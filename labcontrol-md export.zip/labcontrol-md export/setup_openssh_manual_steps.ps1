# Windows 11 OpenSSH Setup — Step-by-Step Manual Guide
# ====================================================
# Run each block in an ELEVATED PowerShell (Run as Administrator)
# This is the manual version of setup_openssh_labcontrol.ps1

# ─────────────────────────────────────────────────────
# STEP 1 : CHECK IF OPENSSH SERVER IS ALREADY INSTALLED
# ─────────────────────────────────────────────────────

Get-WindowsCapability -Online | Where-Object Name -like 'OpenSSH*'

# You should see TWO entries:
#   OpenSSH.Client~~~~0.0.1.0    — State : Installed  (usually pre-installed)
#   OpenSSH.Server~~~~0.0.1.0    — State : Installed  (or NotPresent)

# ─────────────────────────────────────────────────────
# STEP 2 : INSTALL OPENSSH SERVER (if State is NotPresent)
# ─────────────────────────────────────────────────────

Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0

# Verify installation
Get-WindowsCapability -Online | Where-Object Name -like 'OpenSSH.Server*'
# Should now show: State : Installed

# ─────────────────────────────────────────────────────
# STEP 3 : START THE SSHD SERVICE
# ─────────────────────────────────────────────────────

# Start the service
Start-Service sshd

# Set it to start automatically on every boot
Set-Service -Name sshd -StartupType Automatic

# Verify it's running
Get-Service sshd

# Expected output:
#   Status   Name    DisplayName
#   ------   ----    -----------
#   Running  sshd    OpenSSH SSH Server

# ─────────────────────────────────────────────────────
# STEP 4 : SET POWERSHELL AS DEFAULT SSH SHELL
# ─────────────────────────────────────────────────────

# Without this step, SSH sessions open in cmd.exe (not PowerShell).
# This is the most commonly missed step — and the reason
# PowerShell commands fail over SSH.

New-ItemProperty -Path "HKLM:\SOFTWARE\OpenSSH" `
    -Name DefaultShell `
    -Value "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" `
    -PropertyType String -Force

# Verify
(Get-ItemProperty -Path "HKLM:\SOFTWARE\OpenSSH").DefaultShell

# If you have PowerShell 7 installed and prefer it:
# New-ItemProperty -Path "HKLM:\SOFTWARE\OpenSSH" `
#     -Name DefaultShell `
#     -Value "C:\Program Files\PowerShell\7\pwsh.exe" `
#     -PropertyType String -Force

# ─────────────────────────────────────────────────────
# STEP 5 : CONFIGURE SSHD_CONFIG FOR PASSWORD + KEY AUTH
# ─────────────────────────────────────────────────────

# Open the config file
notepad C:\ProgramData\ssh\sshd_config

# Find and ensure these lines are UNCOMMENTED and set to:
#
#   PasswordAuthentication yes
#   PubkeyAuthentication yes
#   Subsystem sftp sftp-server.exe
#
# IMPORTANT: At the bottom of the file, COMMENT OUT these lines
# (add # at the start) if they exist:
#
#   #Match Group administrators
#   #       AuthorizedKeysFile __PROGRAMDATA__/ssh/administrators_authorized_keys
#
# This fix allows ~/.ssh/authorized_keys to work for admin users.
# Without it, SSH key auth silently fails for Administrator.

# After saving, restart sshd:
Restart-Service sshd

# ─────────────────────────────────────────────────────
# STEP 6 : OPEN WINDOWS FIREWALL FOR PORT 22
# ─────────────────────────────────────────────────────

New-NetFirewallRule -DisplayName "OpenSSH Server (sshd)" `
    -Direction Inbound `
    -Protocol TCP `
    -LocalPort 22 `
    -Action Allow `
    -Profile Any

# Verify
Get-NetFirewallRule -DisplayName "*OpenSSH*" | Select DisplayName, Enabled, Direction

# ─────────────────────────────────────────────────────
# STEP 7 : VERIFY SSH IS LISTENING
# ─────────────────────────────────────────────────────

# Check that sshd is listening on port 22
Get-NetTCPConnection -LocalPort 22 -State Listen

# Expected output:
#   LocalAddress  LocalPort  RemoteAddress  State
#   0.0.0.0       22         0.0.0.0        Listen

# ─────────────────────────────────────────────────────
# STEP 8 : TEST SSH LOCALLY
# ─────────────────────────────────────────────────────

# Test that SSH works on localhost
ssh Administrator@localhost

# You should get a PowerShell prompt (not cmd.exe).
# Type 'exit' to leave the SSH session.

# ─────────────────────────────────────────────────────
# STEP 9 : GET YOUR CONNECTION INFO
# ─────────────────────────────────────────────────────

# Run this to get the values to paste into LabControl:
Write-Host "=== CONNECTION INFO FOR LABCONTROL ==="
Write-Host "Hostname:   $env:COMPUTERNAME"
Write-Host "IP:         $((Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.PrefixOrigin -ne 'WellKnown' -and $_.IPAddress -ne '127.0.0.1' } | Select -First 1).IPAddress)"
Write-Host "MAC:        $((Get-NetAdapter | Where-Object Status -eq Up | Select -First 1).MacAddress -replace '-',':')"
Write-Host "SSH User:   Administrator"
Write-Host "SSH Port:   22"
Write-Host "OS:         $((Get-CimInstance Win32_OperatingSystem).Caption)"

# ─────────────────────────────────────────────────────
# STEP 10 : TEST FROM THE LABCONTROL SERVER
# ─────────────────────────────────────────────────────

# From the Linux/Windows machine running Django, test:
#
#   ssh Administrator@192.168.1.xx
#
# Accept the host key fingerprint, enter the password.
# You should land in a PowerShell prompt.
# Try:
#   Get-Process | Select -First 5
#   Get-LocalUser
#   Get-PSDrive
#   exit

# ─────────────────────────────────────────────────────
# OPTIONAL : ENABLE WAKE-ON-LAN
# ─────────────────────────────────────────────────────

# Enable WoL on the primary NIC (also requires BIOS setting)
Get-NetAdapter | Where-Object Status -eq Up |
    Set-NetAdapterPowerManagement -WakeOnMagicPacket Enabled

# ─────────────────────────────────────────────────────
# OPTIONAL : SETUP SSH KEY AUTH (passwordless login)
# ─────────────────────────────────────────────────────

# On the LABCONTROL SERVER, generate a key pair:
#   ssh-keygen -t ed25519 -f ~/.ssh/labcontrol_key

# Copy the public key to the Windows desktop:
#   scp ~/.ssh/labcontrol_key.pub Administrator@192.168.1.xx:C:\Users\Administrator\.ssh\authorized_keys

# Or manually paste the key content into:
#   C:\Users\Administrator\.ssh\authorized_keys

# Fix permissions on authorized_keys (run on the Windows desktop):
$authKeys = "C:\Users\Administrator\.ssh\authorized_keys"
$acl = Get-Acl $authKeys
$acl.SetAccessRuleProtection($true, $false)
$adminRule = New-Object System.Security.AccessControl.FileSystemAccessRule("Administrators","FullControl","Allow")
$systemRule = New-Object System.Security.AccessControl.FileSystemAccessRule("SYSTEM","FullControl","Allow")
$acl.SetAccessRule($adminRule)
$acl.SetAccessRule($systemRule)
Set-Acl $authKeys $acl

# Test key-based auth:
#   ssh -i ~/.ssh/labcontrol_key Administrator@192.168.1.xx

# ─────────────────────────────────────────────────────
# TROUBLESHOOTING
# ─────────────────────────────────────────────────────

# 1. "Permission denied" on SSH login
#    → Password is wrong, or PasswordAuthentication is not 'yes' in sshd_config
#    → Fix: notepad C:\ProgramData\ssh\sshd_config → set PasswordAuthentication yes
#    → Then: Restart-Service sshd

# 2. "Connection refused" from remote
#    → sshd not running or firewall blocking port 22
#    → Fix: Start-Service sshd
#    → Fix: New-NetFirewallRule (Step 6)

# 3. SSH connects but opens cmd.exe instead of PowerShell
#    → DefaultShell not set
#    → Fix: Step 4 above

# 4. SSH key auth not working for Administrator
#    → The admin authorized_keys override at the bottom of sshd_config
#    → Fix: Comment out the "Match Group administrators" block (Step 5)
#    → Then: Restart-Service sshd

# 5. SFTP "Permission denied"
#    → The SSH user needs read/write access to the target directory
#    → Fix: Use Administrator account, or grant ACL permissions

# 6. "Connection timed out"
#    → PC is off, or IP address is wrong, or different subnet/VLAN
#    → Fix: Verify IP with: Get-NetIPAddress -AddressFamily IPv4
