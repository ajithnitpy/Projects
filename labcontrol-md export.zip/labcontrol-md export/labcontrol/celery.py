"""
Celery configuration for LabControl.
Run:  celery -A labcontrol worker -l info
      celery -A labcontrol beat -l info
Broker: Redis (redis://localhost:6379/0)
"""
import os
from celery import Celery

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'labcontrol.settings')

app = Celery('labcontrol')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks()


@app.task(bind=True)
def debug_task(self):
    print(f'Request: {self.request!r}')
