"""LabControl URL Configuration"""
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/login/', auth_views.LoginView.as_view(
        template_name='registration/login.html'), name='login'),
    path('accounts/logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('', include('core.urls')),
]

# Serve uploaded media in development
from django.conf import settings
from django.conf.urls.static import static
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

from django.views.generic import TemplateView
urlpatterns.insert(0, path('spa/', TemplateView.as_view(template_name='core/spa.html'), name='spa'))
urlpatterns.insert(0, path('app/', TemplateView.as_view(template_name='core/spa.html'), name='app'))
