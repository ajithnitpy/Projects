"""Logging filters for LabControl.

Kept in its own module rather than in settings.py so the dictConfig ``()``
factory can import it without re-entering the settings module during startup.
"""

import logging
import os

# django.core.servers.basehttp logs this at INFO on the 'django.server' logger:
#
#     logger.info("- Broken pipe from %s", client_address)
#
# It is reached only from WSGIServer.handle_error() when is_broken_pipe_error()
# is true -- BrokenPipeError / ConnectionAbortedError / ConnectionResetError --
# i.e. the client went away before the exchange finished. The usual shape is an
# *idle keep-alive* connection reset by the client while the handler waits for
# the next request on it (an abort mid-body is swallowed silently one layer
# down, by ServerHandler.handle_error).
#
# That is a client-side event, never a fault in this application: a browser
# navigating away, a cancelled static asset, the dashboard's 2-minute
# /api/bulk-ping/ poll dropped on a page change, or a probe like
# Invoke-WebRequest / curl -I closing early. It is pure noise in an ops log
# where every other line means something -- and this is a dev-server-only code
# path, so it never appears under a production WSGI server anyway.
BROKEN_PIPE_MSG = "- Broken pipe from %s"

#: Set LABCONTROL_LOG_BROKEN_PIPE=1 to let the notices through again, e.g. when
#: diagnosing a proxy or a client that is genuinely hanging up early.
ENV_TOGGLE = "LABCONTROL_LOG_BROKEN_PIPE"


class SuppressBrokenPipe(logging.Filter):
    """Drop django.server's client-disconnect notices; keep everything else.

    Matches the raw format string rather than the formatted message, so a log
    record that merely *mentions* a broken pipe -- an SSH failure surfaced by
    remote_ops, say -- is never swallowed by accident.
    """

    def filter(self, record):
        if os.environ.get(ENV_TOGGLE) == "1":
            return True
        return record.msg != BROKEN_PIPE_MSG
