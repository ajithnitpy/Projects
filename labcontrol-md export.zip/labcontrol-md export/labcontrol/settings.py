"""
LabControl Settings
===================
Lab Desktop Computer Automation & Administration System.
Backend: MySQL (with SQLite fallback for first-run testing).
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = os.environ.get(
    'LABCONTROL_SECRET_KEY',
    'django-insecure-labcontrol-CHANGE-IN-PRODUCTION-!@#$%^&*()'
)

DEBUG = os.environ.get('LABCONTROL_DEBUG', '1') == '1'
ALLOWED_HOSTS = ['*']

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.humanize',
    'import_export',
    'core',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'core.middleware.ActivityLogMiddleware',
    # Must sit after auth so it can see the login redirect it converts to 401.
    'core.middleware.ApiJsonAuthMiddleware',
]

ROOT_URLCONF = 'labcontrol.urls'

TEMPLATES = [{
    'BACKEND': 'django.template.backends.django.DjangoTemplates',
    'DIRS': [BASE_DIR / 'templates'],
    'APP_DIRS': True,
    'OPTIONS': {
        'context_processors': [
            'django.template.context_processors.debug',
            'django.template.context_processors.request',
            'django.contrib.auth.context_processors.auth',
            'django.contrib.messages.context_processors.messages',
        ],
    },
}]

WSGI_APPLICATION = 'labcontrol.wsgi.application'

# ── Database: MySQL (primary) / SQLite (dev fallback) ──────────
USE_MYSQL = os.environ.get('LABCONTROL_USE_MYSQL', '0') == '1'

if USE_MYSQL:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.mysql',
            'NAME':     os.environ.get('MYSQL_DB',   'labcontrol'),
            'USER':     os.environ.get('MYSQL_USER', 'labadmin'),
            'PASSWORD': os.environ.get('MYSQL_PASS', 'labpass'),
            'HOST':     os.environ.get('MYSQL_HOST', '127.0.0.1'),
            'PORT':     os.environ.get('MYSQL_PORT', '3306'),
            'OPTIONS': {
                'charset': 'utf8mb4',
                'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
            },
        }
    }
else:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'labcontrol.sqlite3',
        }
    }

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
     'OPTIONS': {'min_length': 4}},
]

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Kolkata'
USE_I18N = True
USE_TZ = True

STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

LOGIN_URL = '/accounts/login/'
LOGIN_REDIRECT_URL = '/'
LOGOUT_REDIRECT_URL = '/accounts/login/'

# ── LabControl Application Settings ───────────────────────────
LAB_NAME = os.environ.get('LAB_NAME', 'Research Computing Laboratory')
SSH_TIMEOUT = 10
SSH_DEFAULT_PORT = 22
WOL_BROADCAST = '255.255.255.255'
WOL_PORT = 9
SCAN_MAX_WORKERS = 30
DEFAULT_SHELL_PROMPT = '$'

# ── django-import-export settings ─────────────────────────────
IMPORT_EXPORT_USE_TRANSACTIONS = True
IMPORT_EXPORT_SKIP_ADMIN_LOG = False
IMPORT_EXPORT_IMPORT_PERMISSION_CODE = 'add'
IMPORT_EXPORT_EXPORT_PERMISSION_CODE = 'view'

# ── Local LLM (Ollama) Settings ──
# Ollama runs at http://127.0.0.1:11434 by default (one-time setup):
#   curl -fsSL https://ollama.com/install.sh | sh
#   ollama pull qwen2.5-coder:7b
#   ollama serve &
OLLAMA_HOST    = os.environ.get('OLLAMA_HOST',  'http://127.0.0.1:11434')
OLLAMA_MODEL   = os.environ.get('OLLAMA_MODEL', 'gemma3:27b')
OLLAMA_TIMEOUT = int(os.environ.get('OLLAMA_TIMEOUT', '120'))

# Media files (uploaded packages)
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
MEDIA_URL = '/media/'

# Large file uploads (no size limit, streaming)
DATA_UPLOAD_MAX_MEMORY_SIZE = None  # No limit
FILE_UPLOAD_MAX_MEMORY_SIZE = 10 * 1024 * 1024  # 10MB in memory, rest to temp
FILE_UPLOAD_HANDLERS = [
    'django.core.files.uploadhandler.TemporaryFileUploadHandler',
]
# Long session (24 hours for large uploads)
SESSION_COOKIE_AGE = 86400

# ─── Logging ──────────────────────────────────────────────────
# Django configures DEFAULT_LOGGING first and then applies this dict, so only
# the 'django.server' logger is redefined here -- the 'django' logger and its
# console/mail_admins handlers are inherited untouched. The handler and
# formatter below are byte-for-byte Django's defaults; the single change is the
# attached filter, which drops the dev server's "- Broken pipe from <client>"
# notices (see labcontrol/logging_filters.py for why they are noise, and the
# LABCONTROL_LOG_BROKEN_PIPE=1 escape hatch to get them back).
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'filters': {
        'suppress_broken_pipe': {
            '()': 'labcontrol.logging_filters.SuppressBrokenPipe',
        },
    },
    'formatters': {
        'django.server': {
            '()': 'django.utils.log.ServerFormatter',
            'format': '[{server_time}] {message}',
            'style': '{',
        },
    },
    'handlers': {
        'django.server': {
            'level': 'INFO',
            'class': 'logging.StreamHandler',
            'formatter': 'django.server',
            'filters': ['suppress_broken_pipe'],
        },
    },
    'loggers': {
        'django.server': {
            'handlers': ['django.server'],
            'level': 'INFO',
            'propagate': False,
        },
    },
}

# ─── Celery ───────────────────────────────────────────────────
CELERY_BROKER_URL = os.environ.get('CELERY_BROKER', 'redis://localhost:6379/0')
CELERY_RESULT_BACKEND = os.environ.get('CELERY_BACKEND', 'redis://localhost:6379/0')
CELERY_ACCEPT_CONTENT = ['json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_TIMEZONE = TIME_ZONE if 'TIME_ZONE' in dir() else 'UTC'

CELERY_BEAT_SCHEDULE = {
    'run-due-scheduled-tasks': {
        'task': 'core.tasks.run_due_tasks',
        'schedule': 60.0,   # check every minute
    },
    'poll-usage-every-5min': {
        'task': 'core.tasks.poll_all_usage',
        'schedule': 300.0,
    },
    'nightly-inventory': {
        'task': 'core.tasks.nightly_inventory',
        'schedule': 86400.0,
    },
}
