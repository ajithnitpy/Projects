# LabControl — Central Control Automation System

A Django-based lab desktop fleet management platform. Manages Linux and Windows
desktops entirely over SSH: power control (Wake-on-LAN / shutdown / restart),
live telemetry, a remote file manager, software inventory, config-drift
detection, session tracking, reservations, scheduled tasks, an AI assistant, and
full audit logging.

The interface comes in two blended layers that share one Django backend, one
database, and one login session:

1. **Live SPA** (React single-page app) at `/app/` — sidebar navigation, no page
   reloads, a persistent operations terminal docked at the footer that streams
   every action live.
2. **Classic pages** (server-rendered Django templates) at `/`, `/desktops/`,
   `/apps/`, etc. — the original multi-page UI.

Each layer links to the other, so you can move between them freely.

---

## 1. Requirements

- **Python 3.13** (recommended) or 3.14
- **Django 5.1.16 or newer** — REQUIRED. Django <= 5.1.15 crashes on Python 3.14
  with `'super' object has no attribute 'dicts'` in the admin.
- MySQL (optional; SQLite works out of the box)
- Ollama (optional; only for the AI assistant) running locally on port 11434
- A modern browser (the SPA loads React from a CDN by default)

Target desktops need an SSH server:
- **Linux**: `openssh-server` with the management user able to `sudo`
- **Windows**: the built-in OpenSSH Server, with the management user in the
  local Administrators group. PowerShell commands are wrapped automatically.

---

## 2. Installation

```bash
# 1. Extract and enter the project
cd labcontrol-enhanced

# 2. Create a virtual environment
python -m venv env
# Windows:
env\Scripts\activate
# Linux/macOS:
source env/bin/activate

# 3. Install dependencies (and force the Django version fix)
pip install -r requirements.txt
pip install --upgrade "Django>=5.1.16,<6.0"

# 4. Create the database schema
python manage.py makemigrations core
python manage.py migrate

# 5. Seed demo data (creates admin/admin + example labs & desktops)
python manage.py seed_lab

# 6. Run the server
python manage.py runserver 0.0.0.0:8000
```

Open **http://localhost:8000/app/** and log in (default `admin` / `admin`).

> If `makemigrations` complains about old models like `UserSession` or
> `TaskRun`, delete everything in `core/migrations/` except `__init__.py`, delete
> `db.sqlite3`, and re-run steps 4-5. Those were removed in a cleanup.

---

## 3. The two interfaces, blended

| Layer | URL | How it works |
|---|---|---|
| **Live SPA** | `/app/` (or `/spa/`) | One React app, sidebar menu, footer terminal |
| **Classic Dashboard** | `/` | Server-rendered Django template |
| Desktop list | `/desktops/` | Classic |
| App catalog | `/apps/` | Classic |
| Package repo | `/packages/` | Classic |
| Discovery | `/discovery/` | Classic |
| Locations | `/locations/` | Classic |
| Django admin | `/admin/` | Built-in admin for all models |

**How they blend:**
- The classic sidebar has a green **"Open Live SPA ->"** button at the top.
- The SPA sidebar has a **"Classic Pages"** section linking back to every Django
  page (`/`, `/desktops/`, `/apps/`, `/packages/`, `/discovery/`, `/locations/`,
  `/admin/`).
- Both use the same session cookie, so you never log in twice.

---

## 4. The SPA layout

```
+----------+---------------------------------------------+
|          |  Dashboard              last: ping ok...    |  <- top status bar
| SIDEBAR  +---------------------------------------------+
|          |                                             |
| SPA      |                                             |
| Modules  |            ACTIVE PAGE CONTENT              |
|  - Dash  |            (changes without reload)         |
|  - Files |                                             |
|  - ...   |                                             |
|          |                                             |
| Classic  |                                             |
| Pages    +---------------------------------------------+
|  - ...   |  OPERATIONS TERMINAL       3 events    v    |  <- footer terminal
|  admin   |  14:32:01.123  CMD  [lab-a-pc-01] ping       |    (persists across
|  Logout  |  14:32:01.456  OK   3 online, 0 offline      |     ALL pages)
+----------+---------------------------------------------+
```

- **Sidebar** — collapsible (« / » button). Two sections: SPA Modules (9 React
  pages) and Classic Pages (links to Django templates).
- **Footer terminal** — always visible, aligns beside the sidebar, streams every
  operation with millisecond timestamps and color-coded levels
  (CMD / OUT / OK / WARN / ERR / INFO). Collapsible; CLEAR button empties it.
- **Top status bar** — shows the current page and the last terminal action.

### SPA modules

| Module | What it does | Backing API |
|---|---|---|
| Dashboard | Device tiles per lab, Ping All, per-device power | `/api/dashboard/`, `/api/ping-all/`, `/api/power/` |
| File Manager | Browse / view / edit / download / upload / delete remote files | `/api/files/`, `/api/fm/*` |
| Sessions | Active login sessions with duration + idle | `/api/sessions/` |
| Inventory | Fleet software list, searchable | `/api/software/` |
| Config Drift | Drift reports vs golden config | `/api/drift/` |
| Reservations | Upcoming desktop bookings | `/api/reservations/` |
| Schedules | Scheduled task list | `/api/scheduled-tasks/` |
| AI Assistant | General Q&A + read error logs | `/api/ai/ask/`, `/api/ai/read-logs/` |
| Audit Logs | Shell / power / activity history | `/api/logs/` |

---

## 5. Frontend implementation — two paths

The SPA is one file: `static/js/app.jsx`. Django serves it via the
`templates/core/spa.html` host template. You can run it two ways.

### Path A — CDN (default, no Node.js) — WORKS OUT OF THE BOX

`spa.html` loads React 18 + Babel from a CDN and transpiles `app.jsx` in the
browser. Nothing to build. This is what runs when you open `/app/`.

- **Pros**: zero build step, no Node.js, no `npm`.
- **Cons**: ~500 KB of CDN JS on first load; in-browser transpile adds ~1 s to
  first render. Perfectly fine for an internal lab tool.
- **Air-gapped?** Download the three CDN scripts into `static/js/vendor/` and
  point the `<script>` tags in `spa.html` at them. Then it needs no internet.

### Path B — Vite build (optimized, needs Node.js)

For faster loads, precompile to a minified bundle.

```bash
# One-time setup
npm create vite@latest frontend -- --template react
cd frontend
npm install

# Copy static/js/app.jsx into frontend/src/App.jsx
# Change the last line from ReactDOM.createRoot(...).render(<App />)
#   to:  export default App;
# Create src/main.jsx that imports and renders App.

# Configure frontend/vite.config.js:
#   base: "/static/spa/",
#   build: { outDir: "../static/spa", emptyOutDir: true, manifest: true },
#   server: { proxy: { "/api": "http://localhost:8000" } }

# Development with hot reload (Django on :8000 in another terminal):
npm run dev            # http://localhost:5173

# Production build:
npm run build          # outputs to ../static/spa/
python manage.py collectstatic
# Then point spa.html's <script> at the hashed file in static/spa/.vite/manifest.json
```

See `SPA_SETUP.md` for the full Vite walkthrough.

### Using any other frontend framework

The backend is a plain JSON REST API — nothing about it is React-specific. To
use Vue, Svelte, Angular, htmx, or a mobile app instead:

1. Point your client at the same `/api/*` endpoints (all listed in section 4).
2. On startup, `GET /api/csrf/` once to set the CSRF cookie.
3. Send the `X-CSRFToken` header (read from the `csrftoken` cookie) on every
   POST. Use `credentials: "include"` so the session cookie rides along.
4. `POST /api/login/` with `{username, password}` to authenticate.

That's the entire contract. The React app in `static/js/app.jsx` is just one
reference client.

---

## 6. Populating data

Some SPA pages are empty until a collector runs. Collectors connect to online,
managed desktops over SSH.

```bash
# All collectors across the fleet
python manage.py run_collectors --type all

# Individually
python manage.py run_collectors --type sessions    # login sessions
python manage.py run_collectors --type software     # inventory
python manage.py run_collectors --type drift        # config drift

# Limit to one lab (Location ID)
python manage.py run_collectors --type software --lab 3
```

**Reservations** and **Scheduled Tasks** are created through the admin:
- `/admin/core/reservation/add/`
- `/admin/core/scheduledtask/add/`

**Golden configs** (the baseline for drift detection) and **software policies**
(required/forbidden rules) are also created in the admin before their collectors
produce meaningful output:
- `/admin/core/goldenconfig/add/`
- `/admin/core/softwarepolicy/add/`

> The scheduled-task **definitions** exist and are listed in the Schedules page,
> but automatic firing requires Celery Beat, which is not wired up yet. Until
> then, run tasks manually via `run_collectors` or the power APIs.

---

## 7. Adding a real desktop

1. Go to `/admin/core/desktop/add/` (or the classic Desktop List -> Add).
2. Fill in: device name, IP address, MAC address (for Wake-on-LAN), OS type,
   SSH username, and SSH password or key path.
3. Set **is_managed = true** so collectors and bulk ops include it.
4. Test from the SPA Dashboard: click **Ping**, then **Shell** to run a command.

Wake-on-LAN prerequisites on each desktop:
- BIOS: enable "Wake on LAN" / "Power On by PCI-E"
- Windows: disable Fast Startup; enable "Wake on Magic Packet" on the NIC
- Linux: `sudo ethtool -s eth0 wol g`
- Use wired ethernet (WoL over WiFi rarely works)

---

## 8. Project structure

```
labcontrol-enhanced/
├── manage.py
├── requirements.txt
├── README.md                    <- this file
├── SPA_SETUP.md                 <- Vite build details
├── labcontrol/
│   ├── settings.py              <- MEDIA, large uploads, static config
│   └── urls.py                  <- /app/ and /spa/ routes
├── core/
│   ├── models.py                <- 23 models (desktops, logs, features)
│   ├── views.py                 <- classic server-rendered pages
│   ├── api.py                   <- JSON REST API for the SPA
│   ├── remote_ops.py            <- SSH/SFTP, WoL, power, telemetry
│   ├── collectors.py            <- session/software/drift SSH scans
│   ├── ai_agent.py              <- Ollama client (general assistant)
│   ├── admin.py                 <- admin registration for all models
│   ├── urls.py                  <- all classic + /api/ routes
│   └── management/commands/
│       ├── seed_lab.py          <- demo data
│       └── run_collectors.py    <- manual collector runner
├── templates/core/
│   ├── base.html                <- classic sidebar (links to SPA)
│   ├── spa.html                 <- SPA host (loads React + app.jsx)
│   ├── dashboard.html           <- classic dashboard
│   └── ...                      <- other classic pages
└── static/
    ├── js/app.jsx               <- the entire React SPA
    └── css/
```

---

## 9. Troubleshooting

| Symptom | Fix |
|---|---|
| `'super' object has no attribute 'dicts'` on any admin page | Upgrade: `pip install --upgrade "Django>=5.1.16"` |
| `AlreadyRegistered: InstalledSoftware` | You have an old `admin.py`; use this build (duplicates removed) |
| `makemigrations` mentions `UserSession`/`TaskRun` | Delete `core/migrations/0*.py` (keep `__init__.py`) + `db.sqlite3`, re-migrate |
| SPA loads but pages are empty | Run `python manage.py run_collectors --type all` |
| SPA login works but data calls 403 | The CSRF cookie wasn't set — the app calls `/api/csrf/` on load; hard-refresh |
| AI assistant says unavailable | Start Ollama locally (`ollama serve`) with a model like `llama3.2:3b` |
| WoL does nothing | Check BIOS WoL, disable Windows Fast Startup, use wired ethernet, try directed-broadcast method |
| Air-gapped, SPA won't load React | Bundle React/Babel locally into `static/js/vendor/` (see section 5 Path A) |

---

## 10. Default credentials

After `seed_lab`: **admin / admin**. Change immediately in production via
`/admin/` or `python manage.py changepassword admin`.
