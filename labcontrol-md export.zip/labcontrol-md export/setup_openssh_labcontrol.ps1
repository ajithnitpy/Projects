<#
.SYNOPSIS
    LabControl — Windows 11 OpenSSH Server Setup Script
    Configures a Windows 11 desktop to be fully managed via SSH from the
    LabControl Django dashboard.

.DESCRIPTION
    This script performs ALL required steps in one run:
      1. Installs OpenSSH Server (built into Windows 10 1809+ / Windows 11)
      2. Starts and enables the sshd service
      3. Sets PowerShell as the default SSH shell (instead of cmd.exe)
      4. Configures sshd_config for password auth + key auth
      5. Opens Windows Firewall for port 22
      6. Creates an SSH admin user (optional)
      7. Enables Wake-on-LAN on the primary NIC
      8. Tests the configuration
      9. Displays connection info for pasting into LabControl

.NOTES
    Run this script as ADMINISTRATOR on each Windows lab desktop.

    Usage:
      Right-click PowerShell → "Run as administrator"
      Set-ExecutionPolicy Bypass -Scope Process -Force
      .\setup_openssh_labcontrol.ps1

    Or run remotely from a working SSH session on another Windows PC:
      powershell -ExecutionPolicy Bypass -File .\setup_openssh_labcontrol.ps1

.EXAMPLE
    PS C:\> .\setup_openssh_labcontrol.ps1
    PS C:\> .\setup_openssh_labcontrol.ps1 -CreateUser labadmin -UserPassword 'SecurePass123!'
    PS C:\> .\setup_openssh_labcontrol.ps1 -SkipWoL -SkipUserCreation
#>

[CmdletBinding()]
param(
    [string]$CreateUser      = '',            # Username to create (blank = skip)
    [string]$UserPassword    = '',            # Password for new user
    [switch]$SkipWoL         = $false,        # Skip Wake-on-LAN setup
    [switch]$SkipUserCreation= $false,        # Skip user creation entirely
    [switch]$SkipFirewall    = $false,        # Skip firewall rule
    [int]   $SSHPort         = 22             # SSH port (default 22)
)

# ═══════════════════════════════════════════════════════════════
#  HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════

function Write-Step {
    param([string]$Num, [string]$Title)
    Write-Host ""
    Write-Host "  ┌─────────────────────────────────────────────────" -ForegroundColor Cyan
    Write-Host "  │ STEP $Num : $Title" -ForegroundColor Cyan
    Write-Host "  └─────────────────────────────────────────────────" -ForegroundColor Cyan
}

function Write-OK {
    param([string]$Msg)
    Write-Host "    ✓ $Msg" -ForegroundColor Green
}

function Write-Warn {
    param([string]$Msg)
    Write-Host "    ⚠ $Msg" -ForegroundColor Yellow
}

function Write-Fail {
    param([string]$Msg)
    Write-Host "    ✗ $Msg" -ForegroundColor Red
}

function Write-Info {
    param([string]$Msg)
    Write-Host "    → $Msg" -ForegroundColor Gray
}

# ═══════════════════════════════════════════════════════════════
#  PRE-FLIGHT CHECKS
# ═══════════════════════════════════════════════════════════════

Write-Host ""
Write-Host "  ╔═══════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "  ║   LabControl — Windows 11 OpenSSH Setup          ║" -ForegroundColor Cyan
Write-Host "  ║   SSH Server Configuration for Lab Desktops      ║" -ForegroundColor Cyan
Write-Host "  ╚═══════════════════════════════════════════════════╝" -ForegroundColor Cyan

# Check we're running as admin
$isAdmin = ([Security.Principal.WindowsPrincipal] `
            [Security.Principal.WindowsIdentity]::GetCurrent() `
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Fail "This script must be run as Administrator!"
    Write-Info "Right-click PowerShell → 'Run as administrator', then try again."
    exit 1
}
Write-OK "Running as Administrator"

# Check Windows version
$os = Get-CimInstance Win32_OperatingSystem
$ver = [System.Version]$os.Version
Write-Info "OS: $($os.Caption) (Build $($os.BuildNumber))"

if ($ver.Build -lt 17763) {
    Write-Fail "OpenSSH Server requires Windows 10 1809 (Build 17763) or later."
    Write-Info "Current build: $($ver.Build). Please update Windows."
    exit 1
}
Write-OK "Windows version compatible"


# ═══════════════════════════════════════════════════════════════
#  STEP 1 : INSTALL OPENSSH SERVER
# ═══════════════════════════════════════════════════════════════

Write-Step "1" "Install OpenSSH Server"

$sshCapability = Get-WindowsCapability -Online | Where-Object {
    $_.Name -like 'OpenSSH.Server*'
}

if ($sshCapability.State -eq 'Installed') {
    Write-OK "OpenSSH Server already installed"
} else {
    Write-Info "Installing OpenSSH Server..."
    try {
        $result = Add-WindowsCapability -Online -Name 'OpenSSH.Server~~~~0.0.1.0' -ErrorAction Stop
        if ($result.RestartNeeded) {
            Write-Warn "A restart may be required to complete installation"
        }
        Write-OK "OpenSSH Server installed"
    } catch {
        Write-Fail "Installation failed: $($_.Exception.Message)"
        Write-Info "Try manually: Settings → Apps → Optional Features → Add → OpenSSH Server"
        exit 1
    }
}

# Also ensure OpenSSH Client is installed (for ssh-keygen etc.)
$clientCap = Get-WindowsCapability -Online | Where-Object {
    $_.Name -like 'OpenSSH.Client*'
}
if ($clientCap.State -ne 'Installed') {
    Write-Info "Installing OpenSSH Client..."
    Add-WindowsCapability -Online -Name 'OpenSSH.Client~~~~0.0.1.0' -ErrorAction SilentlyContinue
    Write-OK "OpenSSH Client installed"
} else {
    Write-OK "OpenSSH Client already installed"
}


# ═══════════════════════════════════════════════════════════════
#  STEP 2 : START AND ENABLE SSHD SERVICE
# ═══════════════════════════════════════════════════════════════

Write-Step "2" "Start and enable sshd service"

try {
    # Start the service
    Start-Service sshd -ErrorAction Stop
    Write-OK "sshd service started"
} catch {
    Write-Warn "Could not start sshd: $($_.Exception.Message)"
    Write-Info "Attempting to set startup type first..."
    Set-Service -Name sshd -StartupType Automatic
    Start-Service sshd
    Write-OK "sshd service started (retry)"
}

# Set to auto-start on boot
Set-Service -Name sshd -StartupType Automatic
Write-OK "sshd set to start automatically on boot"

# Also start ssh-agent
try {
    Start-Service ssh-agent -ErrorAction SilentlyContinue
    Set-Service -Name ssh-agent -StartupType Automatic -ErrorAction SilentlyContinue
    Write-OK "ssh-agent started and enabled"
} catch {
    Write-Warn "ssh-agent not available (non-critical)"
}

# Verify
$svc = Get-Service sshd
if ($svc.Status -eq 'Running') {
    Write-OK "sshd is RUNNING (Status: $($svc.Status))"
} else {
    Write-Fail "sshd is NOT running (Status: $($svc.Status))"
    exit 1
}


# ═══════════════════════════════════════════════════════════════
#  STEP 3 : SET POWERSHELL AS DEFAULT SSH SHELL
# ═══════════════════════════════════════════════════════════════

Write-Step "3" "Set PowerShell as default SSH shell"

$regPath = "HKLM:\SOFTWARE\OpenSSH"
$psPath  = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"

# Check if PowerShell 7 is available (preferred)
$ps7 = "C:\Program Files\PowerShell\7\pwsh.exe"
if (Test-Path $ps7) {
    $psPath = $ps7
    Write-Info "PowerShell 7 detected — using pwsh.exe"
} else {
    Write-Info "Using Windows PowerShell 5.1"
}

# Create the registry key if it doesn't exist
if (-not (Test-Path $regPath)) {
    New-Item -Path $regPath -Force | Out-Null
}

New-ItemProperty -Path $regPath `
    -Name DefaultShell `
    -Value $psPath `
    -PropertyType String `
    -Force | Out-Null

Write-OK "Default SSH shell set to: $psPath"
Write-Info "This means 'ssh user@host' drops into PowerShell directly"
Write-Info "(no more needing 'powershell -c' prefix for every command)"


# ═══════════════════════════════════════════════════════════════
#  STEP 4 : CONFIGURE SSHD_CONFIG
# ═══════════════════════════════════════════════════════════════

Write-Step "4" "Configure sshd_config"

$sshdConfig = "$env:ProgramData\ssh\sshd_config"

if (-not (Test-Path $sshdConfig)) {
    Write-Fail "sshd_config not found at $sshdConfig"
    Write-Info "The OpenSSH installation may be incomplete"
    exit 1
}

# Backup original
$backup = "$sshdConfig.bak.$(Get-Date -Format 'yyyyMMdd-HHmmss')"
Copy-Item $sshdConfig $backup -Force
Write-OK "Backed up to: $backup"

# Read current config
$config = Get-Content $sshdConfig -Raw

# Ensure key settings are enabled
$changes = @(
    @{ Pattern = '#?\s*PasswordAuthentication\s+\w+';
       Replace = 'PasswordAuthentication yes';
       Desc    = 'Password authentication enabled' },

    @{ Pattern = '#?\s*PubkeyAuthentication\s+\w+';
       Replace = 'PubkeyAuthentication yes';
       Desc    = 'Public key authentication enabled' },

    @{ Pattern = '#?\s*PermitRootLogin\s+\w+';
       Replace = '# PermitRootLogin (N/A on Windows)';
       Desc    = 'PermitRootLogin commented (N/A)' },

    @{ Pattern = '#?\s*Subsystem\s+sftp\s+.*';
       Replace = 'Subsystem sftp sftp-server.exe';
       Desc    = 'SFTP subsystem enabled' }
)

foreach ($c in $changes) {
    if ($config -match $c.Pattern) {
        $config = $config -replace $c.Pattern, $c.Replace
    } else {
        # Append if not present
        $config += "`r`n$($c.Replace)"
    }
    Write-OK $c.Desc
}

# CRITICAL: Fix the administrators_authorized_keys problem
# By default, Windows OpenSSH uses a special authorized_keys file for
# admin users that blocks normal ~/.ssh/authorized_keys from working.
# Comment out these lines so key auth works normally.
$adminKeyPattern = '(?m)^(Match Group administrators[\s\S]*?AuthorizedKeysFile[^\r\n]*)'
if ($config -match $adminKeyPattern) {
    $config = $config -replace '(?m)^(Match Group administrators)', '# $1'
    $config = $config -replace '(?m)^(\s*AuthorizedKeysFile\s+__PROGRAMDATA__)', '# $1'
    Write-OK "Disabled admin-specific authorized_keys override"
    Write-Info "SSH key auth now works from ~/.ssh/authorized_keys for all users"
} else {
    Write-Info "No admin authorized_keys override found (already OK)"
}

# Write updated config
Set-Content -Path $sshdConfig -Value $config -Encoding UTF8 -Force
Write-OK "sshd_config updated"

# Restart sshd to apply changes
Restart-Service sshd -Force
Write-OK "sshd restarted with new configuration"


# ═══════════════════════════════════════════════════════════════
#  STEP 5 : CONFIGURE WINDOWS FIREWALL
# ═══════════════════════════════════════════════════════════════

Write-Step "5" "Configure Windows Firewall"

if ($SkipFirewall) {
    Write-Warn "Skipped (flag -SkipFirewall)"
} else {
    # Remove any old rules first
    Get-NetFirewallRule -DisplayName "*OpenSSH*" -ErrorAction SilentlyContinue |
        Remove-NetFirewallRule -ErrorAction SilentlyContinue

    # Create inbound rule
    New-NetFirewallRule `
        -DisplayName "OpenSSH Server (sshd) - LabControl" `
        -Description "Allow inbound SSH connections for LabControl management" `
        -Direction Inbound `
        -Protocol TCP `
        -LocalPort $SSHPort `
        -Action Allow `
        -Profile Any `
        -Enabled True | Out-Null

    Write-OK "Firewall rule created: TCP port $SSHPort inbound (all profiles)"

    # Verify
    $rule = Get-NetFirewallRule -DisplayName "*OpenSSH Server*LabControl*" -ErrorAction SilentlyContinue
    if ($rule) {
        Write-OK "Firewall rule verified active"
    } else {
        Write-Warn "Could not verify rule — check Windows Firewall manually"
    }
}


# ═══════════════════════════════════════════════════════════════
#  STEP 6 : CREATE SSH ADMIN USER (OPTIONAL)
# ═══════════════════════════════════════════════════════════════

Write-Step "6" "Create SSH admin user"

if ($SkipUserCreation) {
    Write-Warn "Skipped (flag -SkipUserCreation)"
    Write-Info "You can SSH as the existing Administrator account"
} elseif ($CreateUser -ne '') {
    # Create the user
    $userExists = Get-LocalUser -Name $CreateUser -ErrorAction SilentlyContinue
    if ($userExists) {
        Write-Warn "User '$CreateUser' already exists — skipping creation"
    } else {
        if ($UserPassword -eq '') {
            Write-Fail "Password required when creating a user"
            Write-Info "Usage: .\setup_openssh_labcontrol.ps1 -CreateUser labadmin -UserPassword 'Pass123!'"
        } else {
            $secPw = ConvertTo-SecureString $UserPassword -AsPlainText -Force
            New-LocalUser -Name $CreateUser `
                          -Password $secPw `
                          -FullName "LabControl Admin" `
                          -Description "SSH admin account for LabControl dashboard" `
                          -PasswordNeverExpires `
                          -AccountNeverExpires | Out-Null

            # Add to Administrators group (required for user management operations)
            Add-LocalGroupMember -Group "Administrators" -Member $CreateUser `
                                 -ErrorAction SilentlyContinue
            Add-LocalGroupMember -Group "Users" -Member $CreateUser `
                                 -ErrorAction SilentlyContinue

            Write-OK "User '$CreateUser' created and added to Administrators group"
            Write-Info "This user can now SSH in and manage other users"
        }
    }
} else {
    Write-Info "No user requested — use existing Administrator account"
    Write-Info "To create one: .\setup_openssh_labcontrol.ps1 -CreateUser labadmin -UserPassword 'Pass!'"
}


# ═══════════════════════════════════════════════════════════════
#  STEP 7 : ENABLE WAKE-ON-LAN
# ═══════════════════════════════════════════════════════════════

Write-Step "7" "Enable Wake-on-LAN"

if ($SkipWoL) {
    Write-Warn "Skipped (flag -SkipWoL)"
} else {
    try {
        $adapters = Get-NetAdapter | Where-Object { $_.Status -eq 'Up' -and $_.InterfaceDescription -notlike '*Virtual*' }
        foreach ($nic in $adapters) {
            # Enable WoL at driver level
            $wolProps = @('*WakeOnMagicPacket', '*WakeOnPattern', 'WakeOnMagicPacket',
                          'WakeOnMagicPacketFromPowerOff')
            foreach ($prop in $wolProps) {
                $p = Get-NetAdapterAdvancedProperty -Name $nic.Name -RegistryKeyword $prop `
                     -ErrorAction SilentlyContinue
                if ($p) {
                    Set-NetAdapterAdvancedProperty -Name $nic.Name -RegistryKeyword $prop `
                        -RegistryValue '1' -ErrorAction SilentlyContinue
                }
            }

            # Enable via PowerManagement
            Set-NetAdapterPowerManagement -Name $nic.Name -WakeOnMagicPacket Enabled `
                -ErrorAction SilentlyContinue

            $mac = $nic.MacAddress -replace '-', ':'
            Write-OK "WoL enabled on: $($nic.Name) (MAC: $mac)"
        }
    } catch {
        Write-Warn "WoL setup error: $($_.Exception.Message)"
        Write-Info "You may need to enable WoL in BIOS/UEFI manually"
    }
    Write-Info "NOTE: WoL also requires BIOS/UEFI setting — check under Power Management"
}


# ═══════════════════════════════════════════════════════════════
#  STEP 8 : SETUP SSH KEY DIRECTORY (for key-based auth)
# ═══════════════════════════════════════════════════════════════

Write-Step "8" "Setup SSH key directories"

# Create .ssh directory for the current user
$sshDir = "$env:USERPROFILE\.ssh"
if (-not (Test-Path $sshDir)) {
    New-Item -ItemType Directory -Path $sshDir -Force | Out-Null
    Write-OK "Created $sshDir"
} else {
    Write-OK "$sshDir already exists"
}

$authKeys = "$sshDir\authorized_keys"
if (-not (Test-Path $authKeys)) {
    New-Item -ItemType File -Path $authKeys -Force | Out-Null
    Write-OK "Created $authKeys (empty — add your public keys here)"
} else {
    $keyCount = (Get-Content $authKeys | Where-Object { $_ -match '\S' }).Count
    Write-OK "$authKeys exists ($keyCount keys)"
}

# Fix permissions on authorized_keys (Windows ACL)
$acl = Get-Acl $authKeys
$acl.SetAccessRuleProtection($true, $false)  # Disable inheritance
$adminRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
    "Administrators", "FullControl", "Allow")
$systemRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
    "SYSTEM", "FullControl", "Allow")
$userRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
    $env:USERNAME, "FullControl", "Allow")
$acl.SetAccessRule($adminRule)
$acl.SetAccessRule($systemRule)
$acl.SetAccessRule($userRule)
Set-Acl $authKeys $acl -ErrorAction SilentlyContinue
Write-OK "Permissions set on authorized_keys"

Write-Info "To enable key-based auth from the LabControl server:"
Write-Info "  1. On the server: ssh-keygen -t ed25519"
Write-Info "  2. Copy ~/.ssh/id_ed25519.pub content into:"
Write-Info "     $authKeys"

# Also create .ssh for the new user if created
if ($CreateUser -ne '' -and -not $SkipUserCreation) {
    $newUserHome = "C:\Users\$CreateUser"
    if (Test-Path $newUserHome) {
        $newSshDir = "$newUserHome\.ssh"
        if (-not (Test-Path $newSshDir)) {
            New-Item -ItemType Directory -Path $newSshDir -Force | Out-Null
            New-Item -ItemType File -Path "$newSshDir\authorized_keys" -Force | Out-Null
            Write-OK "Created $newSshDir\authorized_keys for user '$CreateUser'"
        }
    }
}


# ═══════════════════════════════════════════════════════════════
#  STEP 9 : VERIFICATION
# ═══════════════════════════════════════════════════════════════

Write-Step "9" "Verify configuration"

# Test sshd is listening
$listener = Get-NetTCPConnection -LocalPort $SSHPort -State Listen -ErrorAction SilentlyContinue
if ($listener) {
    Write-OK "sshd is listening on port $SSHPort"
} else {
    Write-Fail "sshd is NOT listening on port $SSHPort"
    Write-Info "Try: Restart-Service sshd"
}

# Test SSH locally
Write-Info "Testing local SSH connection..."
try {
    $testResult = & ssh -o "StrictHostKeyChecking=no" -o "BatchMode=yes" -o "ConnectTimeout=5" `
                    localhost "echo SSH_OK" 2>&1
    if ($testResult -match 'SSH_OK') {
        Write-OK "Local SSH test: SUCCESS"
    } elseif ($testResult -match 'Permission denied') {
        Write-OK "SSH port reachable (auth needed — expected with BatchMode)"
    } else {
        Write-Warn "SSH test returned: $testResult"
    }
} catch {
    Write-Warn "Local SSH test skipped: $($_.Exception.Message)"
}

# Verify default shell
$defaultShell = (Get-ItemProperty -Path "HKLM:\SOFTWARE\OpenSSH" -Name DefaultShell -ErrorAction SilentlyContinue).DefaultShell
if ($defaultShell) {
    Write-OK "Default shell: $defaultShell"
} else {
    Write-Warn "Default shell not set (will use cmd.exe)"
}

# Verify firewall
$fwRule = Get-NetFirewallRule -DisplayName "*OpenSSH*LabControl*" -ErrorAction SilentlyContinue
if ($fwRule -and $fwRule.Enabled -eq 'True') {
    Write-OK "Firewall rule: active"
} elseif (-not $SkipFirewall) {
    Write-Warn "Firewall rule not found — SSH may be blocked from remote hosts"
}


# ═══════════════════════════════════════════════════════════════
#  SUMMARY — PASTE THESE INTO LABCONTROL DASHBOARD
# ═══════════════════════════════════════════════════════════════

Write-Host ""
Write-Host "  ╔═══════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "  ║              SETUP COMPLETE                      ║" -ForegroundColor Green
Write-Host "  ╚═══════════════════════════════════════════════════╝" -ForegroundColor Green

$hostname   = $env:COMPUTERNAME
$ipAddress  = (Get-NetIPAddress -AddressFamily IPv4 |
               Where-Object { $_.PrefixOrigin -ne 'WellKnown' -and
                              $_.IPAddress -ne '127.0.0.1' } |
               Select-Object -First 1).IPAddress
$macAddress = (Get-NetAdapter | Where-Object { $_.Status -eq 'Up' -and
               $_.InterfaceDescription -notlike '*Virtual*' } |
               Select-Object -First 1).MacAddress -replace '-', ':'
$osCaption  = $os.Caption
$cpu        = (Get-CimInstance Win32_Processor | Select-Object -First 1).Name
$ramGB      = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
$diskGB     = [math]::Round((Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" ).Size / 1GB)
$sshUser    = if ($CreateUser -ne '' -and -not $SkipUserCreation) { $CreateUser } else { "Administrator" }

Write-Host ""
Write-Host "  Enter these values in the LabControl 'Add Desktop' form:" -ForegroundColor Yellow
Write-Host ""
Write-Host "  ┌──────────────────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host "  │  Device Name   :  $hostname" -ForegroundColor White
Write-Host "  │  IP Address    :  $ipAddress" -ForegroundColor White
Write-Host "  │  MAC Address   :  $macAddress" -ForegroundColor White
Write-Host "  │  SSH Username  :  $sshUser" -ForegroundColor White
Write-Host "  │  SSH Port      :  $SSHPort" -ForegroundColor White
Write-Host "  │  OS Type       :  Windows 11   (or Windows 10)" -ForegroundColor White
Write-Host "  │  OS Version    :  $osCaption" -ForegroundColor White
Write-Host "  │  CPU           :  $cpu" -ForegroundColor White
Write-Host "  │  RAM           :  $ramGB GB" -ForegroundColor White
Write-Host "  │  Storage       :  $diskGB GB" -ForegroundColor White
Write-Host "  └──────────────────────────────────────────────────────────" -ForegroundColor DarkGray
Write-Host ""
Write-Host "  Test from the LabControl server:" -ForegroundColor Yellow
Write-Host "    ssh $sshUser@$ipAddress" -ForegroundColor Cyan
Write-Host ""
Write-Host "  If using SSH keys, copy your public key to:" -ForegroundColor Yellow
Write-Host "    C:\Users\$sshUser\.ssh\authorized_keys" -ForegroundColor Cyan
Write-Host ""
