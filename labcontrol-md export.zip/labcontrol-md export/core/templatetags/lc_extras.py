"""Custom template filters for LabControl."""
from django import template

register = template.Library()


@register.filter(name='split')
def split_str(value, sep=','):
    """Split a string by separator. Usage: {{ "a,b,c"|split:"," }}"""
    if not value:
        return []
    return value.split(sep)


@register.filter(name='filesize')
def filesize(value):
    """Human-readable file size."""
    try:
        size = float(value)
    except (TypeError, ValueError):
        return value
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if size < 1024:
            return f'{size:.1f} {unit}'
        size /= 1024
    return f'{size:.1f} PB'
