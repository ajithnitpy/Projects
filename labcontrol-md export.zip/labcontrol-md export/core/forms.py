"""LabControl Forms"""
from django import forms
from .models import Desktop, Location


_BASE = {'class': 'form-input'}
_SEL = {'class': 'form-select'}
_TXT = {'class': 'form-textarea', 'rows': 3}


class LocationForm(forms.ModelForm):
    class Meta:
        model = Location
        fields = ['name', 'building', 'room', 'floor', 'description', 'color']
        widgets = {
            'name':        forms.TextInput(attrs={**_BASE, 'placeholder': 'Lab A'}),
            'building':    forms.TextInput(attrs={**_BASE, 'placeholder': 'Block 3'}),
            'room':        forms.TextInput(attrs={**_BASE, 'placeholder': '301'}),
            'floor':       forms.TextInput(attrs={**_BASE, 'placeholder': '3rd'}),
            'description': forms.Textarea(attrs=_TXT),
            'color':       forms.TextInput(attrs={**_BASE, 'type': 'color'}),
        }


class DesktopForm(forms.ModelForm):
    ssh_password = forms.CharField(
        required=False,
        widget=forms.PasswordInput(attrs={**_BASE, 'autocomplete': 'new-password'}),
        help_text='Leave blank to keep existing'
    )
    sudo_password = forms.CharField(
        required=False,
        widget=forms.PasswordInput(attrs={**_BASE, 'autocomplete': 'new-password'})
    )

    class Meta:
        model = Desktop
        fields = [
            'device_name', 'ip_address', 'mac_address',
            'ssh_username', 'ssh_port', 'ssh_key_path', 'use_sudo',
            'make', 'model', 'serial_no', 'cpu', 'ram_gb', 'storage_gb',
            'os_type', 'os_version', 'purchase_year',
            'location', 'asset_tag', 'notes', 'is_managed',
        ]
        widgets = {
            'device_name':  forms.TextInput(attrs={**_BASE, 'placeholder': 'lab-pc-01'}),
            'ip_address':   forms.TextInput(attrs={**_BASE, 'placeholder': '192.168.1.10'}),
            'mac_address':  forms.TextInput(attrs={**_BASE, 'placeholder': 'AA:BB:CC:DD:EE:FF'}),
            'ssh_username': forms.TextInput(attrs={**_BASE, 'placeholder': 'labadmin'}),
            'ssh_port':     forms.NumberInput(attrs=_BASE),
            'ssh_key_path': forms.TextInput(attrs={**_BASE, 'placeholder': '/home/srv/.ssh/id_rsa'}),
            'make':         forms.TextInput(attrs={**_BASE, 'placeholder': 'Dell'}),
            'model':        forms.TextInput(attrs={**_BASE, 'placeholder': 'OptiPlex 7090'}),
            'serial_no':    forms.TextInput(attrs=_BASE),
            'cpu':          forms.TextInput(attrs={**_BASE, 'placeholder': 'Intel i7-11700'}),
            'ram_gb':       forms.NumberInput(attrs={**_BASE, 'placeholder': '16'}),
            'storage_gb':   forms.NumberInput(attrs={**_BASE, 'placeholder': '512'}),
            'os_type':      forms.Select(attrs=_SEL),
            'os_version':   forms.TextInput(attrs={**_BASE, 'placeholder': '22.04 LTS'}),
            'purchase_year':forms.NumberInput(attrs={**_BASE, 'placeholder': '2023'}),
            'location':     forms.Select(attrs=_SEL),
            'asset_tag':    forms.TextInput(attrs={**_BASE, 'placeholder': 'LAB-00123'}),
            'notes':        forms.Textarea(attrs=_TXT),
        }


class ShellForm(forms.Form):
    command   = forms.CharField(widget=forms.TextInput(attrs={
        **_BASE, 'placeholder': 'uptime  /  Get-Process',
        'autocomplete': 'off',
    }))
    backend   = forms.ChoiceField(choices=[
        ('paramiko', 'Paramiko (SSH)'),
        ('fabric',   'Fabric (SSH)'),
        ('netmiko',  'Netmiko (SSH)'),
    ], initial='paramiko', widget=forms.Select(attrs=_SEL))
    use_sudo  = forms.BooleanField(required=False, initial=False,
                                   label='Run with sudo (Linux only)')


class CreateRemoteUserForm(forms.Form):
    username  = forms.CharField(max_length=32,
        widget=forms.TextInput(attrs={**_BASE, 'placeholder': 'student01'}))
    full_name = forms.CharField(required=False, max_length=120,
        widget=forms.TextInput(attrs={**_BASE, 'placeholder': 'John Smith'}))
    password  = forms.CharField(min_length=4,
        widget=forms.PasswordInput(attrs=_BASE))
    create_home = forms.BooleanField(required=False, initial=True)


class FileBrowserForm(forms.Form):
    path = forms.CharField(initial='/home',
        widget=forms.TextInput(attrs={**_BASE, 'placeholder': '/home/student01'}))


class BulkScanForm(forms.Form):
    SCAN_CHOICES = [
        ('discover_users',  'Discover OS Users (all desktops)'),
        ('disk_usage',      'Disk Usage'),
        ('uptime',          'Uptime'),
        ('logged_users',    'Logged-in Users'),
        ('os_inventory',    'OS Inventory'),
        ('purge_user_home', 'Purge a User\'s Home Dir on All Desktops'),
        ('custom',          'Custom Command'),
    ]
    scan_type = forms.ChoiceField(choices=SCAN_CHOICES,
        widget=forms.Select(attrs=_SEL))
    parameter = forms.CharField(required=False,
        widget=forms.TextInput(attrs={**_BASE,
            'placeholder': 'username (for purge) or command'}))
    location = forms.ModelChoiceField(queryset=Location.objects.all(),
        required=False, empty_label='— All locations —',
        widget=forms.Select(attrs=_SEL))
    confirm  = forms.BooleanField(required=False,
        label='I understand destructive operations cannot be undone')
