"""
REST API for LabControl React SPA
==================================
All endpoints return JSON. No DRF dependency — pure Django views.
The SPA at / consumes these endpoints for dynamic, no-reload operation.
"""
import json
import os
import time
import traceback

from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Count, Q
from django.http import JsonResponse, StreamingHttpResponse
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.http import require_POST, require_GET

from . import availability, collectors, remote_ops
from .models import (
    Location, Desktop, DesktopUser, Application, InstallJob,
    ActivityLog, PowerLog, ShellCommandLog, FileOperationLog,
    AIConversation,
)

# Try importing PackageFile (may not exist in older schemas)
try:
    from .models import PackageFile
except ImportError:
    PackageFile = None


# ─── Auth ─────────────────────────────────────────────────────

@ensure_csrf_cookie
def api_csrf(request):
    """Return CSRF token cookie for SPA."""
    return JsonResponse({'ok': True})


@require_POST
def api_login(request):
    data = json.loads(request.body)
    user = authenticate(request, username=data.get('username'),
                        password=data.get('password'))
    if user:
        login(request, user)
        return JsonResponse({'ok': True, 'user': user.username})
    return JsonResponse({'ok': False, 'error': 'Invalid credentials'}, status=401)


def api_logout(request):
    logout(request)
    return JsonResponse({'ok': True})


def api_me(request):
    if request.user.is_authenticated:
        return JsonResponse({'ok': True, 'user': request.user.username,
                             'is_staff': request.user.is_staff})
    return JsonResponse({'ok': False}, status=401)


# ─── Dashboard / Stats ───────────────────────────────────────

@login_required
def api_dashboard(request):
    """All dashboard data in a single call."""
    desktops = Desktop.objects.select_related('location').all()
    locations = Location.objects.all()

    # Group desktops by location
    labs = []
    for loc in locations:
        loc_desktops = [d for d in desktops if d.location_id == loc.pk]
        if not loc_desktops:
            continue
        labs.append({
            'id': loc.pk,
            'name': loc.name,
            'building': loc.building,
            'room': loc.room,
            'floor': loc.floor,
            'color': loc.color,
            'desktops': [_desktop_dict(d) for d in loc_desktops],
        })

    # Unassigned desktops
    unassigned = [d for d in desktops if not d.location_id]

    # Stats
    total = len(desktops)
    online = sum(1 for d in desktops if d.status == 'online')
    offline = sum(1 for d in desktops if d.status == 'offline')

    # Recent activity
    recent = list(ActivityLog.objects.order_by('-created_at')[:10].values(
        'action', 'path', 'ip_addr', 'created_at', 'user__username'))

    return JsonResponse({
        'ok': True,
        'labs': labs,
        'unassigned': [_desktop_dict(d) for d in unassigned],
        'stats': {
            'total': total, 'online': online, 'offline': offline,
            'locations': len(locations),
        },
        'recent_activity': recent,
    })


def _desktop_dict(d):
    return {
        'id': d.pk,
        'device_name': d.device_name,
        'ip_address': d.ip_address,
        'mac_address': d.mac_address,
        'status': d.status,
        'os_type': d.os_type,
        'os_display': d.get_os_type_display(),
        'is_windows': d.is_windows,
        'make': d.make,
        'model': d.model,
        'cpu': d.cpu,
        'ram_gb': d.ram_gb,
        'storage_gb': d.storage_gb,
        'os_version': d.os_version,
        'last_seen': d.last_seen.isoformat() if d.last_seen else None,
        'last_ping_ms': d.last_ping_ms,
        'location_id': d.location_id,
        'location_name': d.location.name if d.location else None,
        'is_managed': d.is_managed,
    }


# ─── Ping ─────────────────────────────────────────────────────

@login_required
def api_ping_all(request):
    """Ping all managed desktops."""
    import concurrent.futures

    lab_id = request.GET.get('lab_id')
    qs = Desktop.objects.filter(is_managed=True)
    if lab_id:
        qs = qs.filter(location_id=lab_id)

    targets = list(qs)
    if not targets:
        return JsonResponse({'ok': True, 'count': 0, 'online': 0,
                             'offline': 0, 'results': []})

    # Parallel sweep: serial SSH-less pings still cost ~1 RTT+timeout each,
    # so a 60-desktop fleet took ~2 min before. ex.map preserves order.
    workers = min(len(targets), getattr(settings, 'SCAN_MAX_WORKERS', 30))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        probes = list(ex.map(
            lambda d: remote_ops.ping_host(d.ip_address, timeout=2), targets))

    now = timezone.now()
    results = []
    for d, res in zip(targets, probes):
        alive = res.get('alive', False)
        d.status = 'online' if alive else 'offline'
        d.last_ping_ms = res.get('rtt_ms')
        if alive:
            d.last_seen = now
        results.append({
            'id': d.pk, 'name': d.device_name, 'ip': d.ip_address,
            'alive': alive, 'rtt_ms': res.get('rtt_ms'),
            'status': d.status,
        })
    Desktop.objects.bulk_update(targets,
                                ['status', 'last_ping_ms', 'last_seen'])
    # History lives in the availability tables; Desktop.status stays as the
    # denormalised "right now" cache the older pages still read.
    availability.record_many(
        [(d, d.status, d.last_ping_ms) for d in targets], source='ping', now=now)
    return JsonResponse({
        'ok': True, 'count': len(results),
        'online': sum(1 for r in results if r['alive']),
        'offline': sum(1 for r in results if not r['alive']),
        'results': results,
    })


@login_required
def api_ping_one(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    res = remote_ops.ping_host(d.ip_address, timeout=2)
    alive = res.get('alive', False)
    d.status = 'online' if alive else 'offline'
    d.last_ping_ms = res.get('rtt_ms')
    if alive:
        d.last_seen = timezone.now()
    d.save(update_fields=['status', 'last_ping_ms', 'last_seen'])
    return JsonResponse({'ok': True, **res, 'status': d.status})


# ─── Power ────────────────────────────────────────────────────

@login_required
@require_POST
def api_power(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    data = json.loads(request.body) if request.body else {}
    action = data.get('action', 'shutdown')
    method = data.get('method', 'wol')  # wol | wol_directed | ipmi
    if action == 'wol':
        res = remote_ops.power_on(d, method=method)
    else:
        res = remote_ops.power_off(d, mode=action)
    PowerLog.objects.create(
        desktop=d, user=request.user, action=_power_log_action(action),
        success=res.get('success', False),
        detail=res.get('detail', '')[:500],
    )
    # Attach debugging suggestions on failure
    op = 'power_on' if action == 'wol' else action
    debug = remote_ops.suggest_debug(op, res, d) if not res.get('success') else []
    return JsonResponse({'ok': res.get('success', False), **res,
                         'debug_suggestions': debug})


# ─── Target resolution for fleet-wide / lab-wide / selected ops ───

#: Power actions the bulk endpoints accept. 'wol' routes to power_on();
#: everything else must be a remote_ops.POWER_OFF_MODES value. Nothing
#: outside this map is executable — an unknown action is rejected, never
#: coerced to a default (a coerced 'restart' would shut a lab down).
BULK_POWER_ACTIONS = ('wol', 'shutdown', 'reboot', 'suspend')


def _power_log_action(action):
    """
    Map an API power action to a valid PowerLog.ACTION_CHOICES value.

    The API calls it 'wol'; the model calls it 'wol_on'. Django does not
    validate choices on .create(), so the mismatch silently wrote rows whose
    get_action_display() fell back to the raw string on the Audit Logs page.
    """
    return 'wol_on' if action == 'wol' else action


def _resolve_targets(data):
    """
    Resolve a bulk-operation target set from a request payload.

    Accepts, in priority order:
      {'desktop_ids': [1,2,3]}  explicit selection
      {'lab_id': 4}             every managed desktop in one Location
      {'scope': 'all'}          the whole managed fleet

    Returns (queryset, label, error). Only one of queryset/error is meaningful.
    An explicitly empty ``desktop_ids`` is an error rather than a silent
    fleet-wide fan-out — "operate on nothing" must never become "operate on
    everything".
    """
    ids = data.get('desktop_ids')
    lab_id = data.get('lab_id')
    scope = (data.get('scope') or '').strip()

    base = Desktop.objects.filter(is_managed=True)

    if ids is not None:
        if not ids:
            return None, '', 'No desktops selected'
        return base.filter(pk__in=ids), f'{len(ids)} selected desktop(s)', None

    if lab_id:
        try:
            lab = Location.objects.get(pk=lab_id)
        except Location.DoesNotExist:
            return None, '', f'Lab {lab_id} not found'
        return base.filter(location_id=lab_id), f'lab "{lab.name}"', None

    if scope == 'all':
        return base, 'entire managed fleet', None

    return None, '', ('Specify desktop_ids, lab_id, or scope="all"')


@login_required
@require_POST
def api_bulk_power(request):
    """
    Power action across a selection, a whole lab, or the entire fleet.

    POST {action, desktop_ids|lab_id|scope, method?}
      action: wol | shutdown | reboot | suspend
      method: WoL delivery when action=wol (wol | wol_directed | ipmi)
    """
    data = json.loads(request.body)
    action = (data.get('action') or '').strip()
    method = data.get('method', 'wol')

    if action not in BULK_POWER_ACTIONS:
        return JsonResponse({'ok': False,
                             'error': f'Unsupported power action {action!r}. '
                                      f'Expected one of '
                                      f'{", ".join(BULK_POWER_ACTIONS)}'},
                            status=400)

    desktops, label, err = _resolve_targets(data)
    if err:
        return JsonResponse({'ok': False, 'error': err}, status=400)

    targets = list(desktops)
    if not targets:
        return JsonResponse({'ok': False,
                             'error': f'No managed desktops in {label}'},
                            status=400)

    def _runner(d):
        if action == 'wol':
            return remote_ops.power_on(d, method=method)
        return remote_ops.power_off(d, mode=action)

    # Fan out in parallel — serial SSH to a 40-machine lab takes minutes.
    raw = remote_ops.bulk_run(targets, _runner)

    by_name = {d.device_name: d for d in targets}
    op = 'power_on' if action == 'wol' else action
    results = []
    logs = []
    for r in raw:
        d = by_name.get(r.get('device_name'))
        success = r.get('success', False)
        if d is not None:
            logs.append(PowerLog(desktop=d, user=request.user,
                                 action=_power_log_action(action),
                                 success=success,
                                 detail=r.get('detail', '')[:500]))
        results.append({
            'id': d.pk if d else None,
            'device': r.get('device_name', ''),
            'ip': r.get('ip_address', ''),
            'success': success,
            'detail': r.get('detail', ''),
            'steps': r.get('steps', []),
            'debug_suggestions': (remote_ops.suggest_debug(op, r, d)
                                  if not success else []),
        })
    PowerLog.objects.bulk_create(logs)

    results.sort(key=lambda r: r['device'])
    ok = sum(1 for r in results if r['success'])
    return JsonResponse({'ok': True, 'action': action, 'target': label,
                         'results': results,
                         'summary': f'{ok}/{len(results)} succeeded'})


@login_required
@require_POST
def api_bulk_ping(request):
    """
    Live-status check across a selection, a whole lab, or the entire fleet.

    POST {desktop_ids|lab_id|scope} -> pings in parallel and persists
    status / last_ping_ms / last_seen, same as api_ping_all does for the
    whole fleet.
    """
    import concurrent.futures

    data = json.loads(request.body)
    desktops, label, err = _resolve_targets(data)
    if err:
        return JsonResponse({'ok': False, 'error': err}, status=400)

    targets = list(desktops)
    if not targets:
        return JsonResponse({'ok': False,
                             'error': f'No managed desktops in {label}'},
                            status=400)

    # Probe in parallel, but touch the ORM only from this thread: SQLite
    # locks under concurrent writers, and the worker pool would serialise
    # on it anyway. ex.map preserves input order, so probes[i] is targets[i].
    workers = min(len(targets), getattr(settings, 'SCAN_MAX_WORKERS', 30))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        probes = list(ex.map(
            lambda d: remote_ops.ping_host(d.ip_address, timeout=2), targets))

    now = timezone.now()
    results = []
    for d, res in zip(targets, probes):
        alive = res.get('alive', False)
        d.status = 'online' if alive else 'offline'
        d.last_ping_ms = res.get('rtt_ms')
        if alive:
            d.last_seen = now
        results.append({
            'id': d.pk, 'name': d.device_name, 'ip': d.ip_address,
            'alive': alive, 'rtt_ms': res.get('rtt_ms'), 'status': d.status,
        })
    Desktop.objects.bulk_update(
        targets, ['status', 'last_ping_ms', 'last_seen'])
    availability.record_many(
        [(d, d.status, d.last_ping_ms) for d in targets], source='ping', now=now)

    online = sum(1 for r in results if r['alive'])
    return JsonResponse({
        'ok': True, 'target': label, 'count': len(results),
        'online': online, 'offline': len(results) - online,
        'results': results,
        # Fleet-wide aggregates so any page can repaint its counters without
        # knowing which desktop belongs to which lab.
        'totals': _fleet_totals(),
        'by_lab': _lab_totals(),
        'steps': [f'ping sweep · {label}',
                  f'{online} online · {len(results) - online} offline'],
    })


def _fleet_totals():
    """Whole-fleet status counts, straight from the DB."""
    qs = Desktop.objects.filter(is_managed=True)
    return {
        'total':   qs.count(),
        'online':  qs.filter(status='online').count(),
        'offline': qs.filter(status='offline').count(),
        'unknown': qs.exclude(status__in=['online', 'offline']).count(),
    }


def _lab_totals():
    """{lab_id: {online, total}} for every Location, in one query."""
    rows = (Location.objects
            .annotate(total=Count('desktops',
                                  filter=Q(desktops__is_managed=True)),
                      online=Count('desktops',
                                   filter=Q(desktops__is_managed=True,
                                            desktops__status='online')))
            .values('pk', 'total', 'online'))
    return {str(r['pk']): {'online': r['online'], 'total': r['total']}
            for r in rows}


@login_required
@require_GET
def api_fleet_status(request):
    """
    Current status of every managed desktop, read straight from the DB.

    Deliberately does NOT ping — it is the cheap read that lets every open
    page stay in sync with whatever the last real sweep discovered. Pinging
    is what /api/bulk-ping/ is for; if every page polled by pinging, N open
    tabs would mean N ICMP sweeps of the whole fleet.
    """
    # Read from the availability event log, not Desktop.status — the event
    # log is the record of what was actually observed, and it carries "since
    # when", which a single denormalised cell cannot.
    rows = availability.live_status(managed_only=True)
    counts = {'online': 0, 'offline': 0, 'unknown': 0}
    by_lab = {}
    for r in rows:
        key = r['status'] if r['status'] in counts else 'unknown'
        counts[key] += 1
        if r['lab_id']:
            b = by_lab.setdefault(str(r['lab_id']), {'online': 0, 'total': 0})
            b['total'] += 1
            if r['status'] == 'online':
                b['online'] += 1
    return JsonResponse({
        'ok': True,
        'results': [{'id': r['id'], 'status': r['status'], 'rtt_ms': r['rtt_ms'],
                     'last_seen': r['since'], 'lab_id': r['lab_id']}
                    for r in rows],
        'totals': dict(counts, total=len(rows)),
        'by_lab': by_lab,
    })


# ─── Lab-scoped task + deployment operations ──────────────────

@login_required
@require_POST
def api_task_create(request):
    """
    Create a ScheduledTask, normally scoped to one lab.

    POST {name, task_type, lab_id?, custom_command?, cron_minute?,
          cron_hour?, cron_day_of_week?, idle_threshold_min?}

    NOTE: rows created here are definitions only. Nothing fires them until
    core/tasks.py + a Celery worker/beat exist (see CLAUDE.md §8), so the
    response says so rather than implying the schedule is live.
    """
    from .models import ScheduledTask

    data = json.loads(request.body)
    name = (data.get('name') or '').strip()
    task_type = (data.get('task_type') or '').strip()

    valid_types = [c[0] for c in ScheduledTask.TASK_CHOICES]
    if not name:
        return JsonResponse({'ok': False, 'error': 'Task name required'},
                            status=400)
    if task_type not in valid_types:
        return JsonResponse({'ok': False,
                             'error': f'Unknown task_type {task_type!r}. '
                                      f'Expected one of {", ".join(valid_types)}'},
                            status=400)

    lab = None
    if data.get('lab_id'):
        lab = Location.objects.filter(pk=data['lab_id']).first()
        if lab is None:
            return JsonResponse({'ok': False, 'error': 'Lab not found'},
                                status=400)

    task = ScheduledTask.objects.create(
        name=name[:200],
        task_type=task_type,
        lab=lab,
        custom_command=(data.get('custom_command') or '')[:4000],
        cron_minute=str(data.get('cron_minute', '0'))[:20],
        cron_hour=str(data.get('cron_hour', '0'))[:20],
        cron_day_of_week=str(data.get('cron_day_of_week', '*'))[:20],
        idle_threshold_min=int(data.get('idle_threshold_min') or 30),
        is_enabled=bool(data.get('is_enabled', True)),
    )
    return JsonResponse({
        'ok': True,
        'task': {'id': task.pk, 'name': task.name,
                 'task_display': task.get_task_type_display(),
                 'lab': lab.name if lab else None,
                 'cron': task.cron_display, 'is_enabled': task.is_enabled},
        'steps': [f'created task "{task.name}" ({task.get_task_type_display()})',
                  f'schedule {task.cron_display}'
                  + (f' · lab {lab.name}' if lab else ' · fleet-wide')],
        'detail': 'Task saved. Scheduling is inert until a Celery worker '
                  'and beat are running (see CLAUDE.md §8).',
    })


@login_required
@require_POST
def api_task_delete(request):
    """Delete ScheduledTask rows. POST {task_ids: [...]} or {task_id: n}."""
    from .models import ScheduledTask

    data = json.loads(request.body)
    ids = data.get('task_ids')
    if ids is None and data.get('task_id'):
        ids = [data['task_id']]
    if not ids:
        return JsonResponse({'ok': False, 'error': 'No tasks selected'},
                            status=400)

    qs = ScheduledTask.objects.filter(pk__in=ids)
    names = list(qs.values_list('name', flat=True))
    deleted, _ = qs.delete()
    if not names:
        return JsonResponse({'ok': False, 'error': 'No matching tasks'},
                            status=404)
    return JsonResponse({'ok': True, 'deleted': len(names),
                         'steps': [f'deleted task "{n}"' for n in names],
                         'detail': f'{len(names)} task(s) deleted'})


@login_required
@require_POST
def api_collect_macs(request):
    """
    Harvest each desktop's MAC over SSH and store it.

    Wake-on-LAN addresses a MAC, so a desktop with a blank mac_address can
    never be woken — power_on() refuses it outright. This fills the gap for a
    selection, a lab, or the whole fleet.

    POST {desktop_ids|lab_id|scope, overwrite: bool}
    overwrite=false (default) only fills blanks, so a re-run is cheap and
    will not churn MACs that are already correct.
    """
    data = json.loads(request.body)
    overwrite = bool(data.get('overwrite', False))

    desktops, label, err = _resolve_targets(data)
    if err:
        return JsonResponse({'ok': False, 'error': err}, status=400)

    targets = [d for d in desktops if overwrite or not d.mac_address]
    skipped = len(list(desktops)) - len(targets)
    if not targets:
        return JsonResponse({
            'ok': True, 'target': label, 'results': [], 'updated': 0,
            'summary': f'every desktop in {label} already has a MAC '
                       f'({skipped} skipped) — pass overwrite to refresh them',
            'steps': [f'nothing to do for {label}'],
        })

    raw = remote_ops.bulk_run(targets, remote_ops.get_mac_address)

    by_name = {d.device_name: d for d in targets}
    changed, results = [], []
    for r in raw:
        d = by_name.get(r.get('device_name'))
        mac = r.get('mac', '')
        if d is not None and mac and mac != d.mac_address:
            d.mac_address = mac
            changed.append(d)
        results.append({
            'id': d.pk if d else None,
            'device': r.get('device_name', ''),
            'mac': mac,
            'success': bool(mac),
            'detail': r.get('detail', '')[:200],
        })
    if changed:
        Desktop.objects.bulk_update(changed, ['mac_address'])

    results.sort(key=lambda x: x['device'])
    failed = [x for x in results if not x['success']]
    summary = (f'{len(changed)} MAC(s) stored, {len(failed)} unreachable '
               f'or unreadable, {skipped} already had one')
    return JsonResponse({
        'ok': True, 'target': label, 'results': results,
        'updated': len(changed), 'failed': len(failed), 'skipped': skipped,
        'summary': summary,
        'steps': [f'MAC harvest → {label}', summary]
                 + ([f'still unwakeable: '
                     + ', '.join(x['device'] for x in failed[:8])]
                    if failed else []),
    })


@login_required
@require_POST
def api_bulk_purge(request):
    """
    Clear one or more users' home / profile folders across a target set —
    the "make these desktops exam-ready" operation.

    POST {users: [...], desktop_ids|lab_id|scope, dry_run: bool}

    dry_run counts what would be deleted and removes nothing. Account names
    are validated by remote_ops (see USERNAME_RE) before any command is
    built; the account itself is never deleted, only its contents.
    """
    from .models import FileOperationLog

    data = json.loads(request.body)
    users = [str(u).strip() for u in (data.get('users') or []) if str(u).strip()]
    dry_run = bool(data.get('dry_run', False))

    if not users:
        return JsonResponse({'ok': False, 'error': 'No usernames given'},
                            status=400)

    # Refuse the whole request if any name is unsafe, rather than silently
    # purging the valid subset — a typo should stop the operator, not run.
    bad = [remote_ops._reject_user(u) for u in users]
    bad = [b for b in bad if b]
    if bad:
        return JsonResponse({'ok': False, 'error': '; '.join(bad[:3])},
                            status=400)

    desktops, label, err = _resolve_targets(data)
    if err:
        return JsonResponse({'ok': False, 'error': err}, status=400)

    targets = list(desktops)
    if not targets:
        return JsonResponse({'ok': False,
                             'error': f'No managed desktops in {label}'},
                            status=400)

    def _runner(d):
        per_user = []
        for u in users:
            per_user.append((u, remote_ops.purge_user_home(d, u,
                                                           dry_run=dry_run)))
        return {'success': all(r.get('success') for _, r in per_user),
                'per_user': per_user}

    raw = remote_ops.bulk_run(targets, _runner)

    by_name = {d.device_name: d for d in targets}
    logs, results, files = [], [], 0
    for r in raw:
        d = by_name.get(r.get('device_name'))
        if 'per_user' not in r:
            results.append({'device': r.get('device_name', ''), 'user': '—',
                            'success': False, 'files': 0,
                            'detail': r.get('detail', 'worker failed')})
            continue
        for u, res in r['per_user']:
            n = res.get('file_count') or 0
            files += n
            if d is not None:
                logs.append(FileOperationLog(
                    desktop=d, user=request.user,
                    operation='scan_home' if dry_run else 'purge_home',
                    target_path=('C:\\Users\\' if d.is_windows else '/home/') + u,
                    target_user=u[:64], file_count=n or None,
                    success=res.get('success', False),
                    detail=res.get('detail', '')[:2000]))
            results.append({
                'device': r.get('device_name', ''), 'user': u,
                'success': res.get('success', False), 'files': n,
                'detail': res.get('detail', '')[:300],
            })
    FileOperationLog.objects.bulk_create(logs)

    results.sort(key=lambda x: (x['device'], x['user']))
    ok = sum(1 for x in results if x['success'])
    verb = 'would clear' if dry_run else 'cleared'
    summary = (f'{ok}/{len(results)} home folder(s) {verb} '
               f'across {len(targets)} desktop(s)')
    return JsonResponse({
        'ok': True, 'dry_run': dry_run, 'target': label,
        'results': results, 'summary': summary,
        'file_total': files,
        'steps': [f'{"DRY RUN — " if dry_run else ""}purge '
                  f'{len(users)} user(s) → {label}', summary],
    })


@login_required
@require_POST
def api_bulk_deploy(request):
    """
    Install one or more catalog Applications across a selection, a lab, or
    the whole fleet.

    POST {app_ids: [...], desktop_ids|lab_id|scope}

    Each (desktop, app) pair runs remote_ops.run_command and writes an
    InstallJob row, mirroring views.app_install but fanned out in parallel
    and target-resolved like the other bulk endpoints.
    """
    data = json.loads(request.body)
    app_ids = data.get('app_ids') or []
    if not app_ids:
        return JsonResponse({'ok': False, 'error': 'No applications selected'},
                            status=400)

    desktops, label, err = _resolve_targets(data)
    if err:
        return JsonResponse({'ok': False, 'error': err}, status=400)

    targets = list(desktops)
    apps = list(Application.objects.filter(pk__in=app_ids, is_active=True))
    if not targets:
        return JsonResponse({'ok': False,
                             'error': f'No managed desktops in {label}'},
                            status=400)
    if not apps:
        return JsonResponse({'ok': False,
                             'error': 'No active applications matched'},
                            status=400)

    # 'uninstall' is what the exam-prep page uses to strip apps before an
    # exam. A catalog entry built from a custom script has no inverse, so it
    # reports a failure instead of silently doing nothing (or, worse,
    # falling through to the install command).
    uninstall = (data.get('mode') == 'uninstall')

    def _runner(d):
        """Run the selected apps on one desktop, sequentially."""
        per_app = []
        for app in apps:
            if uninstall:
                cmd = app.uninstall_command(d)
                if not cmd:
                    per_app.append((app, '', {
                        'success': False,
                        'detail': f'"{app.name}" has no uninstall command '
                                  f'(custom install script) — remove it manually'}))
                    continue
            else:
                cmd = app.install_command(d)
            res = remote_ops.run_command(d, cmd, use_sudo=not d.is_windows)
            per_app.append((app, cmd, res))
        return {'success': all(r.get('success') for _, _, r in per_app),
                'per_app': per_app}

    raw = remote_ops.bulk_run(targets, _runner)

    by_name = {d.device_name: d for d in targets}
    jobs, results = [], []
    for r in raw:
        d = by_name.get(r.get('device_name'))
        for app, cmd, res in r.get('per_app', []):
            if d is not None:
                jobs.append(InstallJob(
                    desktop=d, application=app, user=request.user,
                    command=cmd[:2000],
                    stdout=res.get('stdout', '')[:6000],
                    stderr=res.get('stderr', '')[:3000],
                    exit_code=res.get('exit_code'),
                    success=res.get('success', False),
                    duration_ms=res.get('duration_ms'),
                ))
            results.append({
                'device': r.get('device_name', ''), 'app': app.name,
                'success': res.get('success', False),
                'detail': (res.get('detail')
                           or res.get('stderr', '')[:300] or ''),
            })
        if 'per_app' not in r:
            # bulk_run caught an exception before any app ran
            results.append({'device': r.get('device_name', ''), 'app': '—',
                            'success': False,
                            'detail': r.get('detail', 'worker failed')})
    InstallJob.objects.bulk_create(jobs)

    results.sort(key=lambda x: (x['device'], x['app']))
    ok = sum(1 for r in results if r['success'])
    noun = 'removal' if uninstall else 'install'
    verb = 'remove' if uninstall else 'deploy'
    return JsonResponse({
        'ok': True, 'target': label, 'mode': 'uninstall' if uninstall else 'install',
        'results': results,
        'summary': f'{ok}/{len(results)} {noun}(s) succeeded '
                   f'across {len(targets)} desktop(s)',
        'steps': [f'{verb} {len(apps)} app(s) → {label}',
                  f'{ok}/{len(results)} succeeded'],
    })


# ─── Shell ────────────────────────────────────────────────────

@login_required
@require_POST
def api_shell(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    data = json.loads(request.body)
    cmd = data.get('command', '').strip()
    if not cmd:
        return JsonResponse({'ok': False, 'error': 'Empty command'})
    backend = data.get('backend', 'paramiko')
    use_sudo = data.get('use_sudo', False)
    res = remote_ops.run_command(d, cmd, backend=backend, use_sudo=use_sudo)
    ShellCommandLog.objects.create(
        desktop=d, user=request.user, command=cmd[:500],
        stdout=res.get('stdout', '')[:8000],
        stderr=res.get('stderr', '')[:4000],
        exit_code=res.get('exit_code'),
        duration_ms=res.get('duration_ms'),
        backend=res.get('backend', backend)[:20],
    )
    return JsonResponse({'ok': res.get('success', False), **res})


# ─── Bulk Shell ───────────────────────────────────────────────

@login_required
@require_POST
def api_bulk_shell(request):
    data = json.loads(request.body)
    desktop_ids = data.get('desktop_ids', [])
    command = data.get('command', '').strip()
    if not desktop_ids or not command:
        return JsonResponse({'ok': False, 'error': 'Need desktop_ids and command'})
    desktops = Desktop.objects.filter(pk__in=desktop_ids, is_managed=True)
    results = []
    for d in desktops:
        try:
            r = remote_ops.run_command(d, command, use_sudo=not d.is_windows)
            r['device'] = d.device_name
            r['id'] = d.pk
            results.append(r)
        except Exception as e:
            results.append({'device': d.device_name, 'id': d.pk,
                           'success': False, 'detail': str(e)})
    return JsonResponse({'ok': True, 'results': results})


# ─── File Browser (SFTP) ─────────────────────────────────────

@login_required
def api_files(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    path = request.GET.get('path', d.default_browse_path)
    res = remote_ops.sftp_list_dir(d, path)
    return JsonResponse({'ok': res.get('success', False), **res})


# ─── Lab Files (shared per-lab file storage) ─────────────────

LAB_FILES_ROOT = os.path.join(settings.MEDIA_ROOT, 'lab_files')


@login_required
def api_lab_files(request, lab_id):
    """List files shared to a specific lab."""
    loc = get_object_or_404(Location, pk=lab_id)
    lab_dir = os.path.join(LAB_FILES_ROOT, str(lab_id))
    os.makedirs(lab_dir, exist_ok=True)

    files = []
    for fname in os.listdir(lab_dir):
        fpath = os.path.join(lab_dir, fname)
        if os.path.isfile(fpath):
            stat = os.stat(fpath)
            files.append({
                'name': fname,
                'size': stat.st_size,
                'size_display': _size_display(stat.st_size),
                'modified': time.ctime(stat.st_mtime),
            })
    files.sort(key=lambda f: f['name'])
    return JsonResponse({
        'ok': True, 'lab_id': lab_id, 'lab_name': loc.name,
        'files': files, 'path': lab_dir,
    })


@login_required
@require_POST
def api_lab_upload(request, lab_id):
    """Upload a file to a lab's shared directory. Supports large files."""
    loc = get_object_or_404(Location, pk=lab_id)
    lab_dir = os.path.join(LAB_FILES_ROOT, str(lab_id))
    os.makedirs(lab_dir, exist_ok=True)

    f = request.FILES.get('file')
    if not f:
        return JsonResponse({'ok': False, 'error': 'No file'})

    dest = os.path.join(lab_dir, f.name)
    with open(dest, 'wb') as out:
        for chunk in f.chunks(chunk_size=1024 * 1024):  # 1 MB chunks
            out.write(chunk)

    return JsonResponse({
        'ok': True,
        'name': f.name,
        'size': f.size,
        'size_display': _size_display(f.size),
    })


@login_required
@require_POST
def api_lab_deploy_file(request, lab_id):
    """Copy a lab file to selected desktops via SFTP."""
    data = json.loads(request.body)
    filename = data.get('filename', '')
    desktop_ids = data.get('desktop_ids', [])

    lab_dir = os.path.join(LAB_FILES_ROOT, str(lab_id))
    local_path = os.path.join(lab_dir, filename)
    if not os.path.isfile(local_path):
        return JsonResponse({'ok': False, 'error': f'File not found: {filename}'})

    desktops = Desktop.objects.filter(pk__in=desktop_ids, is_managed=True)
    results = []
    for d in desktops:
        try:
            if d.is_windows:
                remote_path = f'C:\\Temp\\{filename}'
                remote_ops.run_command(d, 'mkdir C:\\Temp 2>nul & echo ok')
            else:
                remote_path = f'/tmp/{filename}'
            client = remote_ops._ssh_client(
                d.ip_address, d.ssh_username,
                password=d.ssh_password or None,
                key_path=d.ssh_key_path or None,
                port=d.ssh_port,
            )
            sftp = client.open_sftp()
            sftp.put(local_path, remote_path)
            sftp.close()
            client.close()
            results.append({'id': d.pk, 'device': d.device_name,
                           'success': True, 'detail': f'→ {remote_path}'})
        except Exception as e:
            results.append({'id': d.pk, 'device': d.device_name,
                           'success': False, 'detail': str(e)})

    return JsonResponse({'ok': True, 'results': results})


def _size_display(size):
    if size > 1_073_741_824:
        return f'{size / 1_073_741_824:.1f} GB'
    if size > 1_048_576:
        return f'{size / 1_048_576:.1f} MB'
    if size > 1024:
        return f'{size / 1024:.1f} KB'
    return f'{size} B'


# ─── AI Assistant ─────────────────────────────────────────────

@login_required
@require_POST
def api_ai_ask(request):
    from . import ai_agent
    data = json.loads(request.body)
    prompt = data.get('prompt', '').strip()
    if not prompt:
        return JsonResponse({'ok': False, 'error': 'Empty prompt'})
    result = ai_agent.ask(prompt)
    AIConversation.objects.create(
        user=request.user, prompt=prompt,
        response=result.get('response', ''),
        success=result.get('ok', False),
        model=result.get('model', ''),
        duration_ms=result.get('duration_ms'),
        error=result.get('error', '')[:500],
    )
    return JsonResponse(result)


@login_required
def api_ai_history(request):
    convs = AIConversation.objects.filter(user=request.user)[:20]
    return JsonResponse({'ok': True, 'conversations': [
        {'id': c.pk, 'prompt': c.prompt, 'response': c.response,
         'success': c.success, 'model': c.model,
         'duration_ms': c.duration_ms, 'error': c.error,
         'created_at': c.created_at.isoformat()}
        for c in convs
    ]})


@login_required
@require_POST
def api_ai_read_logs(request):
    """Read recent error logs and ask AI for diagnosis."""
    from . import ai_agent

    data = json.loads(request.body)
    desktop_id = data.get('desktop_id')
    log_type = data.get('log_type', 'shell')  # shell, power, activity

    errors = []
    if log_type == 'shell':
        qs = ShellCommandLog.objects.filter(exit_code__gt=0).order_by('-created_at')[:10]
        if desktop_id:
            qs = qs.filter(desktop_id=desktop_id)
        for log in qs:
            errors.append(f"[{log.created_at}] {log.desktop.device_name}: "
                         f"$ {log.command}\nExit {log.exit_code}\n"
                         f"stderr: {log.stderr[:300]}")
    elif log_type == 'power':
        qs = PowerLog.objects.filter(success=False).order_by('-created_at')[:10]
        if desktop_id:
            qs = qs.filter(desktop_id=desktop_id)
        for log in qs:
            errors.append(f"[{log.created_at}] {log.desktop.device_name}: "
                         f"{log.action} FAILED: {log.detail[:300]}")

    if not errors:
        return JsonResponse({'ok': True, 'response': 'No errors found in recent logs.',
                             'error_count': 0})

    combined = "\n---\n".join(errors)
    prompt = (f"Analyze these {len(errors)} recent error logs from my lab "
              f"management system and provide: 1) Root cause for each, "
              f"2) Fix commands, 3) Prevention recommendations:\n\n{combined}")

    result = ai_agent.ask(prompt)
    result['error_count'] = len(errors)
    return JsonResponse(result)


# ─── AI Save App ──────────────────────────────────────────────

@login_required
@require_POST
def api_ai_save_app(request):
    data = json.loads(request.body)
    app_data = data.get('app', {})
    if not app_data.get('name'):
        return JsonResponse({'ok': False, 'error': 'Missing app name'})
    app, created = Application.objects.update_or_create(
        name=app_data['name'],
        defaults={
            'description':    app_data.get('description', ''),
            'category':       app_data.get('category', 'other'),
            'linux_pkg':      app_data.get('linux_pkg', ''),
            'linux_method':   app_data.get('linux_method', 'apt'),
            'windows_pkg':    app_data.get('windows_pkg', ''),
            'windows_method': app_data.get('windows_method', 'winget'),
            'custom_linux':   app_data.get('custom_linux', ''),
            'custom_windows': app_data.get('custom_windows', ''),
            'is_active':      True,
        })
    return JsonResponse({'ok': True, 'created': created, 'app_id': app.pk})


# ─── Logs ─────────────────────────────────────────────────────

@login_required
def api_logs(request):
    log_type = request.GET.get('type', 'activity')
    desktop_id = request.GET.get('desktop_id')
    limit = min(int(request.GET.get('limit', 50)), 200)

    if log_type == 'shell':
        qs = ShellCommandLog.objects.select_related('desktop', 'user')
        if desktop_id:
            qs = qs.filter(desktop_id=desktop_id)
        logs = [{'type': 'shell', 'desktop': l.desktop.device_name,
                 'command': l.command, 'exit_code': l.exit_code,
                 'stdout': l.stdout[:500], 'stderr': l.stderr[:500],
                 'user': l.user.username if l.user else '',
                 'created_at': l.created_at.isoformat()}
                for l in qs[:limit]]
    elif log_type == 'power':
        qs = PowerLog.objects.select_related('desktop', 'user')
        if desktop_id:
            qs = qs.filter(desktop_id=desktop_id)
        logs = [{'type': 'power', 'desktop': l.desktop.device_name,
                 'action': l.action, 'success': l.success,
                 'detail': l.detail[:300],
                 'user': l.user.username if l.user else '',
                 'created_at': l.created_at.isoformat()}
                for l in qs[:limit]]
    else:
        qs = ActivityLog.objects.select_related('user')
        logs = [{'type': 'activity', 'action': l.action, 'path': l.path,
                 'user': l.user.username if l.user else '',
                 'ip': l.ip_addr,
                 'created_at': l.created_at.isoformat()}
                for l in qs[:limit]]

    return JsonResponse({'ok': True, 'logs': logs, 'count': len(logs)})


# ─── Live Telemetry via SSH ───────────────────────────────────

@login_required
def api_telemetry(request, pk):
    """Collect live CPU, RAM, disk, network stats from a desktop via SSH."""
    d = get_object_or_404(Desktop, pk=pk)
    result = {'ok': False, 'id': d.pk, 'name': d.device_name,
              'ip': d.ip_address, 'is_windows': d.is_windows}

    if d.is_windows:
        cmd = (
            'powershell -NoProfile -Command "'
            '$cpu = (Get-CimInstance Win32_Processor).LoadPercentage;'
            '$os = Get-CimInstance Win32_OperatingSystem;'
            '$mem_total = [math]::Round($os.TotalVisibleMemorySize/1MB,1);'
            '$mem_used = [math]::Round(($os.TotalVisibleMemorySize - $os.FreePhysicalMemory)/1MB,1);'
            '$disk = Get-CimInstance Win32_LogicalDisk -Filter \\\"DriveType=3\\\" | Select DeviceID,'
            '@{N=\\\"SizeGB\\\";E={[math]::Round($_.Size/1GB,1)}},'
            '@{N=\\\"FreeGB\\\";E={[math]::Round($_.FreeSpace/1GB,1)}};'
            '$net = Get-NetAdapterStatistics | Select Name,ReceivedBytes,SentBytes;'
            'Write-Output \\\"CPU:$cpu\\\";'
            'Write-Output \\\"MEM:$mem_used/$mem_total\\\";'
            'foreach($dr in $disk){Write-Output \\\"DISK:$($dr.DeviceID)|$($dr.SizeGB)|$($dr.FreeGB)\\\"};'
            'foreach($n in $net){Write-Output \\\"NET:$($n.Name)|$($n.ReceivedBytes)|$($n.SentBytes)\\\"}'
            '"'
        )
    else:
        cmd = (
            "echo CPU:$(top -bn1 | grep 'Cpu(s)' | awk '{print 100-$8}');"
            "echo MEM:$(free -g | awk '/Mem:/{print $3\"/\"int($2)}');"
            "df -BG --output=target,size,avail / | tail -1 | "
            "  awk '{gsub(/G/,\"\"); print \"DISK:/|\"$2\"|\"$3}';"
            "cat /proc/net/dev | grep -E 'eth|ens|enp|wlan' | head -1 | "
            "  awk -F: '{split($2,a); print \"NET:\"$1\"|\"a[1]\"|\"a[9]}'"
        )

    res = remote_ops.run_command(d, cmd)
    if not res.get('success'):
        result['error'] = res.get('detail') or res.get('stderr', 'SSH failed')
        return JsonResponse(result)

    # Parse output
    telem = {'cpu': 0, 'mem_used_gb': 0, 'mem_total_gb': 0, 'mem_pct': 0,
             'disks': [], 'net': []}
    for line in res.get('stdout', '').strip().splitlines():
        line = line.strip()
        if line.startswith('CPU:'):
            try:
                telem['cpu'] = round(float(line.split(':',1)[1].strip()), 1)
            except (ValueError, IndexError):
                pass
        elif line.startswith('MEM:'):
            try:
                parts = line.split(':',1)[1].strip().split('/')
                telem['mem_used_gb'] = round(float(parts[0]), 1)
                telem['mem_total_gb'] = round(float(parts[1]), 1)
                if telem['mem_total_gb'] > 0:
                    telem['mem_pct'] = round(telem['mem_used_gb'] / telem['mem_total_gb'] * 100, 1)
            except (ValueError, IndexError):
                pass
        elif line.startswith('DISK:'):
            try:
                parts = line.split(':',1)[1].strip().split('|')
                total = float(parts[1])
                free = float(parts[2])
                telem['disks'].append({
                    'mount': parts[0].strip(),
                    'total_gb': round(total, 1),
                    'free_gb': round(free, 1),
                    'used_gb': round(total - free, 1),
                    'pct': round((total - free) / total * 100, 1) if total > 0 else 0,
                })
            except (ValueError, IndexError):
                pass
        elif line.startswith('NET:'):
            try:
                parts = line.split(':',1)[1].strip().split('|')
                telem['net'].append({
                    'iface': parts[0].strip(),
                    'rx_bytes': int(parts[1].strip()),
                    'tx_bytes': int(parts[2].strip()),
                })
            except (ValueError, IndexError):
                pass

    result['ok'] = True
    result['telemetry'] = telem
    result['duration_ms'] = res.get('duration_ms', 0)
    return JsonResponse(result)


@login_required
def api_telemetry_batch(request):
    """Collect telemetry from multiple desktops in parallel."""
    import concurrent.futures
    lab_id = request.GET.get('lab_id')
    qs = Desktop.objects.filter(is_managed=True, status='online')
    if lab_id:
        qs = qs.filter(location_id=lab_id)

    def fetch_one(d):
        try:
            if d.is_windows:
                cmd = (
                    'powershell -NoProfile -Command "'
                    '$cpu = (Get-CimInstance Win32_Processor).LoadPercentage;'
                    '$os = Get-CimInstance Win32_OperatingSystem;'
                    '$mem_total = [math]::Round($os.TotalVisibleMemorySize/1MB,1);'
                    '$mem_used = [math]::Round(($os.TotalVisibleMemorySize-$os.FreePhysicalMemory)/1MB,1);'
                    'Write-Output \\\"CPU:$cpu\\\";'
                    'Write-Output \\\"MEM:$mem_used/$mem_total\\\""'
                )
            else:
                cmd = (
                    "echo CPU:$(top -bn1 | grep 'Cpu(s)' | awk '{print 100-$8}');"
                    "echo MEM:$(free -g | awk '/Mem:/{print $3\"/\"int($2)}')"
                )
            res = remote_ops.run_command(d, cmd)
            cpu = 0; mem_pct = 0; mem_used = 0; mem_total = 0
            if res.get('success'):
                for line in res.get('stdout','').splitlines():
                    if line.startswith('CPU:'):
                        try: cpu = round(float(line.split(':',1)[1]),1)
                        except: pass
                    elif line.startswith('MEM:'):
                        try:
                            p = line.split(':',1)[1].split('/')
                            mem_used = round(float(p[0]),1)
                            mem_total = round(float(p[1]),1)
                            if mem_total > 0: mem_pct = round(mem_used/mem_total*100,1)
                        except: pass
            ping_res = remote_ops.ping_host(d.ip_address, timeout=2)
            return {
                'id': d.pk, 'name': d.device_name, 'ip': d.ip_address,
                'is_windows': d.is_windows, 'status': 'online',
                'cpu': cpu, 'mem_pct': mem_pct,
                'mem_used_gb': mem_used, 'mem_total_gb': mem_total,
                'rtt_ms': ping_res.get('rtt_ms'),
                'ok': True,
            }
        except Exception as e:
            return {'id': d.pk, 'name': d.device_name, 'ip': d.ip_address,
                    'ok': False, 'error': str(e), 'status': 'error'}

    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
        for r in ex.map(fetch_one, list(qs)):
            results.append(r)

    return JsonResponse({'ok': True, 'results': results, 'count': len(results)})


# ─── File Manager (SFTP browse/view/edit/download/upload) ─────

@login_required
def api_file_read(request, pk):
    """Read a remote text file for viewing/editing."""
    d = get_object_or_404(Desktop, pk=pk)
    path = request.GET.get('path', '')
    if not path:
        return JsonResponse({'ok': False, 'error': 'No path'})
    res = remote_ops.sftp_read_file(d, path, max_bytes=512*1024)
    FileOperationLog.objects.create(
        desktop=d, user=request.user, operation='view',
        path=path[:500], success=res.get('success', False),
        detail=res.get('detail', '')[:300])
    return JsonResponse({'ok': res.get('success', False), **res})


@login_required
@require_POST
def api_file_write(request, pk):
    """Save edited content back to a remote file."""
    d = get_object_or_404(Desktop, pk=pk)
    data = json.loads(request.body)
    path = data.get('path', '')
    content = data.get('content', '')
    if not path:
        return JsonResponse({'ok': False, 'error': 'No path'})
    res = remote_ops.sftp_write_file(d, path, content)
    FileOperationLog.objects.create(
        desktop=d, user=request.user, operation='edit',
        path=path[:500], success=res.get('success', False),
        detail=res.get('detail', '')[:300])
    return JsonResponse({'ok': res.get('success', False), **res})


@login_required
def api_file_download(request, pk):
    """Stream a remote file to the browser as a download."""
    from django.http import HttpResponse
    d = get_object_or_404(Desktop, pk=pk)
    path = request.GET.get('path', '')
    if not path:
        return JsonResponse({'ok': False, 'error': 'No path'}, status=400)
    data, err = remote_ops.sftp_download_bytes(d, path)
    if err:
        return JsonResponse({'ok': False, 'error': err}, status=400)
    filename = path.replace('\\', '/').rstrip('/').split('/')[-1] or 'download'
    FileOperationLog.objects.create(
        desktop=d, user=request.user, operation='download',
        path=path[:500], success=True, detail=f'{len(data)} bytes')
    resp = HttpResponse(data, content_type='application/octet-stream')
    resp['Content-Disposition'] = f'attachment; filename="{filename}"'
    return resp


@login_required
@require_POST
def api_file_upload(request, pk):
    """Upload a file from the browser to a remote directory via SFTP."""
    d = get_object_or_404(Desktop, pk=pk)
    remote_dir = request.POST.get('path', d.default_browse_path)
    f = request.FILES.get('file')
    if not f:
        return JsonResponse({'ok': False, 'error': 'No file'})
    sep = '\\' if d.is_windows else '/'
    remote_path = remote_dir.rstrip('/\\') + sep + f.name
    res = remote_ops.sftp_upload_fileobj(d, f, remote_path)
    FileOperationLog.objects.create(
        desktop=d, user=request.user, operation='upload',
        path=remote_path[:500], success=res.get('success', False),
        detail=f'{f.size} bytes')
    return JsonResponse({'ok': res.get('success', False), **res})


@login_required
@require_POST
def api_file_delete(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    data = json.loads(request.body)
    path = data.get('path', '')
    res = remote_ops.sftp_delete_file(d, path)
    FileOperationLog.objects.create(
        desktop=d, user=request.user, operation='delete',
        path=path[:500], success=res.get('success', False),
        detail=res.get('detail', '')[:300])
    return JsonResponse({'ok': res.get('success', False), **res})


@login_required
@require_POST
def api_file_mkdir(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    data = json.loads(request.body)
    parent = data.get('path', d.default_browse_path)
    name = data.get('name', '')
    sep = '\\' if d.is_windows else '/'
    full = parent.rstrip('/\\') + sep + name
    res = remote_ops.sftp_mkdir(d, full)
    return JsonResponse({'ok': res.get('success', False), **res})


# ─── Session & Usage Tracking API ─────────────────────────────

@login_required
def api_sessions(request):
    """Current + recent login sessions. ?desktop_id=X ?active=1"""
    from .models import LoginSession
    qs = LoginSession.objects.select_related('desktop')
    if request.GET.get('desktop_id'):
        qs = qs.filter(desktop_id=request.GET['desktop_id'])
    if request.GET.get('active') == '1':
        qs = qs.filter(is_active=True)
    limit = min(int(request.GET.get('limit', 100)), 500)
    sessions = [{
        'id': s.pk, 'desktop': s.desktop.device_name, 'desktop_id': s.desktop_id,
        'username': s.username, 'login_time': s.login_time.isoformat(),
        'last_seen': s.last_seen.isoformat(),
        'logout_time': s.logout_time.isoformat() if s.logout_time else None,
        'is_active': s.is_active, 'duration': s.duration_display,
        'idle_seconds': s.idle_seconds, 'tty': s.tty, 'source_ip': s.source_ip,
    } for s in qs[:limit]]
    return JsonResponse({'ok': True, 'sessions': sessions, 'count': len(sessions)})


@login_required
def api_usage_stats(request):
    """Usage aggregates for capacity planning."""
    from .models import LoginSession, Desktop
    from django.db.models import Count, Avg
    # Most-used desktops (by session count, last 30 days)
    cutoff = timezone.now() - timezone.timedelta(days=30)
    by_desktop = list(LoginSession.objects.filter(login_time__gte=cutoff)
        .values('desktop__device_name')
        .annotate(sessions=Count('id'))
        .order_by('-sessions')[:20])
    # Most active users
    by_user = list(LoginSession.objects.filter(login_time__gte=cutoff)
        .values('username')
        .annotate(sessions=Count('id'))
        .order_by('-sessions')[:20])
    return JsonResponse({'ok': True, 'by_desktop': by_desktop, 'by_user': by_user})


# ─── Software Inventory API ───────────────────────────────────

@login_required
def api_software_inventory(request):
    """Fleet software inventory. ?desktop_id=X or ?search=name"""
    from .models import InstalledSoftware
    qs = InstalledSoftware.objects.select_related('desktop')
    if request.GET.get('desktop_id'):
        qs = qs.filter(desktop_id=request.GET['desktop_id'])
    if request.GET.get('search'):
        qs = qs.filter(name__icontains=request.GET['search'])
    limit = min(int(request.GET.get('limit', 200)), 1000)
    items = [{'desktop': s.desktop.device_name, 'name': s.name,
              'version': s.version, 'publisher': s.publisher, 'source': s.source}
             for s in qs[:limit]]
    return JsonResponse({'ok': True, 'software': items, 'count': len(items)})


@login_required
def api_compliance(request):
    """Software compliance violations across the fleet."""
    from .models import Desktop
    violations = []
    for d in Desktop.objects.filter(is_managed=True):
        r = collectors.check_software_compliance(d)
        if r['violations']:
            violations.append({'desktop': d.device_name, 'issues': r['violations']})
    return JsonResponse({'ok': True, 'violations': violations})


# ─── Drift API ────────────────────────────────────────────────

@login_required
def api_drift_reports(request):
    """Latest drift report per desktop."""
    from .models import DriftReport, Desktop
    reports = []
    for d in Desktop.objects.filter(is_managed=True):
        latest = d.drift_reports.first()
        if latest:
            reports.append({
                'desktop': d.device_name, 'has_drift': latest.has_drift,
                'drift_count': latest.drift_count,
                'checked_at': latest.checked_at.isoformat(),
                'missing_packages': json.loads(latest.missing_packages or '[]'),
                'stopped_services': json.loads(latest.stopped_services or '[]'),
                'changed_files': json.loads(latest.changed_files or '[]'),
            })
    return JsonResponse({'ok': True, 'reports': reports})


# ─── Reservation API ──────────────────────────────────────────

@login_required
def api_reservations(request):
    from .models import Reservation
    qs = Reservation.objects.select_related('desktop', 'reserved_by').exclude(
        status='cancelled')
    if request.GET.get('desktop_id'):
        qs = qs.filter(desktop_id=request.GET['desktop_id'])
    if request.GET.get('upcoming') == '1':
        qs = qs.filter(end_time__gte=timezone.now())
    items = [{
        'id': r.pk, 'desktop': r.desktop.device_name, 'desktop_id': r.desktop_id,
        'user': r.reserved_by.username, 'purpose': r.purpose,
        'start': r.start_time.isoformat(), 'end': r.end_time.isoformat(),
        'status': r.status, 'hours': r.duration_hours,
    } for r in qs[:200]]
    return JsonResponse({'ok': True, 'reservations': items})


@login_required
@require_POST
def api_reserve(request):
    """Create a reservation, checking for conflicts."""
    from .models import Reservation, Desktop
    from django.utils.dateparse import parse_datetime
    data = json.loads(request.body)
    desktop = get_object_or_404(Desktop, pk=data.get('desktop_id'))
    start = parse_datetime(data.get('start_time'))
    end = parse_datetime(data.get('end_time'))
    if not start or not end or end <= start:
        return JsonResponse({'ok': False, 'error': 'Invalid time range'})

    # Conflict check
    conflicts = Reservation.objects.filter(
        desktop=desktop, status__in=['confirmed', 'active', 'pending'],
        start_time__lt=end, end_time__gt=start)
    if conflicts.exists():
        c = conflicts.first()
        return JsonResponse({'ok': False,
            'error': f'Conflict: reserved by {c.reserved_by.username} '
                     f'from {c.start_time:%H:%M} to {c.end_time:%H:%M}'})

    r = Reservation.objects.create(
        desktop=desktop, reserved_by=request.user,
        purpose=data.get('purpose', ''), start_time=start, end_time=end)
    return JsonResponse({'ok': True, 'reservation_id': r.pk})


# ─── Scheduled Tasks API ──────────────────────────────────────

@login_required
def api_scheduled_tasks(request):
    """List ScheduledTask definitions, optionally narrowed to one lab."""
    from .models import ScheduledTask
    qs = ScheduledTask.objects.select_related('lab').all()
    lab_id = request.GET.get('lab_id')
    if lab_id:
        qs = qs.filter(lab_id=lab_id)
    tasks = [{
        'id': t.pk, 'name': t.name, 'task_type': t.task_type,
        'task_display': t.get_task_type_display(),
        'lab': t.lab.name if t.lab else None,
        'lab_id': t.lab_id,
        'cron': t.cron_display, 'is_enabled': t.is_enabled,
        'last_run': t.last_run.isoformat() if t.last_run else None,
        'last_result': t.last_result[:200],
    } for t in qs]
    return JsonResponse({
        'ok': True, 'tasks': tasks,
        'task_types': [{'value': v, 'label': l}
                       for v, l in ScheduledTask.TASK_CHOICES],
        # Surfaced so the UI can warn instead of implying these fire.
        'scheduler_running': False,
    })


# ─── ARP Neighbor Discovery ───────────────────────────────────

@login_required
def api_neighbors(request):
    """
    Discover LAN neighbors via ARP.
    ?desktop_id=X  → scan runs remotely on that desktop over SSH.
    (omitted)      → scan runs locally on the LabControl server.
    ?sweep=0       → skip the ping-sweep (read existing ARP cache only).
    Returns graph nodes/edges + accessible table rows.
    """
    from .models import Desktop
    desktop_id = request.GET.get('desktop_id')
    sweep = request.GET.get('sweep', '1') != '0'
    subnet = request.GET.get('subnet')

    desktop = None
    if desktop_id:
        desktop = get_object_or_404(Desktop, pk=desktop_id)

    scan = remote_ops.arp_scan(desktop=desktop, sweep=sweep, subnet=subnet)
    if not scan.get('ok'):
        return JsonResponse({'ok': False, 'error': scan.get('error', 'scan failed'),
                             'source': scan.get('source'), 'host': scan.get('host')})

    # Persist to the deduplicated host registry + sighting log
    from . import collectors
    rec = collectors.record_discovery(scan)

    # Cross-reference discovered IPs/MACs against known desktops
    known_by_ip = {d.ip_address: d for d in Desktop.objects.all()}
    known_by_mac = {(d.mac_address or '').lower(): d
                    for d in Desktop.objects.all() if d.mac_address}

    center = scan['host']
    nodes = [{'id': 'host', 'label': center, 'type': 'scanner',
              'ip': desktop.ip_address if desktop else 'server', 'mac': '', 'vendor': ''}]
    edges = []
    rows = []

    for i, n in enumerate(scan['neighbors']):
        known = known_by_ip.get(n['ip']) or known_by_mac.get(n['mac'])
        label = known.device_name if known else (n['vendor'] or n['ip'])
        node_type = 'managed' if known else 'unknown'
        nid = f'n{i}'
        nodes.append({
            'id': nid, 'label': label, 'type': node_type,
            'ip': n['ip'], 'mac': n['mac'],
            'vendor': n['vendor'], 'iface': n.get('iface', ''),
            'device_name': known.device_name if known else '',
            'os': (known.get_os_type_display() if known else ''),
        })
        edges.append({'from': 'host', 'to': nid})
        rows.append({
            'ip': n['ip'], 'mac': n['mac'],
            'vendor': n['vendor'] or 'Unknown',
            'iface': n.get('iface', '') or '—',
            'status': 'Managed desktop' if known else 'Unmanaged device',
            'device_name': known.device_name if known else '',
        })

    # Sort table rows by IP (numeric)
    def ip_key(r):
        try: return tuple(int(o) for o in r['ip'].split('.'))
        except: return (0,0,0,0)
    rows.sort(key=ip_key)

    return JsonResponse({
        'ok': True,
        'source': scan['source'],       # 'local' or 'remote'
        'host': center,
        'count': scan['count'],
        'managed_count': sum(1 for r in rows if r['device_name']),
        'graph': {'nodes': nodes, 'edges': edges},
        'table': rows,
        'recorded': rec,                 # dedup persistence summary
    })


# ─── Deduplicated Host Registry ───────────────────────────────

@login_required
def api_hosts(request):
    """
    The unique, deduplicated host list from the discovery registry.
    ?category=iot   → filter to one category
    Grouped by category with counts.
    """
    from .models import DiscoveredHost
    qs = DiscoveredHost.objects.select_related('desktop').all()
    cat = request.GET.get('category')
    if cat:
        qs = qs.filter(category=cat)

    hosts = [{
        'id': h.pk, 'mac': h.mac, 'ip': h.ip, 'vendor': h.vendor,
        'category': h.category, 'category_display': h.get_category_display(),
        'hostname': h.hostname,
        'device_name': h.desktop.device_name if h.desktop else '',
        'seen_local': h.seen_local, 'seen_remote': h.seen_remote,
        'discovered_via': h.discovered_via,
        'times_seen': h.times_seen,
        'first_seen': h.first_seen.isoformat(),
        'last_seen': h.last_seen.isoformat(),
    } for h in qs]

    # Category counts across the whole registry
    from django.db.models import Count
    counts = {row['category']: row['n'] for row in
              DiscoveredHost.objects.values('category').annotate(n=Count('id'))}

    return JsonResponse({
        'ok': True, 'hosts': hosts, 'total': len(hosts),
        'by_category': counts,
    })


@login_required
def api_host_sightings(request, pk):
    """Sighting history (audit trail) for one discovered host."""
    from .models import DiscoveredHost
    host = get_object_or_404(DiscoveredHost, pk=pk)
    sightings = [{
        'ip': s.ip, 'source': s.source, 'scanned_by': s.scanned_by,
        'seen_at': s.seen_at.isoformat(),
    } for s in host.sightings.all()[:100]]
    return JsonResponse({'ok': True, 'host': str(host),
                         'sightings': sightings, 'count': len(sightings)})
