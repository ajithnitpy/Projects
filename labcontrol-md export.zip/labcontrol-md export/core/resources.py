"""
Import / Export Resources
=========================
django-import-export Resource classes for bulk CSV/XLSX import and export
of Desktop and DesktopUser records via the Django admin.

Each Resource class defines:
  - which fields appear in the exported file
  - how incoming rows are matched to existing records (import_id_fields)
  - custom field widgets for ForeignKeys (so Location can be referenced by name)
"""
from import_export import resources, fields
from import_export.widgets import ForeignKeyWidget
from .models import Desktop, DesktopUser, Location


class LocationResource(resources.ModelResource):
    """Bulk import/export of Location records."""
    class Meta:
        model = Location
        import_id_fields = ('name',)
        fields = ('id', 'name', 'building', 'room', 'floor',
                  'description', 'color')
        export_order = fields
        skip_unchanged = True
        report_skipped = True


class DesktopResource(resources.ModelResource):
    """
    Bulk import/export of Desktop records.

    CSV/XLSX columns:
      device_name, ip_address, mac_address, ssh_username, ssh_password,
      ssh_port, ssh_key_path, use_sudo, sudo_password, make, model,
      serial_no, cpu, ram_gb, storage_gb, os_type, os_version,
      purchase_year, location, asset_tag, status, notes, is_managed

    Matching:
      Rows are matched on `device_name` (update) or inserted as new.
    """
    # Reference Location by its name (not its numeric ID) so spreadsheets
    # are human-readable
    location = fields.Field(
        column_name='location',
        attribute='location',
        widget=ForeignKeyWidget(Location, 'name'),
    )

    #: Both secrets are masked on export with this sentinel, and any row
    #: carrying it on import is treated as "leave the stored value alone".
    REDACTED = '***REDACTED***'

    class Meta:
        model = Desktop
        import_id_fields = ('device_name',)
        fields = (
            'device_name', 'ip_address', 'mac_address',
            'ssh_username', 'ssh_password', 'ssh_port', 'ssh_key_path',
            'use_sudo', 'sudo_password',
            'make', 'model', 'serial_no',
            'cpu', 'ram_gb', 'storage_gb',
            'os_type', 'os_version', 'purchase_year',
            'location', 'asset_tag', 'status', 'notes', 'is_managed',
        )
        export_order = fields
        skip_unchanged = True
        report_skipped = True

    def before_import_row(self, row, **kwargs):
        """Normalize incoming row data before creating/updating."""
        # Default OS type if missing
        if not row.get('os_type'):
            row['os_type'] = 'win11'
        # Default SSH port if missing
        if not row.get('ssh_port'):
            row['ssh_port'] = 22
        # Default status
        if not row.get('status'):
            row['status'] = 'unknown'
        # sudo defaults to on for Linux-style management
        if row.get('use_sudo') in (None, ''):
            row['use_sudo'] = True
        # Trim whitespace on key fields
        for key in ('device_name', 'ip_address', 'mac_address',
                    'ssh_username'):
            if row.get(key):
                row[key] = str(row[key]).strip()

        # Round-trip guard: exports mask both secrets, so re-importing an
        # exported file would otherwise overwrite every stored password with
        # the literal string "***REDACTED***" and lock the fleet out. Drop
        # the key so django-import-export leaves the existing value intact.
        for secret in ('ssh_password', 'sudo_password'):
            if str(row.get(secret) or '').strip() == self.REDACTED:
                row.pop(secret, None)

    def dehydrate_ssh_password(self, desktop):
        """
        SECURITY: Exported files MASK the password field.
        If you need real passwords in the export (NOT recommended),
        remove this method.
        """
        return self.REDACTED if desktop.ssh_password else ''

    def dehydrate_sudo_password(self, desktop):
        """SECURITY: sudo passwords are masked on export, same as SSH."""
        return self.REDACTED if desktop.sudo_password else ''


class DesktopUserResource(resources.ModelResource):
    """
    Bulk import/export of DesktopUser (OS-level users on remote desktops).

    CSV/XLSX columns:
      desktop, username, full_name, uid, gid, home_dir,
      shell, is_locked, is_sudoer

    Matching:
      Rows matched on (desktop + username) composite key.
    """
    desktop = fields.Field(
        column_name='desktop',
        attribute='desktop',
        widget=ForeignKeyWidget(Desktop, 'device_name'),
    )

    class Meta:
        model = DesktopUser
        import_id_fields = ('desktop', 'username')
        fields = (
            'desktop', 'username', 'full_name',
            'uid', 'gid', 'home_dir', 'shell',
            'is_locked', 'is_sudoer',
        )
        export_order = fields
        skip_unchanged = True
        report_skipped = True

    def before_import_row(self, row, **kwargs):
        """Auto-fill home_dir if missing based on desktop OS."""
        if not row.get('home_dir') and row.get('desktop') and row.get('username'):
            try:
                d = Desktop.objects.get(device_name=row['desktop'])
                if d.is_windows:
                    row['home_dir'] = f'C:\\Users\\{row["username"]}'
                else:
                    row['home_dir'] = f'/home/{row["username"]}'
            except Desktop.DoesNotExist:
                pass
