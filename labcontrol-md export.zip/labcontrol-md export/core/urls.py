"""Core URL routes"""
from django.urls import path
from . import views, api

urlpatterns = [
    # Dashboard
    path('', views.dashboard, name='dashboard'),

    # Desktop CRUD
    path('desktops/',                  views.desktop_list,   name='desktop_list'),
    path('desktops/add/',              views.desktop_add,    name='desktop_add'),
    path('desktops/<int:pk>/',         views.desktop_detail, name='desktop_detail'),
    path('desktops/<int:pk>/edit/',    views.desktop_edit,   name='desktop_edit'),
    path('desktops/<int:pk>/delete/',  views.desktop_delete, name='desktop_delete'),

    # Power
    path('desktops/<int:pk>/power-on/',  views.desktop_power_on,  name='desktop_power_on'),
    path('desktops/<int:pk>/power-off/', views.desktop_power_off, name='desktop_power_off'),
    path('desktops/<int:pk>/ping/',      views.desktop_ping,      name='desktop_ping'),

    # Shell
    path('desktops/<int:pk>/shell/', views.desktop_shell_run, name='desktop_shell_run'),

    # File browser
    path('desktops/<int:pk>/files/',          views.desktop_files,            name='desktop_files'),
    path('desktops/<int:pk>/files/view/',     views.desktop_file_view,        name='desktop_file_view'),
    path('desktops/<int:pk>/files/delete/',   views.desktop_file_delete,      name='desktop_file_delete'),
    path('desktops/<int:pk>/files/purge/',    views.desktop_purge_user_home,  name='desktop_purge_user_home'),

    # Remote OS user mgmt
    path('desktops/<int:pk>/users/create/',   views.desktop_user_create,   name='desktop_user_create'),
    path('desktops/<int:pk>/users/delete/',   views.desktop_user_delete,   name='desktop_user_delete'),
    path('desktops/<int:pk>/users/lock/',     views.desktop_user_lock,     name='desktop_user_lock'),
    path('desktops/<int:pk>/users/discover/', views.desktop_users_discover,name='desktop_users_discover'),

    # Bulk scan
    path('scan/', views.bulk_scan, name='bulk_scan'),

    # Change hostname / IP on a remote desktop
    path('desktops/<int:pk>/hostname/', views.desktop_change_hostname,
         name='desktop_change_hostname'),
    path('desktops/<int:pk>/ip/',       views.desktop_change_ip,
         name='desktop_change_ip'),

    # Icon-grid fleet monitor
    path('monitor/', views.monitor, name='monitor'),

    # Exam preparation (bulk clear user data)
    path('exam-prep/', views.exam_prep, name='exam_prep'),

    # Discovery
    path('discovery/', views.discovery, name='discovery'),

    # Bulk actions across multiple desktops
    path('bulk/', views.bulk_action, name='bulk_action'),

    # Ping all + Package repository
    path('ping-all/', views.ping_all, name='ping_all'),
    path('packages/', views.package_repo, name='package_repo'),
    path('packages/upload/', views.package_upload, name='package_upload'),
    path('packages/deploy/', views.package_deploy, name='package_deploy'),

    # Application catalog
    path('apps/', views.app_catalog, name='app_catalog'),
    path('apps/install/', views.app_install, name='app_install'),

    # AI assistant (local LLM via Ollama)
    path('ai/', views.ai_assistant, name='ai_assistant'),
    path('ai/generate/', views.ai_generate, name='ai_generate'),
    path('ai/save/', views.ai_save_app, name='ai_save_app'),

    # Locations
    path('locations/',                   views.location_manage, name='location_manage'),
    path('locations/<int:pk>/delete/',   views.location_delete, name='location_delete'),

    # Audit logs
    path('logs/', views.audit_logs, name='audit_logs'),

    # ─── REST API for React SPA ───────────────────────────────
    path('api/csrf/',          api.api_csrf,          name='api_csrf'),
    path('api/login/',         api.api_login,         name='api_login'),
    path('api/logout/',        api.api_logout,        name='api_logout'),
    path('api/me/',            api.api_me,            name='api_me'),
    path('api/dashboard/',     api.api_dashboard,     name='api_dashboard'),
    path('api/ping-all/',      api.api_ping_all,      name='api_ping_all'),
    path('api/ping/<int:pk>/', api.api_ping_one,      name='api_ping_one'),
    path('api/power/<int:pk>/',api.api_power,         name='api_power'),
    path('api/shell/<int:pk>/',api.api_shell,         name='api_shell'),
    path('api/bulk-shell/',    api.api_bulk_shell,     name='api_bulk_shell'),
    path('api/files/<int:pk>/',api.api_files,          name='api_files'),
    path('api/labs/<int:lab_id>/files/',     api.api_lab_files,        name='api_lab_files'),
    path('api/labs/<int:lab_id>/upload/',    api.api_lab_upload,       name='api_lab_upload'),
    path('api/labs/<int:lab_id>/deploy/',    api.api_lab_deploy_file,  name='api_lab_deploy_file'),
    path('api/ai/ask/',        api.api_ai_ask,         name='api_ai_ask'),
    path('api/ai/history/',    api.api_ai_history,     name='api_ai_history'),
    path('api/ai/read-logs/',  api.api_ai_read_logs,   name='api_ai_read_logs'),
    path('api/ai/save-app/',   api.api_ai_save_app,    name='api_ai_save_app'),
    path('api/logs/',          api.api_logs,            name='api_logs'),
    path('api/telemetry/<int:pk>/', api.api_telemetry,   name='api_telemetry'),
    path('api/telemetry-batch/',    api.api_telemetry_batch, name='api_telemetry_batch'),

    # File manager (SFTP)
    path('api/fm/<int:pk>/read/',     api.api_file_read,     name='api_file_read'),
    path('api/fm/<int:pk>/write/',    api.api_file_write,    name='api_file_write'),
    path('api/fm/<int:pk>/download/', api.api_file_download, name='api_file_download'),
    path('api/fm/<int:pk>/upload/',   api.api_file_upload,   name='api_file_upload'),
    path('api/fm/<int:pk>/delete/',   api.api_file_delete,   name='api_file_delete'),
    path('api/fm/<int:pk>/mkdir/',    api.api_file_mkdir,    name='api_file_mkdir'),
    path('api/bulk-power/',           api.api_bulk_power,    name='api_bulk_power'),
    path('api/bulk-ping/',            api.api_bulk_ping,     name='api_bulk_ping'),
    path('api/status/',               api.api_fleet_status,  name='api_fleet_status'),
    path('api/bulk-deploy/',          api.api_bulk_deploy,   name='api_bulk_deploy'),
    path('api/bulk-purge/',           api.api_bulk_purge,    name='api_bulk_purge'),
    path('api/collect-macs/',         api.api_collect_macs,  name='api_collect_macs'),
    path('api/tasks/create/',         api.api_task_create,   name='api_task_create'),
    path('api/tasks/delete/',         api.api_task_delete,   name='api_task_delete'),

    # Feature 1: Sessions & usage tracking
    path('api/sessions/',      api.api_sessions,       name='api_sessions'),
    path('api/usage-stats/',   api.api_usage_stats,    name='api_usage_stats'),
    # Feature 2: Scheduled tasks
    path('api/scheduled-tasks/', api.api_scheduled_tasks, name='api_scheduled_tasks'),
    # Feature 3: Software inventory
    path('api/software/',      api.api_software_inventory, name='api_software_inventory'),
    path('api/compliance/',    api.api_compliance,     name='api_compliance'),
    # Feature 4: Reservations
    path('api/reservations/',  api.api_reservations,   name='api_reservations'),
    path('api/reserve/',       api.api_reserve,        name='api_reserve'),
    # Feature 5: Config drift
    path('api/drift/',         api.api_drift_reports,  name='api_drift_reports'),
    # ARP neighbor discovery
    path('api/neighbors/',     api.api_neighbors,      name='api_neighbors'),
    path('api/hosts/',         api.api_hosts,          name='api_hosts'),
    path('api/hosts/<int:pk>/sightings/', api.api_host_sightings, name='api_host_sightings'),
]
