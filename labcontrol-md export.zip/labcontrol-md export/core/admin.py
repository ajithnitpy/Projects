"""LabControl Admin — with bulk CSV/Excel import/export"""
from django.contrib import admin
from import_export.admin import ImportExportModelAdmin

from .models import (
    Location, Desktop, DesktopUser,
    ActivityLog, PowerLog, ShellCommandLog,
    FileOperationLog, RemoteUserMgmtLog, ScanLog,
)
from .resources import LocationResource, DesktopResource, DesktopUserResource


@admin.register(Location)
class LocationAdmin(ImportExportModelAdmin):
    resource_class = LocationResource
    list_display = ['name', 'building', 'room', 'desktop_count', 'online_count']
    search_fields = ['name', 'building', 'room']


@admin.register(Desktop)
class DesktopAdmin(ImportExportModelAdmin):
    resource_class = DesktopResource
    list_display = ['device_name', 'ip_address', 'location', 'os_type',
                    'status', 'make', 'model', 'last_seen']
    list_filter = ['status', 'os_type', 'location', 'make']
    search_fields = ['device_name', 'ip_address', 'mac_address',
                     'serial_no', 'asset_tag']
    readonly_fields = ['created_at', 'updated_at', 'last_seen']
    fieldsets = (
        ('Identity', {'fields': ('device_name', 'ip_address', 'mac_address',
                                 'asset_tag', 'serial_no')}),
        ('SSH Access', {'fields': ('ssh_username', 'ssh_password', 'ssh_key_path',
                                   'ssh_port', 'use_sudo', 'sudo_password')}),
        ('Hardware', {'fields': ('make', 'model', 'cpu', 'ram_gb',
                                  'storage_gb', 'purchase_year')}),
        ('OS', {'fields': ('os_type', 'os_version')}),
        ('Location', {'fields': ('location', 'notes')}),
        ('State', {'fields': ('status', 'is_managed', 'last_seen',
                              'last_ping_ms', 'last_user',
                              'created_at', 'updated_at', 'added_by')}),
    )


@admin.register(DesktopUser)
class DesktopUserAdmin(ImportExportModelAdmin):
    resource_class = DesktopUserResource
    list_display = ['username', 'desktop', 'uid', 'is_locked', 'is_sudoer']
    list_filter = ['is_locked', 'is_sudoer']
    search_fields = ['username', 'desktop__device_name']


@admin.register(ActivityLog)
class ActivityLogAdmin(admin.ModelAdmin):
    list_display = ['created_at', 'user', 'action', 'path', 'ip_addr']
    list_filter = ['action', 'created_at']
    search_fields = ['user__username', 'path']


@admin.register(PowerLog)
class PowerLogAdmin(admin.ModelAdmin):
    list_display = ['created_at', 'desktop', 'action', 'success', 'user']
    list_filter = ['action', 'success']


@admin.register(ShellCommandLog)
class ShellCommandLogAdmin(admin.ModelAdmin):
    list_display = ['created_at', 'desktop', 'user', 'command',
                    'exit_code', 'duration_ms', 'backend']
    list_filter = ['backend', 'used_sudo', 'exit_code']
    search_fields = ['command', 'desktop__device_name']


@admin.register(FileOperationLog)
class FileOperationLogAdmin(admin.ModelAdmin):
    list_display = ['created_at', 'desktop', 'operation', 'target_path',
                    'success', 'user']
    list_filter = ['operation', 'success']
    search_fields = ['target_path', 'target_user']


@admin.register(RemoteUserMgmtLog)
class RemoteUserMgmtLogAdmin(admin.ModelAdmin):
    list_display = ['created_at', 'desktop', 'operation', 'target_user',
                    'success', 'user']
    list_filter = ['operation', 'success']
    search_fields = ['target_user', 'desktop__device_name']


@admin.register(ScanLog)
class ScanLogAdmin(admin.ModelAdmin):
    list_display = ['started_at', 'scan_type', 'target_count',
                    'success_count', 'failure_count', 'duration_ms', 'user']
    list_filter = ['scan_type']


from .models import Application, InstallJob

@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'linux_pkg', 'windows_pkg', 'is_active']
    list_filter = ['category', 'is_active', 'linux_method', 'windows_method']
    search_fields = ['name', 'linux_pkg', 'windows_pkg']

@admin.register(InstallJob)
class InstallJobAdmin(admin.ModelAdmin):
    list_display = ['created_at', 'application', 'desktop', 'success',
                    'exit_code', 'duration_ms', 'user']
    list_filter = ['success']
    readonly_fields = ['created_at']


from .models import AIConversation

@admin.register(AIConversation)
class AIConversationAdmin(admin.ModelAdmin):
    list_display = ['created_at', 'user', 'prompt', 'success',
                    'app_created', 'duration_ms', 'model']
    list_filter  = ['success', 'model']
    search_fields= ['prompt', 'response']
    readonly_fields = ['created_at']


from .models import PackageFile

@admin.register(PackageFile)
class PackageFileAdmin(admin.ModelAdmin):
    list_display = ['name', 'original_filename', 'file_size_display',
                    'platform_hint', 'uploaded_by', 'created_at']
    list_filter = ['created_at']
    search_fields = ['name', 'original_filename']
    readonly_fields = ['created_at']


from .models import (LoginSession, UsageSnapshot, InstalledSoftware,
                     SoftwarePolicy, GoldenConfig, DriftReport,
                     Reservation, ScheduledTask)

@admin.register(LoginSession)
class LoginSessionAdmin(admin.ModelAdmin):
    list_display = ['username', 'desktop', 'login_time', 'duration_display', 'is_active', 'idle_seconds']
    list_filter = ['is_active', 'desktop']
    search_fields = ['username', 'desktop__device_name']

@admin.register(InstalledSoftware)
class InstalledSoftwareAdmin(admin.ModelAdmin):
    list_display = ['name', 'version', 'desktop', 'source', 'last_seen']
    list_filter = ['source', 'desktop']
    search_fields = ['name']

@admin.register(SoftwarePolicy)
class SoftwarePolicyAdmin(admin.ModelAdmin):
    list_display = ['match_pattern', 'rule', 'applies_to_lab', 'is_active']
    list_filter = ['rule', 'is_active']

@admin.register(GoldenConfig)
class GoldenConfigAdmin(admin.ModelAdmin):
    list_display = ['name', 'lab', 'os_family', 'is_active']
    list_filter = ['lab', 'os_family']

@admin.register(DriftReport)
class DriftReportAdmin(admin.ModelAdmin):
    list_display = ['desktop', 'has_drift', 'drift_count', 'checked_at']
    list_filter = ['has_drift']

@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = ['desktop', 'reserved_by', 'start_time', 'end_time', 'status']
    list_filter = ['status', 'desktop']

@admin.register(ScheduledTask)
class ScheduledTaskAdmin(admin.ModelAdmin):
    list_display = ['name', 'task_type', 'lab', 'cron_display', 'is_enabled', 'last_run']
    list_filter = ['task_type', 'is_enabled']

admin.site.register(UsageSnapshot)


from .models import DiscoveredHost, HostSighting

@admin.register(DiscoveredHost)
class DiscoveredHostAdmin(admin.ModelAdmin):
    list_display = ['ip', 'mac', 'category', 'vendor', 'device_name_col',
                    'times_seen', 'seen_local', 'seen_remote', 'last_seen']
    list_filter = ['category', 'seen_local', 'seen_remote']
    search_fields = ['ip', 'mac', 'vendor', 'hostname']
    readonly_fields = ['first_seen', 'last_seen', 'times_seen']

    def device_name_col(self, obj):
        return obj.desktop.device_name if obj.desktop else '—'
    device_name_col.short_description = 'Managed as'

@admin.register(HostSighting)
class HostSightingAdmin(admin.ModelAdmin):
    list_display = ['ip', 'host', 'source', 'scanned_by', 'seen_at']
    list_filter = ['source']
    search_fields = ['ip', 'scanned_by']
