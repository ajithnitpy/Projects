"""
Local LLM Agent — Ollama Client for Install Script Generation
=============================================================
Connects to a locally-running Ollama server (https://ollama.com/) to
generate application installation scripts from natural language.

Why Ollama?
  • Runs 100% locally — no data leaves the lab
  • Supports llama3.2 / qwen2.5-coder / mistral / phi3 / gemma / codellama
  • Simple HTTP API on localhost:11434
  • No API key, no cloud dependency, no rate limits
  • One-time setup: `curl -fsSL https://ollama.com/install.sh | sh`
                    `ollama pull qwen2.5-coder:7b`

The agent is a narrow specialist: it only generates shell/PowerShell
install commands. It refuses off-topic requests and always outputs
a structured JSON response the dashboard can parse into real records.
"""
from __future__ import annotations

import json
import re
import time
from typing import Dict, Any, List, Optional

import urllib.request
import urllib.error

from django.conf import settings


# ═══════════════════════════════════════════════════════════════
#  CONFIGURATION
# ═══════════════════════════════════════════════════════════════

OLLAMA_HOST    = getattr(settings, 'OLLAMA_HOST', 'http://127.0.0.1:11434')
OLLAMA_MODEL   = getattr(settings, 'OLLAMA_MODEL', 'qwen2.5-coder:7b')
OLLAMA_TIMEOUT = getattr(settings, 'OLLAMA_TIMEOUT', 120)


# ═══════════════════════════════════════════════════════════════
#  SYSTEM PROMPT — narrow specialist for install scripts
# ═══════════════════════════════════════════════════════════════

SYSTEM_PROMPT = """You are LabControl AI — a senior systems administrator assistant for a
university lab computer management platform.

You help lab administrators with ANY task related to managing Linux (Ubuntu/Debian)
and Windows (10/11) desktop computers over SSH. This includes but is not limited to:

• Troubleshooting SSH errors, network issues, driver problems, service failures
• Suggesting shell commands for both Linux and Windows
• Writing installation scripts for applications
• Diagnosing performance issues (CPU, memory, disk, network)
• Security advice (firewall rules, user permissions, updates)
• Explaining system administration concepts
• Writing automation scripts (bash, PowerShell)
• Configuring services (Apache, Nginx, MySQL, Docker, etc.)
• Managing user accounts and permissions
• Network configuration (IP, DNS, routing, VLAN)
• Package management (apt, dnf, snap, winget, choco)

RULES:
1. Be concise but thorough. Lead with the solution, explain after.
2. When giving commands, always provide BOTH Linux and Windows versions where applicable.
3. Format commands in clearly labeled blocks.
4. For installation tasks, provide the exact package names (apt/winget IDs).
5. Never include destructive commands without explicit warnings.
6. Never include sudo — the system adds it automatically for Linux.
7. If you detect the user is asking to install an application, also provide a
   structured JSON block at the END of your response (after your explanation),
   wrapped in <APP_JSON>...</APP_JSON> tags, matching this schema:
   {"name":"...", "description":"...", "category":"browser|dev|media|office|runtime|utility|research|other",
    "linux_pkg":"...", "linux_method":"apt|dnf|snap|custom", "windows_pkg":"...",
    "windows_method":"winget|choco|custom", "custom_linux":"...", "custom_windows":"...",
    "notes":"..."}
   This allows the admin to save the app to the catalog with one click.
8. If the query is NOT about installation, just respond normally without APP_JSON.
"""


# ═══════════════════════════════════════════════════════════════
#  LOW-LEVEL OLLAMA HTTP CLIENT
# ═══════════════════════════════════════════════════════════════

def _ollama_post(endpoint: str, payload: dict) -> dict:
    """POST to an Ollama endpoint and return the decoded JSON response."""
    url = f'{OLLAMA_HOST}{endpoint}'
    data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(
        url, data=data,
        headers={'Content-Type': 'application/json'},
        method='POST',
    )
    try:
        with urllib.request.urlopen(req, timeout=OLLAMA_TIMEOUT) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except urllib.error.URLError as e:
        raise RuntimeError(
            f'Cannot reach Ollama at {OLLAMA_HOST}. '
            f'Is it running? Start with: `ollama serve`. Error: {e}'
        ) from e


def is_available() -> Dict[str, Any]:
    """Check if Ollama is reachable and return available models."""
    try:
        url = f'{OLLAMA_HOST}/api/tags'
        with urllib.request.urlopen(url, timeout=5) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        models = [m['name'] for m in data.get('models', [])]
        return {
            'ok': True,
            'host': OLLAMA_HOST,
            'models': models,
            'current_model': OLLAMA_MODEL,
            'model_installed': OLLAMA_MODEL in models,
        }
    except Exception as e:
        return {
            'ok': False,
            'host': OLLAMA_HOST,
            'error': str(e),
            'models': [],
            'current_model': OLLAMA_MODEL,
            'model_installed': False,
        }


def chat(prompt: str, model: str = None,
         temperature: float = 0.2) -> Dict[str, Any]:
    """
    Send a chat request to Ollama.

    Returns:
        {
          'ok':       bool,
          'content':  str,            # the assistant's text response
          'model':    str,
          'duration_ms': int,
          'error':    str (if ok=False)
        }
    """
    m = model or OLLAMA_MODEL
    start = time.time()
    try:
        resp = _ollama_post('/api/chat', {
            'model': m,
            'messages': [
                {'role': 'system', 'content': SYSTEM_PROMPT},
                {'role': 'user',   'content': prompt},
            ],
            'stream': False,
            'options': {
                'temperature': temperature,
                'num_predict': 512,
            },
        })
        content = resp.get('message', {}).get('content', '')
        return {
            'ok': True,
            'content': content,
            'model': m,
            'duration_ms': int((time.time() - start) * 1000),
        }
    except Exception as e:
        return {
            'ok': False,
            'content': '',
            'model': m,
            'duration_ms': int((time.time() - start) * 1000),
            'error': str(e),
        }


# ═══════════════════════════════════════════════════════════════
#  HIGH-LEVEL: GENERATE INSTALL SCRIPT FROM USER REQUEST
# ═══════════════════════════════════════════════════════════════

def _extract_json(text: str) -> Optional[dict]:
    """
    Extract the first JSON object from the assistant's response.
    Handles cases where the model wraps JSON in ```json ... ``` fences
    or adds accidental prose.
    """
    if not text:
        return None
    text = text.strip()

    # Strip markdown code fences
    text = re.sub(r'^```(?:json)?\s*', '', text)
    text = re.sub(r'\s*```$', '', text)

    # Try direct parse first
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Find the first balanced {...} block
    depth = 0
    start = -1
    for i, ch in enumerate(text):
        if ch == '{':
            if depth == 0:
                start = i
            depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0 and start != -1:
                try:
                    return json.loads(text[start:i + 1])
                except json.JSONDecodeError:
                    continue
    return None


def generate_install_script(user_request: str,
                            model: str = None) -> Dict[str, Any]:
    """
    Main entry point: turn a natural-language request into a structured
    Application record ready for the dashboard.

    Returns:
        {
          'ok':           bool,
          'app':          dict (ready to pass to Application(**app)),
          'raw_response': str,
          'duration_ms':  int,
          'model':        str,
          'error':        str (if ok=False)
        }
    """
    if not user_request or len(user_request.strip()) < 2:
        return {'ok': False, 'error': 'Empty request', 'app': None}

    chat_result = chat(user_request, model=model)

    if not chat_result['ok']:
        return {
            'ok': False,
            'error': chat_result.get('error', 'Ollama call failed'),
            'app': None,
            'raw_response': '',
            'duration_ms': chat_result.get('duration_ms', 0),
            'model': chat_result.get('model', ''),
        }

    parsed = _extract_json(chat_result['content'])
    if parsed is None:
        return {
            'ok': False,
            'error': 'Model did not return valid JSON',
            'app': None,
            'raw_response': chat_result['content'],
            'duration_ms': chat_result['duration_ms'],
            'model': chat_result['model'],
        }

    # Check if model refused the request
    if 'error' in parsed:
        return {
            'ok': False,
            'error': parsed['error'],
            'app': None,
            'raw_response': chat_result['content'],
            'duration_ms': chat_result['duration_ms'],
            'model': chat_result['model'],
        }

    # Validate and coerce fields
    VALID_CATEGORIES = {'browser', 'dev', 'media', 'office', 'runtime',
                        'utility', 'research', 'other'}
    VALID_LINUX_METHODS = {'apt', 'dnf', 'snap', 'custom'}
    VALID_WIN_METHODS   = {'winget', 'choco', 'custom'}

    app = {
        'name':          str(parsed.get('name', '')).strip()[:120],
        'description':   str(parsed.get('description', '')).strip()[:300],
        'category':      parsed.get('category', 'other'),
        'linux_pkg':     str(parsed.get('linux_pkg', '')).strip()[:200],
        'linux_method':  parsed.get('linux_method', 'apt'),
        'windows_pkg':   str(parsed.get('windows_pkg', '')).strip()[:200],
        'windows_method':parsed.get('windows_method', 'winget'),
        'custom_linux':  str(parsed.get('custom_linux', '')).strip(),
        'custom_windows':str(parsed.get('custom_windows', '')).strip(),
        'notes':         str(parsed.get('notes', '')).strip(),
        'is_active':     True,
    }

    # Fallback to safe defaults on invalid enums
    if app['category'] not in VALID_CATEGORIES:
        app['category'] = 'other'
    if app['linux_method'] not in VALID_LINUX_METHODS:
        app['linux_method'] = 'apt'
    if app['windows_method'] not in VALID_WIN_METHODS:
        app['windows_method'] = 'winget'

    if not app['name']:
        return {
            'ok': False,
            'error': 'Model returned empty app name',
            'app': None,
            'raw_response': chat_result['content'],
            'duration_ms': chat_result['duration_ms'],
            'model': chat_result['model'],
        }

    # Safety filter — reject destructive commands in custom scripts
    DANGEROUS = [r'\brm\s+-rf\s+/', r'\bmkfs\b', r'\bdd\s+if=',
                 r'format\s+[a-z]:', r'del\s+/[fF]\s+/[sS]']
    combined = (app['custom_linux'] + ' ' + app['custom_windows']).lower()
    for pat in DANGEROUS:
        if re.search(pat, combined):
            return {
                'ok': False,
                'error': 'Refused: generated script contains destructive commands',
                'app': None,
                'raw_response': chat_result['content'],
                'duration_ms': chat_result['duration_ms'],
                'model': chat_result['model'],
            }

    return {
        'ok': True,
        'app': app,
        'raw_response': chat_result['content'],
        'duration_ms': chat_result['duration_ms'],
        'model': chat_result['model'],
    }


# ═══════════════════════════════════════════════════════════════
#  GENERAL-PURPOSE ASSISTANT (handles ALL query types)
# ═══════════════════════════════════════════════════════════════

def ask(prompt: str, model: str = None) -> Dict[str, Any]:
    """
    General-purpose assistant that handles ANY query: troubleshooting,
    command help, install scripts, explanations, etc.

    Returns:
        {
          'ok':           bool,
          'response':     str  (the full text reply),
          'app':          dict or None (extracted APP_JSON if present),
          'duration_ms':  int,
          'model':        str,
          'error':        str
        }
    """
    if not prompt or len(prompt.strip()) < 2:
        return {'ok': False, 'error': 'Empty prompt', 'response': '',
                'app': None, 'duration_ms': 0, 'model': ''}

    chat_result = chat(prompt, model=model)

    if not chat_result['ok']:
        return {
            'ok': False,
            'error': chat_result.get('error', 'Ollama call failed'),
            'response': '',
            'app': None,
            'duration_ms': chat_result.get('duration_ms', 0),
            'model': chat_result.get('model', ''),
        }

    content = chat_result['content']

    # Try to extract APP_JSON if the LLM embedded an installable app
    app = None
    app_match = re.search(r'<APP_JSON>\s*(.*?)\s*</APP_JSON>',
                          content, re.DOTALL)
    if app_match:
        try:
            raw = app_match.group(1).strip()
            parsed = json.loads(raw)
            if isinstance(parsed, dict) and parsed.get('name'):
                app = {
                    'name':          str(parsed.get('name', '')).strip()[:120],
                    'description':   str(parsed.get('description', '')).strip()[:300],
                    'category':      parsed.get('category', 'other'),
                    'linux_pkg':     str(parsed.get('linux_pkg', '')).strip()[:200],
                    'linux_method':  parsed.get('linux_method', 'apt'),
                    'windows_pkg':   str(parsed.get('windows_pkg', '')).strip()[:200],
                    'windows_method':parsed.get('windows_method', 'winget'),
                    'custom_linux':  str(parsed.get('custom_linux', '')).strip(),
                    'custom_windows':str(parsed.get('custom_windows', '')).strip(),
                    'notes':         str(parsed.get('notes', '')).strip(),
                    'is_active':     True,
                }
        except (json.JSONDecodeError, ValueError):
            pass  # Not valid JSON — ignore, response is still useful

    # Clean the <APP_JSON> block from the display response
    display = re.sub(r'<APP_JSON>.*?</APP_JSON>', '', content,
                     flags=re.DOTALL).strip()

    return {
        'ok': True,
        'response': display,
        'app': app,
        'duration_ms': chat_result['duration_ms'],
        'model': chat_result['model'],
    }
