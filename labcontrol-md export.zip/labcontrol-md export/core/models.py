"""
LabControl Core Models
======================
Database schema for the lab desktop computer automation system.

Inventory:
  Location, Desktop, DesktopUser (remote OS users on desktops)

Audit / Logging (separate tables as per spec):
  ActivityLog       — generic web app user activity
  PowerLog          — power on / off events
  ShellCommandLog   — every shell command executed via the dashboard
  FileOperationLog  — file browse / delete / upload / scan operations
  RemoteUserMgmtLog — user create / delete / lock on remote desktops
  ScanLog           — bulk scans across all desktops
"""
from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


# ── Inventory ──────────────────────────────────────────────────

class Location(models.Model):
    """Physical lab location – desktops are grouped by this."""
    name = models.CharField(max_length=120, unique=True)
    building = models.CharField(max_length=120, blank=True)
    room = models.CharField(max_length=60, blank=True)
    floor = models.CharField(max_length=20, blank=True)
    description = models.TextField(blank=True)
    color = models.CharField(max_length=7, default='#00E5FF',
                             help_text='Hex color for UI badges')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']
        db_table = 'lc_location'

    def __str__(self):
        return self.name

    @property
    def desktop_count(self):
        return self.desktops.count()

    @property
    def online_count(self):
        return self.desktops.filter(status='online').count()


class Desktop(models.Model):
    """A lab desktop computer under management."""
    STATUS_CHOICES = [
        ('online',  'Online'),
        ('offline', 'Offline'),
        ('booting', 'Booting'),
        ('shutdown','Shutting Down'),
        ('unknown', 'Unknown'),
    ]
    OS_CHOICES = [
        # ─ Linux family ─
        ('ubuntu',  'Ubuntu Linux'),
        ('debian',  'Debian Linux'),
        ('centos',  'CentOS / RHEL'),
        ('fedora',  'Fedora'),
        # ─ Windows family ─
        ('win11',   'Windows 11'),
        ('win10',   'Windows 10'),
        ('win_srv', 'Windows Server'),
        ('windows', 'Windows (other)'),
        # ─ Other ─
        ('macos',   'macOS'),
        ('other',   'Other'),
    ]

    device_name  = models.CharField(max_length=100, unique=True)
    ip_address   = models.GenericIPAddressField(unique=True)
    mac_address  = models.CharField(max_length=17, blank=True,
                                    help_text='AA:BB:CC:DD:EE:FF (for Wake-on-LAN)')

    # SSH access
    ssh_username = models.CharField(max_length=64)
    ssh_password = models.CharField(max_length=255, blank=True,
                                    help_text='Stored encrypted in production')
    ssh_key_path = models.CharField(max_length=300, blank=True)
    ssh_port     = models.IntegerField(default=22)
    use_sudo     = models.BooleanField(default=True,
                                       help_text='Use sudo for privileged ops')
    sudo_password= models.CharField(max_length=255, blank=True)

    # Hardware / metadata
    make         = models.CharField(max_length=80, blank=True,
                                    help_text='e.g. Dell, HP, Lenovo')
    model        = models.CharField(max_length=120, blank=True)
    serial_no    = models.CharField(max_length=120, blank=True)
    cpu          = models.CharField(max_length=200, blank=True)
    ram_gb       = models.IntegerField(null=True, blank=True)
    storage_gb   = models.IntegerField(null=True, blank=True)
    os_type      = models.CharField(max_length=20, choices=OS_CHOICES,
                                    default='ubuntu')
    os_version   = models.CharField(max_length=80, blank=True)
    purchase_year= models.IntegerField(null=True, blank=True)

    # Grouping
    location     = models.ForeignKey(Location, on_delete=models.SET_NULL,
                                     null=True, blank=True,
                                     related_name='desktops')
    asset_tag    = models.CharField(max_length=80, blank=True)
    notes        = models.TextField(blank=True)

    # Runtime state
    status       = models.CharField(max_length=15, choices=STATUS_CHOICES,
                                    default='unknown')
    last_seen    = models.DateTimeField(null=True, blank=True)
    last_ping_ms = models.FloatField(null=True, blank=True)
    last_user    = models.CharField(max_length=120, blank=True,
                                    help_text='Last logged-in user (auto-discovered)')

    is_managed   = models.BooleanField(default=True)
    created_at   = models.DateTimeField(auto_now_add=True)
    updated_at   = models.DateTimeField(auto_now=True)
    added_by     = models.ForeignKey(User, on_delete=models.SET_NULL,
                                     null=True, blank=True,
                                     related_name='added_desktops')

    class Meta:
        ordering = ['device_name']
        db_table = 'lc_desktop'

    def __str__(self):
        return f'{self.device_name} ({self.ip_address})'

    @property
    def age_years(self):
        if not self.purchase_year:
            return None
        return timezone.now().year - self.purchase_year

    @property
    def status_color(self):
        return {
            'online':  '#9BFF00',
            'offline': '#FF4060',
            'booting': '#00E5FF',
            'shutdown':'#FFB800',
            'unknown': '#6B7886',
        }.get(self.status, '#6B7886')

    @property
    def status_label(self):
        return dict(self.STATUS_CHOICES).get(self.status, 'Unknown')

    @property
    def os_family(self):
        """'windows' or 'linux' — used to pick the remote backend."""
        return 'windows' if (self.os_type or '').lower() in (
            'win11', 'win10', 'win_srv', 'windows') else 'linux'

    @property
    def is_windows(self):
        return self.os_family == 'windows'

    @property
    def default_browse_path(self):
        return 'C:\\Users' if self.is_windows else '/home'


class DesktopUser(models.Model):
    """OS-level user accounts that exist on a desktop (synced/discovered)."""
    desktop  = models.ForeignKey(Desktop, on_delete=models.CASCADE,
                                 related_name='os_users')
    username = models.CharField(max_length=64)
    full_name= models.CharField(max_length=200, blank=True)
    uid      = models.IntegerField(null=True, blank=True)
    gid      = models.IntegerField(null=True, blank=True)
    home_dir = models.CharField(max_length=300, blank=True)
    shell    = models.CharField(max_length=120, blank=True)
    is_locked= models.BooleanField(default=False)
    is_sudoer= models.BooleanField(default=False)
    last_login_at = models.DateTimeField(null=True, blank=True)
    discovered_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = [('desktop', 'username')]
        ordering = ['desktop', 'username']
        db_table = 'lc_desktop_user'

    def __str__(self):
        return f'{self.username}@{self.desktop.device_name}'


# ── Audit / Logging Tables ─────────────────────────────────────

class ActivityLog(models.Model):
    """Generic web app user activity (page visits, logins, etc)."""
    user      = models.ForeignKey(User, on_delete=models.SET_NULL,
                                  null=True, blank=True)
    action    = models.CharField(max_length=120)
    target    = models.CharField(max_length=240, blank=True)
    method    = models.CharField(max_length=10, blank=True)
    path      = models.CharField(max_length=300, blank=True)
    ip_addr   = models.GenericIPAddressField(null=True, blank=True)
    user_agent= models.CharField(max_length=300, blank=True)
    detail    = models.TextField(blank=True)
    created_at= models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        db_table = 'lc_log_activity'
        indexes  = [models.Index(fields=['-created_at']),
                    models.Index(fields=['user', '-created_at'])]

    def __str__(self):
        return f'[{self.created_at:%H:%M}] {self.user}: {self.action}'


class PowerLog(models.Model):
    """Power on / off events for desktops."""
    ACTION_CHOICES = [
        ('wol_on',    'Wake-on-LAN'),
        ('reboot',    'Reboot'),
        ('shutdown',  'Shutdown'),
        ('suspend',   'Suspend'),
    ]
    desktop   = models.ForeignKey(Desktop, on_delete=models.CASCADE,
                                  related_name='power_logs')
    user      = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    action    = models.CharField(max_length=15, choices=ACTION_CHOICES)
    success   = models.BooleanField(default=False)
    detail    = models.TextField(blank=True)
    created_at= models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        db_table = 'lc_log_power'

    def __str__(self):
        return f'{self.desktop.device_name} {self.action} by {self.user}'


class ShellCommandLog(models.Model):
    """Every shell command executed on a desktop via the dashboard."""
    desktop    = models.ForeignKey(Desktop, on_delete=models.CASCADE,
                                   related_name='shell_logs')
    user       = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    command    = models.TextField()
    stdout     = models.TextField(blank=True)
    stderr     = models.TextField(blank=True)
    exit_code  = models.IntegerField(null=True, blank=True)
    duration_ms= models.IntegerField(null=True, blank=True)
    used_sudo  = models.BooleanField(default=False)
    backend    = models.CharField(max_length=20, default='paramiko',
                                  help_text='paramiko / fabric / netmiko')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        db_table = 'lc_log_shell'

    def __str__(self):
        return f'{self.desktop.device_name}: {self.command[:60]}'


class FileOperationLog(models.Model):
    """File browser & deletion operations on desktops."""
    OP_CHOICES = [
        ('list',    'List Directory'),
        ('view',    'View File'),
        ('edit',    'Edit File'),
        ('mkdir',   'Create Directory'),
        ('download','Download'),
        ('upload',  'Upload'),
        ('delete',  'Delete File'),
        ('delete_dir','Delete Directory'),
        ('scan_home','Scan Home Directory'),
        ('purge_home','Purge Home Directory'),
    ]
    desktop    = models.ForeignKey(Desktop, on_delete=models.CASCADE,
                                   related_name='file_logs')
    user       = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    operation  = models.CharField(max_length=20, choices=OP_CHOICES)
    target_path= models.CharField(max_length=600)
    target_user= models.CharField(max_length=64, blank=True,
                                  help_text='Affected OS user (if applicable)')
    file_count = models.IntegerField(null=True, blank=True)
    bytes_size = models.BigIntegerField(null=True, blank=True)
    success    = models.BooleanField(default=False)
    detail     = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        db_table = 'lc_log_files'

    def __str__(self):
        return f'{self.operation}: {self.target_path}'


class RemoteUserMgmtLog(models.Model):
    """User-management operations executed on remote desktops."""
    OP_CHOICES = [
        ('create', 'Create User'),
        ('delete', 'Delete User'),
        ('lock',   'Lock User'),
        ('unlock', 'Unlock User'),
        ('passwd', 'Reset Password'),
        ('discover','Discover Users'),
    ]
    desktop    = models.ForeignKey(Desktop, on_delete=models.CASCADE,
                                   related_name='user_mgmt_logs')
    user       = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    operation  = models.CharField(max_length=15, choices=OP_CHOICES)
    target_user= models.CharField(max_length=64)
    success    = models.BooleanField(default=False)
    detail     = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        db_table = 'lc_log_user_mgmt'

    def __str__(self):
        return f'{self.operation} {self.target_user}@{self.desktop.device_name}'


class ScanLog(models.Model):
    """Bulk-scan operations across multiple desktops."""
    SCAN_CHOICES = [
        ('discover_users', 'Discover OS Users'),
        ('purge_user_home','Purge User Home Dirs'),
        ('disk_usage',     'Disk Usage'),
        ('uptime',         'Uptime'),
        ('logged_users',   'Logged-in Users'),
        ('os_inventory',   'OS Inventory'),
        ('custom',         'Custom Command'),
    ]
    user            = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    scan_type       = models.CharField(max_length=20, choices=SCAN_CHOICES)
    parameter       = models.CharField(max_length=200, blank=True)
    target_count    = models.IntegerField(default=0)
    success_count   = models.IntegerField(default=0)
    failure_count   = models.IntegerField(default=0)
    results_text    = models.TextField(blank=True)
    started_at      = models.DateTimeField(auto_now_add=True)
    completed_at    = models.DateTimeField(null=True, blank=True)
    duration_ms     = models.IntegerField(null=True, blank=True)

    class Meta:
        ordering = ['-started_at']
        db_table = 'lc_log_scan'

    def __str__(self):
        return f'{self.get_scan_type_display()} ({self.target_count} hosts)'


# ─── Application Catalog & Install Audit ──────────────────────

class Application(models.Model):
    """Installable application catalog — managed via Django admin."""
    CATEGORY_CHOICES = [
        ('browser',    'Web Browser'),
        ('dev',        'Developer Tools'),
        ('media',      'Media / Graphics'),
        ('office',     'Office / Productivity'),
        ('runtime',    'Runtimes / Frameworks'),
        ('utility',    'Utilities'),
        ('research',   'Research / Science'),
        ('other',      'Other'),
    ]
    name           = models.CharField(max_length=120, unique=True)
    description    = models.CharField(max_length=300, blank=True)
    category       = models.CharField(max_length=20, choices=CATEGORY_CHOICES,
                                       default='utility')
    icon           = models.CharField(max_length=40, default='package',
                                       help_text='lucide icon name')
    # Linux: apt/dnf package name (or full custom command)
    linux_pkg      = models.CharField(max_length=200, blank=True,
                                       help_text='apt/dnf package name')
    linux_method   = models.CharField(max_length=20, default='apt',
                                       choices=[('apt','apt'),('dnf','dnf'),
                                                ('snap','snap'),('custom','custom')])
    # Windows: winget id (or chocolatey id, or full custom command)
    windows_pkg    = models.CharField(max_length=200, blank=True,
                                       help_text='winget id, e.g. Mozilla.Firefox')
    windows_method = models.CharField(max_length=20, default='winget',
                                       choices=[('winget','winget'),
                                                ('choco','chocolatey'),
                                                ('custom','custom')])
    custom_linux   = models.TextField(blank=True,
                                       help_text='Full bash if linux_method=custom')
    custom_windows = models.TextField(blank=True,
                                       help_text='Full PowerShell if windows_method=custom')
    is_active      = models.BooleanField(default=True)
    created_at     = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['category', 'name']
        db_table = 'lc_application'

    def __str__(self):
        return self.name

    def install_command(self, desktop):
        """Return the shell command to install this app on the given desktop."""
        if desktop.is_windows:
            if self.windows_method == 'custom':
                return self.custom_windows
            if self.windows_method == 'choco':
                return f'choco install {self.windows_pkg} -y'
            return (f'winget install --id {self.windows_pkg} '
                    f'--silent --accept-package-agreements '
                    f'--accept-source-agreements')
        else:
            if self.linux_method == 'custom':
                return self.custom_linux
            if self.linux_method == 'snap':
                return f'snap install {self.linux_pkg}'
            if self.linux_method == 'dnf':
                return f'dnf install -y {self.linux_pkg}'
            return f'DEBIAN_FRONTEND=noninteractive apt-get install -y {self.linux_pkg}'

    def uninstall_command(self, desktop):
        """
        Shell command to remove this app from `desktop`, or '' if the catalog
        entry has no reversible form.

        A 'custom' entry is a free-text install script, so there is nothing to
        invert — callers must surface that as a failure rather than pretend
        the removal happened.
        """
        if desktop.is_windows:
            if self.windows_method == 'custom' or not self.windows_pkg:
                return ''
            if self.windows_method == 'choco':
                return f'choco uninstall {self.windows_pkg} -y'
            return (f'winget uninstall --id {self.windows_pkg} '
                    f'--silent --accept-source-agreements')
        else:
            if self.linux_method == 'custom' or not self.linux_pkg:
                return ''
            if self.linux_method == 'snap':
                return f'snap remove {self.linux_pkg}'
            if self.linux_method == 'dnf':
                return f'dnf remove -y {self.linux_pkg}'
            return (f'DEBIAN_FRONTEND=noninteractive '
                    f'apt-get remove -y {self.linux_pkg}')


class InstallJob(models.Model):
    """Audit log of an application install on a desktop."""
    desktop     = models.ForeignKey(Desktop, on_delete=models.CASCADE,
                                     related_name='install_jobs')
    application = models.ForeignKey(Application, on_delete=models.SET_NULL,
                                     null=True)
    user        = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    command     = models.TextField()
    stdout      = models.TextField(blank=True)
    stderr      = models.TextField(blank=True)
    exit_code   = models.IntegerField(null=True, blank=True)
    success     = models.BooleanField(default=False)
    duration_ms = models.IntegerField(null=True, blank=True)
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        db_table = 'lc_log_install'

    def __str__(self):
        return f'{self.application}@{self.desktop}'


# ─── AI Assistant Conversation Log ────────────────────────────

class AIConversation(models.Model):
    """Log of user ↔ local LLM exchanges for the install-script assistant."""
    user        = models.ForeignKey(User, on_delete=models.SET_NULL,
                                     null=True, blank=True)
    prompt      = models.TextField()
    response    = models.TextField(blank=True)
    app_created = models.ForeignKey('Application',
                                     on_delete=models.SET_NULL,
                                     null=True, blank=True,
                                     related_name='ai_conversations')
    success     = models.BooleanField(default=False)
    model       = models.CharField(max_length=120, blank=True)
    duration_ms = models.IntegerField(null=True, blank=True)
    error       = models.CharField(max_length=500, blank=True)
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        db_table = 'lc_log_ai_chat'

    def __str__(self):
        return f'{self.user}: {self.prompt[:60]}'


# ─── Package Repository ──────────────────────────────────────

def package_upload_path(instance, filename):
    return f'packages/{filename}'

class PackageFile(models.Model):
    """Uploaded installer package (.exe, .msi, .deb, .rpm, .sh, .tar.gz)."""
    name              = models.CharField(max_length=200)
    description       = models.CharField(max_length=500, blank=True)
    file              = models.FileField(upload_to=package_upload_path)
    original_filename = models.CharField(max_length=255)
    file_size         = models.BigIntegerField(default=0)
    uploaded_by       = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    created_at        = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        db_table = 'lc_package_file'

    def __str__(self):
        return f'{self.name} ({self.original_filename})'

    @property
    def file_size_display(self):
        if self.file_size > 1_073_741_824:
            return f'{self.file_size / 1_073_741_824:.1f} GB'
        if self.file_size > 1_048_576:
            return f'{self.file_size / 1_048_576:.1f} MB'
        if self.file_size > 1024:
            return f'{self.file_size / 1024:.1f} KB'
        return f'{self.file_size} B'

    @property
    def extension(self):
        return self.original_filename.rsplit('.', 1)[-1].lower() if '.' in self.original_filename else ''

    @property
    def platform_hint(self):
        ext = self.extension
        if ext in ('exe', 'msi', 'msix'):
            return 'windows'
        if ext in ('deb', 'rpm', 'sh', 'run', 'AppImage'):
            return 'linux'
        return 'both'


# ═══════════════════════════════════════════════════════════════
#  SESSION & USAGE TRACKING
# ═══════════════════════════════════════════════════════════════

class LoginSession(models.Model):
    """A detected login session on a desktop (built from periodic who/query user)."""
    desktop     = models.ForeignKey(Desktop, on_delete=models.CASCADE,
                                    related_name='sessions')
    username    = models.CharField(max_length=100)
    login_time  = models.DateTimeField()
    last_seen   = models.DateTimeField()
    logout_time = models.DateTimeField(null=True, blank=True)
    source_ip   = models.CharField(max_length=64, blank=True)
    tty         = models.CharField(max_length=40, blank=True)
    is_active   = models.BooleanField(default=True)
    idle_seconds= models.IntegerField(default=0)

    class Meta:
        ordering = ['-login_time']
        db_table = 'lc_login_session'
        indexes = [
            models.Index(fields=['desktop', 'username', 'is_active']),
            models.Index(fields=['login_time']),
        ]

    def __str__(self):
        return f'{self.username}@{self.desktop.device_name}'

    @property
    def duration_seconds(self):
        end = self.logout_time or self.last_seen
        return int((end - self.login_time).total_seconds())

    @property
    def duration_display(self):
        s = self.duration_seconds
        h, rem = divmod(s, 3600)
        m = rem // 60
        return f'{h}h {m}m' if h else f'{m}m'


class UsageSnapshot(models.Model):
    """Point-in-time snapshot of a desktop's usage (for capacity time-series)."""
    desktop      = models.ForeignKey(Desktop, on_delete=models.CASCADE,
                                     related_name='usage_snapshots')
    captured_at  = models.DateTimeField(auto_now_add=True)
    logged_in_users = models.IntegerField(default=0)
    active_users = models.IntegerField(default=0)
    top_user     = models.CharField(max_length=100, blank=True)
    cpu_pct      = models.FloatField(null=True, blank=True)
    mem_pct      = models.FloatField(null=True, blank=True)

    class Meta:
        ordering = ['-captured_at']
        db_table = 'lc_usage_snapshot'
        indexes = [models.Index(fields=['desktop', 'captured_at'])]


# ═══════════════════════════════════════════════════════════════
#  LIVE STATUS / AVAILABILITY  (source of truth for monitoring)
# ═══════════════════════════════════════════════════════════════

class DesktopStatusEvent(models.Model):
    """
    Append-only record of every status *transition*.

    `Desktop.status` is a single denormalised cell — it answers "what is it
    now" and forgets everything else, so it can never say how long a machine
    has been up or how much a lab is used. This table is the history.

    Rows are written only when the status actually changes, so a fleet of 231
    desktops polled every 2 minutes produces a handful of rows a day rather
    than 166 000.
    """
    SOURCE_CHOICES = [
        ('ping',   'Ping sweep'),
        ('power',  'Power operation'),
        ('manual', 'Manual / UI'),
        ('seed',   'Initial observation'),
    ]
    desktop         = models.ForeignKey(Desktop, on_delete=models.CASCADE,
                                        related_name='status_events')
    status          = models.CharField(max_length=15,
                                       choices=Desktop.STATUS_CHOICES)
    previous_status = models.CharField(max_length=15, blank=True)
    changed_at      = models.DateTimeField(default=timezone.now)
    #: How long the *previous* status lasted, in seconds.
    duration_s      = models.IntegerField(null=True, blank=True)
    source          = models.CharField(max_length=10, choices=SOURCE_CHOICES,
                                       default='ping')
    rtt_ms          = models.FloatField(null=True, blank=True)

    class Meta:
        ordering = ['-changed_at']
        db_table = 'lc_status_event'
        indexes = [
            models.Index(fields=['desktop', '-changed_at']),
            models.Index(fields=['-changed_at']),
        ]

    def __str__(self):
        return f'{self.desktop_id} {self.previous_status}->{self.status}'


class DesktopUptimeDaily(models.Model):
    """
    Per-desktop, per-day time in each state — the table the utilisation
    charts read.

    Accumulated on every poll: the gap since the previous check is credited
    to whichever state the desktop was in during that gap. Gaps longer than
    `MAX_CREDIT_S` are ignored, so a weekend with the LabControl server off
    does not get charged to the desktops as uptime or downtime.
    """
    #: Never credit more than this from a single gap (poll interval is 120s;
    #: 15 min absorbs a slow sweep or a brief server restart, nothing more).
    MAX_CREDIT_S = 900

    desktop       = models.ForeignKey(Desktop, on_delete=models.CASCADE,
                                      related_name='uptime_days')
    day           = models.DateField()
    online_s      = models.IntegerField(default=0)
    offline_s     = models.IntegerField(default=0)
    unknown_s     = models.IntegerField(default=0)
    checks        = models.IntegerField(default=0)
    first_seen_at = models.DateTimeField(null=True, blank=True)
    last_seen_at  = models.DateTimeField(null=True, blank=True)
    #: When this row was last credited — the basis for the next gap.
    last_check_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-day']
        db_table = 'lc_uptime_daily'
        unique_together = [('desktop', 'day')]
        indexes = [
            models.Index(fields=['day']),
            models.Index(fields=['desktop', '-day']),
        ]

    @property
    def tracked_s(self):
        return self.online_s + self.offline_s + self.unknown_s

    @property
    def utilisation_pct(self):
        """Share of *observed* time the desktop was online."""
        total = self.tracked_s
        return round(100.0 * self.online_s / total, 1) if total else 0.0

    def __str__(self):
        return f'{self.desktop_id} {self.day} {self.utilisation_pct}%'


# ═══════════════════════════════════════════════════════════════
#  SOFTWARE INVENTORY AUDIT
# ═══════════════════════════════════════════════════════════════

class InstalledSoftware(models.Model):
    """A software package found installed on a desktop during inventory scan."""
    desktop      = models.ForeignKey(Desktop, on_delete=models.CASCADE,
                                     related_name='software')
    name         = models.CharField(max_length=200)
    version      = models.CharField(max_length=80, blank=True)
    publisher    = models.CharField(max_length=200, blank=True)
    source       = models.CharField(max_length=20, default='unknown',
                                    help_text='apt/dpkg/winget/registry')
    first_seen   = models.DateTimeField(auto_now_add=True)
    last_seen    = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']
        db_table = 'lc_installed_software'
        unique_together = [('desktop', 'name', 'version')]
        indexes = [models.Index(fields=['name']), models.Index(fields=['desktop'])]

    def __str__(self):
        return f'{self.name} {self.version}'


class SoftwarePolicy(models.Model):
    """Required or forbidden software rules for compliance checks."""
    RULE_CHOICES = [('required', 'Required'), ('forbidden', 'Forbidden'),
                    ('min_version', 'Minimum Version')]
    name         = models.CharField(max_length=200)
    rule         = models.CharField(max_length=20, choices=RULE_CHOICES)
    match_pattern= models.CharField(max_length=200,
                                    help_text='Software name (substring match)')
    min_version  = models.CharField(max_length=80, blank=True)
    applies_to_lab = models.ForeignKey(Location, on_delete=models.CASCADE,
                                       null=True, blank=True,
                                       help_text='Blank = all labs')
    is_active    = models.BooleanField(default=True)

    class Meta:
        db_table = 'lc_software_policy'
        verbose_name_plural = 'Software policies'

    def __str__(self):
        return f'{self.get_rule_display()}: {self.match_pattern}'


# ═══════════════════════════════════════════════════════════════
#  CONFIGURATION DRIFT DETECTION
# ═══════════════════════════════════════════════════════════════

class GoldenConfig(models.Model):
    """Baseline 'golden' configuration for a lab to detect drift against."""
    name         = models.CharField(max_length=200)
    lab          = models.ForeignKey(Location, on_delete=models.CASCADE,
                                     related_name='golden_configs')
    os_family    = models.CharField(max_length=20, default='linux',
                                    choices=[('linux', 'Linux'), ('windows', 'Windows')])
    # JSON blobs of expected state
    expected_packages = models.TextField(blank=True,
                                         help_text='JSON list of required package names')
    expected_services = models.TextField(blank=True,
                                         help_text='JSON list of services that must be running')
    expected_files    = models.TextField(blank=True,
                                         help_text='JSON dict of path→sha256')
    created_at   = models.DateTimeField(auto_now_add=True)
    is_active    = models.BooleanField(default=True)

    class Meta:
        db_table = 'lc_golden_config'

    def __str__(self):
        return f'{self.name} ({self.lab.name})'


class DriftReport(models.Model):
    """Result of comparing a desktop against its lab's golden config."""
    desktop      = models.ForeignKey(Desktop, on_delete=models.CASCADE,
                                     related_name='drift_reports')
    golden       = models.ForeignKey(GoldenConfig, on_delete=models.CASCADE)
    checked_at   = models.DateTimeField(auto_now_add=True)
    has_drift    = models.BooleanField(default=False)
    missing_packages = models.TextField(blank=True)   # JSON
    stopped_services = models.TextField(blank=True)   # JSON
    changed_files    = models.TextField(blank=True)   # JSON
    drift_count  = models.IntegerField(default=0)

    class Meta:
        ordering = ['-checked_at']
        db_table = 'lc_drift_report'

    def __str__(self):
        return f'Drift {self.desktop.device_name}: {self.drift_count} issues'


# ═══════════════════════════════════════════════════════════════
#  RESERVATION / BOOKING SYSTEM
# ═══════════════════════════════════════════════════════════════

class Reservation(models.Model):
    """A booking of a desktop (or GPU node) for a time slot."""
    STATUS_CHOICES = [('pending', 'Pending'), ('confirmed', 'Confirmed'),
                      ('active', 'Active'), ('completed', 'Completed'),
                      ('cancelled', 'Cancelled')]
    desktop      = models.ForeignKey(Desktop, on_delete=models.CASCADE,
                                     related_name='reservations')
    reserved_by  = models.ForeignKey(User, on_delete=models.CASCADE)
    purpose      = models.CharField(max_length=300, blank=True)
    start_time   = models.DateTimeField()
    end_time     = models.DateTimeField()
    status       = models.CharField(max_length=20, choices=STATUS_CHOICES,
                                    default='confirmed')
    created_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['start_time']
        db_table = 'lc_reservation'
        indexes = [models.Index(fields=['desktop', 'start_time', 'end_time'])]

    def __str__(self):
        return f'{self.desktop.device_name} by {self.reserved_by.username}'

    @property
    def duration_hours(self):
        return round((self.end_time - self.start_time).total_seconds() / 3600, 1)

    def overlaps(self, start, end):
        return self.start_time < end and start < self.end_time


# ═══════════════════════════════════════════════════════════════
#  SCHEDULED TASKS (Celery Beat backing store)
# ═══════════════════════════════════════════════════════════════

class ScheduledTask(models.Model):
    """A recurring automation job (wake, shutdown, scan, install)."""
    TASK_CHOICES = [
        ('wake_lab', 'Wake all desktops in a lab'),
        ('shutdown_idle', 'Shutdown idle desktops'),
        ('shutdown_lab', 'Shutdown all desktops in a lab'),
        ('inventory_scan', 'Software inventory scan'),
        ('drift_check', 'Configuration drift check'),
        ('session_poll', 'Poll login sessions'),
        ('custom_command', 'Run custom command'),
    ]
    name         = models.CharField(max_length=200)
    task_type    = models.CharField(max_length=30, choices=TASK_CHOICES)
    lab          = models.ForeignKey(Location, on_delete=models.CASCADE,
                                     null=True, blank=True)
    custom_command = models.TextField(blank=True)
    # Cron-style schedule
    cron_minute  = models.CharField(max_length=20, default='0')
    cron_hour    = models.CharField(max_length=20, default='0')
    cron_day_of_week = models.CharField(max_length=20, default='*')
    idle_threshold_min = models.IntegerField(default=30,
                                             help_text='For shutdown_idle')
    is_enabled   = models.BooleanField(default=True)
    last_run     = models.DateTimeField(null=True, blank=True)
    last_result  = models.TextField(blank=True)
    created_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'lc_scheduled_task'
        ordering = ['name']

    def __str__(self):
        return f'{self.name} ({self.get_task_type_display()})'

    @property
    def cron_display(self):
        return f'{self.cron_minute} {self.cron_hour} * * {self.cron_day_of_week}'


# ═══════════════════════════════════════════════════════════════
#  NEIGHBOR DISCOVERY — unique host registry + sighting log
# ═══════════════════════════════════════════════════════════════

class DiscoveredHost(models.Model):
    """
    A unique network host found via ARP discovery. Deduplicated by MAC
    (falls back to IP when MAC is unavailable). Updated in place on
    re-discovery; a HostSighting row is appended for each appearance.
    """
    CATEGORY_CHOICES = [
        ('managed',        'Managed Desktop'),
        ('infrastructure', 'Network Infrastructure'),
        ('iot',            'IoT / Embedded'),
        ('virtual',        'Virtual Machine'),
        ('unknown',        'Unknown Device'),
    ]
    mac           = models.CharField(max_length=32, blank=True, db_index=True)
    ip            = models.CharField(max_length=64, db_index=True)
    vendor        = models.CharField(max_length=120, blank=True)
    category      = models.CharField(max_length=20, choices=CATEGORY_CHOICES,
                                     default='unknown', db_index=True)
    hostname      = models.CharField(max_length=200, blank=True)
    # Link to a managed desktop if this host matches one
    desktop       = models.ForeignKey(Desktop, on_delete=models.SET_NULL,
                                      null=True, blank=True,
                                      related_name='discovered_as')
    # Discovery provenance
    first_source  = models.CharField(max_length=20, default='local',
                                     help_text='local | remote')
    last_source   = models.CharField(max_length=20, default='local')
    discovered_via= models.CharField(max_length=200, blank=True,
                                     help_text='Which host ran the scan (server or desktop name)')
    seen_local    = models.BooleanField(default=False)
    seen_remote   = models.BooleanField(default=False)
    # Time-series counters
    first_seen    = models.DateTimeField(auto_now_add=True)
    last_seen     = models.DateTimeField(auto_now=True)
    times_seen    = models.IntegerField(default=1)

    class Meta:
        db_table = 'lc_discovered_host'
        ordering = ['ip']
        indexes = [
            models.Index(fields=['category', 'last_seen']),
            models.Index(fields=['mac']),
        ]

    def __str__(self):
        return f'{self.ip} [{self.mac or "no-mac"}] {self.category}'

    @property
    def dedup_key(self):
        return self.mac if self.mac else f'ip:{self.ip}'


class HostSighting(models.Model):
    """One appearance of a DiscoveredHost in a scan (audit trail)."""
    host          = models.ForeignKey(DiscoveredHost, on_delete=models.CASCADE,
                                      related_name='sightings')
    ip            = models.CharField(max_length=64)
    source        = models.CharField(max_length=20)   # local | remote
    scanned_by    = models.CharField(max_length=200)  # server or desktop name
    seen_at       = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'lc_host_sighting'
        ordering = ['-seen_at']
        indexes = [models.Index(fields=['host', 'seen_at'])]

    def __str__(self):
        return f'{self.ip} @ {self.seen_at:%Y-%m-%d %H:%M} via {self.scanned_by}'
