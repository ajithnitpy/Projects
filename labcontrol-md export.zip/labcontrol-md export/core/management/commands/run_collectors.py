"""
Run collectors manually (no Celery needed for testing).

Usage:
  python manage.py run_collectors --type sessions
  python manage.py run_collectors --type software --lab 3
  python manage.py run_collectors --type drift
  python manage.py run_collectors --type all
"""
from django.core.management.base import BaseCommand
from core.models import Desktop
from core import collectors


class Command(BaseCommand):
    help = 'Run session/software/drift collectors across the fleet'

    def add_arguments(self, parser):
        parser.add_argument('--type', default='all',
                            choices=['sessions', 'software', 'drift', 'all'])
        parser.add_argument('--lab', type=int, default=None,
                            help='Limit to a lab (Location) ID')
        parser.add_argument('--online-only', action='store_true', default=True)

    def handle(self, *args, **opts):
        qs = Desktop.objects.filter(is_managed=True)
        if opts['online_only']:
            qs = qs.filter(status='online')
        if opts['lab']:
            qs = qs.filter(location_id=opts['lab'])

        desktops = list(qs)
        self.stdout.write(f'Running "{opts["type"]}" on {len(desktops)} desktop(s)...')

        for d in desktops:
            if opts['type'] in ('sessions', 'all'):
                r = collectors.collect_sessions(d)
                self.stdout.write(f'  [sessions] {d.device_name}: '
                                  f'{r.get("active",0)} active, {r.get("new",0)} new'
                                  + (f' ERROR: {r["error"]}' if 'error' in r else ''))
            if opts['type'] in ('software', 'all'):
                r = collectors.collect_software(d)
                self.stdout.write(f'  [software] {d.device_name}: '
                                  f'{r.get("found",0)} packages'
                                  + (f' ERROR: {r["error"]}' if 'error' in r else ''))
            if opts['type'] in ('drift', 'all'):
                r = collectors.check_drift(d)
                if 'error' in r:
                    self.stdout.write(f'  [drift]    {d.device_name}: {r["error"]}')
                else:
                    self.stdout.write(f'  [drift]    {d.device_name}: '
                                      f'{r["issues"]} issues'
                                      + (' ⚠ DRIFT' if r['has_drift'] else ' ✓ clean'))

        self.stdout.write(self.style.SUCCESS('Collectors complete.'))
