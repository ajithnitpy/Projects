"""
Seed LabControl-Merged with sample lab desktops, locations and audit logs.
The fleet is a deliberate MIX of Linux and Windows machines so the OS
dispatcher in remote_ops gets exercised end-to-end.

Run: python manage.py seed_lab
"""
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import timedelta
import random

from core.models import (
    Location, Desktop, DesktopUser,
    PowerLog, ShellCommandLog, ActivityLog,
)


class Command(BaseCommand):
    help = 'Seed LabControl-Merged with sample mixed-OS lab data'

    def handle(self, *args, **opts):
        self.stdout.write('Seeding LabControl mixed-OS sample data...')

        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser('admin', 'admin@lab.local', 'admin')
            self.stdout.write(self.style.SUCCESS('  ✓ admin user (admin/admin)'))
        admin = User.objects.get(username='admin')

        # ── Locations ──
        locations_data = [
            ('Lab A · Networking',     'Block 3', '301', '3rd', '#00E5FF'),
            ('Lab B · IoT & Embedded', 'Block 3', '302', '3rd', '#9BFF00'),
            ('Lab C · GPU / ML',       'Block 3', '305', '3rd', '#FFB800'),
            ('Faculty Office Cluster', 'Block 2', '210', '2nd', '#A78BFA'),
            ('Server Room',            'Block 1', '101', '1st', '#FF4060'),
        ]
        locations = {}
        for name, building, room, floor, color in locations_data:
            l, _ = Location.objects.get_or_create(
                name=name, defaults={
                    'building': building, 'room': room, 'floor': floor,
                    'color': color,
                    'description': f'Lab desktops located in {building} / Room {room}',
                })
            locations[name] = l
        self.stdout.write(self.style.SUCCESS(f'  ✓ {len(locations)} locations'))

        # ── Desktop fleet — mixed Linux + Windows ──
        # Tuples: (name, ip, mac, location, status, os_family)
        sample_desktops = [
            # Lab A · Networking — mostly Ubuntu lab boxes
            ('lab-a-pc-01',  '192.168.1.11', 'AA:BB:CC:00:00:11', 'Lab A · Networking', 'online',  'linux'),
            ('lab-a-pc-02',  '192.168.1.12', 'AA:BB:CC:00:00:12', 'Lab A · Networking', 'online',  'linux'),
            ('lab-a-pc-03',  '192.168.1.13', 'AA:BB:CC:00:00:13', 'Lab A · Networking', 'online',  'linux'),
            ('lab-a-win-01', '192.168.1.14', 'AA:BB:CC:00:00:14', 'Lab A · Networking', 'online',  'windows'),
            ('lab-a-win-02', '192.168.1.15', 'AA:BB:CC:00:00:15', 'Lab A · Networking', 'offline', 'windows'),
            ('lab-a-pc-06',  '192.168.1.16', 'AA:BB:CC:00:00:16', 'Lab A · Networking', 'online',  'linux'),
            # Lab B · IoT — Linux for sensor work
            ('lab-b-pc-01',  '192.168.1.21', 'AA:BB:CC:00:00:21', 'Lab B · IoT & Embedded', 'online',  'linux'),
            ('lab-b-pc-02',  '192.168.1.22', 'AA:BB:CC:00:00:22', 'Lab B · IoT & Embedded', 'online',  'linux'),
            ('lab-b-win-01', '192.168.1.23', 'AA:BB:CC:00:00:23', 'Lab B · IoT & Embedded', 'offline', 'windows'),
            ('lab-b-pc-04',  '192.168.1.24', 'AA:BB:CC:00:00:24', 'Lab B · IoT & Embedded', 'unknown', 'linux'),
            # Lab C · GPU / ML — mix of Win11 and Ubuntu
            ('lab-c-gpu-01', '192.168.1.31', 'AA:BB:CC:00:00:31', 'Lab C · GPU / ML', 'online', 'linux'),
            ('lab-c-gpu-02', '192.168.1.32', 'AA:BB:CC:00:00:32', 'Lab C · GPU / ML', 'online', 'windows'),
            ('lab-c-gpu-03', '192.168.1.33', 'AA:BB:CC:00:00:33', 'Lab C · GPU / ML', 'online', 'linux'),
            # Faculty offices — mostly Windows
            ('fac-pc-01',    '192.168.1.41', 'AA:BB:CC:00:00:41', 'Faculty Office Cluster', 'online',  'windows'),
            ('fac-pc-02',    '192.168.1.42', 'AA:BB:CC:00:00:42', 'Faculty Office Cluster', 'offline', 'windows'),
            ('fac-pc-03',    '192.168.1.43', 'AA:BB:CC:00:00:43', 'Faculty Office Cluster', 'online',  'windows'),
            # Server room — mix of Linux servers + Windows Server
            ('srv-host-01',  '192.168.1.51', 'AA:BB:CC:00:00:51', 'Server Room', 'online', 'linux'),
            ('srv-host-02',  '192.168.1.52', 'AA:BB:CC:00:00:52', 'Server Room', 'online', 'windows'),
        ]

        makes_models = [
            ('Dell', 'OptiPlex 7090'), ('Dell', 'Precision 3650'),
            ('HP', 'ProDesk 600 G6'), ('HP', 'EliteDesk 800 G8'),
            ('Lenovo', 'ThinkCentre M75q'), ('Lenovo', 'ThinkStation P358'),
            ('Acer', 'Veriton X4670G'),
        ]
        cpus = [
            'Intel Core i7-12700', 'Intel Core i5-11400',
            'Intel Xeon W-2245', 'AMD Ryzen 7 5700G',
            'Intel Core i9-12900K', 'AMD Ryzen 5 5600G',
        ]
        linux_versions  = ['22.04 LTS', '20.04 LTS', '24.04 LTS', '12 (Bookworm)']
        windows_versions= ['Windows 11 23H2', 'Windows 11 22H2',
                           'Windows 10 22H2', 'Windows Server 2022']

        for name, ip, mac, loc_name, status, family in sample_desktops:
            mk, mdl = random.choice(makes_models)
            if family == 'windows':
                os_type = random.choice(['win11', 'win11', 'win10', 'win_srv'])
                os_ver  = random.choice(windows_versions)
                username = 'Administrator'
                port = 22
            else:
                os_type = random.choice(['ubuntu', 'ubuntu', 'debian'])
                os_ver  = random.choice(linux_versions)
                username = 'labadmin'
                port = 22

            d, created = Desktop.objects.get_or_create(
                ip_address=ip,
                defaults={
                    'device_name':   name,
                    'mac_address':   mac,
                    'ssh_username':  username,
                    'ssh_port':      port,
                    'make':          mk,
                    'model':         mdl,
                    'serial_no':     f'SN{random.randint(10000,99999)}',
                    'cpu':           random.choice(cpus),
                    'ram_gb':        random.choice([8, 16, 32, 64]),
                    'storage_gb':    random.choice([256, 512, 1024]),
                    'os_type':       os_type,
                    'os_version':    os_ver,
                    'purchase_year': random.randint(2019, 2024),
                    'location':      locations.get(loc_name),
                    'asset_tag':     f'LAB-{random.randint(10000, 99999)}',
                    'status':        status,
                    'last_user':     random.choice(['student01', 'student02', 'researcher', '']),
                    'last_seen':     (timezone.now() - timedelta(minutes=random.randint(0, 200))
                                       if status == 'online'
                                       else timezone.now() - timedelta(days=random.randint(1, 5))),
                    'last_ping_ms':  round(random.uniform(0.4, 6.0), 2) if status == 'online' else None,
                    'added_by':      admin,
                },
            )
            if created:
                badge = '🪟' if family == 'windows' else '🐧'
                self.stdout.write(f'  · {badge} {name} ({ip}) — {os_type}')

        n_linux = sum(1 for d in sample_desktops if d[5] == 'linux')
        n_win = sum(1 for d in sample_desktops if d[5] == 'windows')
        self.stdout.write(self.style.SUCCESS(
            f'  ✓ {len(sample_desktops)} desktops ({n_linux} Linux, {n_win} Windows)'))

        # ── Sample DesktopUsers (OS-appropriate paths) ──
        for d in Desktop.objects.filter(status='online')[:8]:
            for uname in ['student01', 'student02', 'researcher']:
                if d.is_windows:
                    home = f'C:\\Users\\{uname}'
                    shell = 'powershell.exe'
                    uid, gid = 0, 0
                else:
                    home = f'/home/{uname}'
                    shell = '/bin/bash'
                    uid, gid = 1000 + random.randint(1, 50), 1000
                DesktopUser.objects.get_or_create(
                    desktop=d, username=uname,
                    defaults={'uid': uid, 'gid': gid, 'home_dir': home,
                              'shell': shell, 'is_locked': False},
                )

        # ── Sample power log ──
        if PowerLog.objects.count() == 0:
            for d in Desktop.objects.all()[:8]:
                PowerLog.objects.create(
                    desktop=d, user=admin,
                    action=random.choice(['wol_on', 'shutdown', 'reboot']),
                    success=random.choice([True, True, True, False]),
                    detail='Sample seeded power event',
                    created_at=timezone.now() - timedelta(minutes=random.randint(5, 600)),
                )

        # ── Sample shell commands — mix of bash and PowerShell ──
        if ShellCommandLog.objects.count() == 0:
            linux_samples = [
                ('uptime', ' 14:32:01 up 12 days,  3:42,  2 users', 'fabric'),
                ('df -h /', 'Filesystem  Size  Used Avail Use%\n/dev/sda1   500G  234G  241G  49%', 'fabric'),
                ('whoami', 'labadmin', 'paramiko'),
                ('uname -a', 'Linux lab-a-pc-01 5.15.0-91-generic #101 Ubuntu SMP', 'fabric'),
            ]
            win_samples = [
                ('powershell -c "Get-ComputerInfo | Select CsName,WindowsVersion"',
                 'CsName       : LAB-A-WIN-01\nWindowsVersion : 2009', 'paramiko'),
                ('powershell -c "Get-PSDrive -PSProvider FileSystem"',
                 'Name  Used (GB)  Free (GB)\nC          234        266', 'paramiko'),
                ('whoami', 'lab-a-win-01\\administrator', 'paramiko'),
            ]

            linux_devs = list(Desktop.objects.filter(
                status='online', os_type__in=['ubuntu','debian','centos','fedora'])[:4])
            win_devs   = list(Desktop.objects.filter(
                status='online', os_type__in=['win11','win10','win_srv','windows'])[:3])

            for d, (cmd, out, be) in zip(linux_devs, linux_samples):
                ShellCommandLog.objects.create(
                    desktop=d, user=admin, command=cmd, stdout=out, exit_code=0,
                    duration_ms=random.randint(50, 600), backend=be,
                    created_at=timezone.now() - timedelta(minutes=random.randint(5, 300)),
                )
            for d, (cmd, out, be) in zip(win_devs, win_samples):
                ShellCommandLog.objects.create(
                    desktop=d, user=admin, command=cmd, stdout=out, exit_code=0,
                    duration_ms=random.randint(50, 600), backend=be,
                    created_at=timezone.now() - timedelta(minutes=random.randint(5, 300)),
                )

        # ── Sample activity log ──
        if ActivityLog.objects.count() == 0:
            for path in ['/desktops/1/', '/scan/', '/desktops/add/', '/locations/']:
                ActivityLog.objects.create(
                    user=admin, action='POST', method='POST',
                    path=path, ip_addr='127.0.0.1',
                    created_at=timezone.now() - timedelta(minutes=random.randint(5, 240)),
                )

        self.stdout.write(self.style.SUCCESS(
            '\n✓ Seeding complete!\n'
            '\n  Run:    python manage.py runserver'
            '\n  Login:  http://127.0.0.1:8000/  with  admin / admin'
            '\n\n  The dispatcher will route SSH operations to Linux boxes'
            '\n  and PowerShell-over-SSH operations to Windows boxes automatically.\n'
        ))

        # ── Application catalog ──
        from core.models import Application
        catalog = [
            # name, desc, category, icon, linux_pkg, linux_method, win_pkg, win_method
            ('Google Chrome',  'Web browser',                    'browser', 'chrome',
             'google-chrome-stable', 'apt', 'Google.Chrome', 'winget'),
            ('Mozilla Firefox','Web browser',                    'browser', 'globe',
             'firefox', 'apt', 'Mozilla.Firefox', 'winget'),
            ('VS Code',        'Code editor',                    'dev', 'code',
             'code', 'snap', 'Microsoft.VisualStudioCode', 'winget'),
            ('Git',            'Version control',                'dev', 'git-branch',
             'git', 'apt', 'Git.Git', 'winget'),
            ('Python 3.12',    'Python interpreter',             'runtime', 'terminal',
             'python3', 'apt', 'Python.Python.3.12', 'winget'),
            ('Node.js LTS',    'JavaScript runtime',             'runtime', 'hexagon',
             'nodejs', 'apt', 'OpenJS.NodeJS.LTS', 'winget'),
            ('Docker',         'Container runtime',              'dev', 'box',
             'docker.io', 'apt', 'Docker.DockerDesktop', 'winget'),
            ('VLC',            'Media player',                   'media', 'play',
             'vlc', 'apt', 'VideoLAN.VLC', 'winget'),
            ('GIMP',           'Image editor',                   'media', 'image',
             'gimp', 'apt', 'GIMP.GIMP', 'winget'),
            ('LibreOffice',    'Office suite',                   'office', 'file-text',
             'libreoffice', 'apt', 'TheDocumentFoundation.LibreOffice', 'winget'),
            ('7-Zip',          'Archive manager',                'utility', 'archive',
             'p7zip-full', 'apt', '7zip.7zip', 'winget'),
            ('Wireshark',      'Network protocol analyzer',      'utility', 'activity',
             'wireshark', 'apt', 'WiresharkFoundation.Wireshark', 'winget'),
            ('PuTTY',          'SSH client',                     'utility', 'terminal-square',
             'putty', 'apt', 'PuTTY.PuTTY', 'winget'),
            ('Notepad++',      'Text editor',                    'utility', 'edit-3',
             '', '', 'Notepad++.Notepad++', 'winget'),
            ('htop',           'Process viewer',                 'utility', 'cpu',
             'htop', 'apt', '', ''),
            ('R',              'Statistical computing',          'research', 'sigma',
             'r-base', 'apt', 'RProject.R', 'winget'),
            ('Anaconda',       'Python data science distro',     'research', 'flask-conical',
             '', '', 'Anaconda.Anaconda3', 'winget'),
        ]
        for name, desc, cat, icon, lpkg, lm, wpkg, wm in catalog:
            Application.objects.get_or_create(
                name=name,
                defaults={
                    'description': desc, 'category': cat, 'icon': icon,
                    'linux_pkg': lpkg, 'linux_method': lm or 'apt',
                    'windows_pkg': wpkg, 'windows_method': wm or 'winget',
                },
            )
        self.stdout.write(self.style.SUCCESS(f'  ✓ {len(catalog)} apps in catalog'))
