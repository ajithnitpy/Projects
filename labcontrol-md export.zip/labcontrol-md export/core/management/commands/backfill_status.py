"""
Seed the availability event log from the current Desktop.status cells.

The live-status tables start empty, and live_status() reports 'unknown' for a
desktop it has never observed. Without this one-off seed the whole fleet would
read as unknown until the first sweep, which looks like an outage. Writes one
'seed' event per desktop, only where no event exists yet — so it is safe to
re-run.

    python manage.py backfill_status
"""
from django.core.management.base import BaseCommand
from django.utils import timezone

from core.models import Desktop, DesktopStatusEvent


class Command(BaseCommand):
    help = 'Seed DesktopStatusEvent from the current Desktop.status values'

    def add_arguments(self, parser):
        parser.add_argument('--all', action='store_true',
                            help='include unmanaged desktops')

    def handle(self, *args, **opts):
        now = timezone.now()
        qs = Desktop.objects.all()
        if not opts['all']:
            qs = qs.filter(is_managed=True)

        already = set(DesktopStatusEvent.objects
                      .values_list('desktop_id', flat=True).distinct())
        pending = [d for d in qs if d.pk not in already]

        if not pending:
            self.stdout.write(self.style.SUCCESS(
                f'Nothing to seed — all {qs.count()} desktop(s) already have '
                f'status history.'))
            return

        DesktopStatusEvent.objects.bulk_create([
            DesktopStatusEvent(
                desktop=d,
                status=d.status or 'unknown',
                previous_status='',
                changed_at=d.last_seen or now,
                duration_s=None,
                source='seed',
                rtt_ms=d.last_ping_ms,
            ) for d in pending
        ])

        by_status = {}
        for d in pending:
            by_status[d.status or 'unknown'] = by_status.get(d.status or 'unknown', 0) + 1
        detail = ', '.join(f'{v} {k}' for k, v in sorted(by_status.items()))
        self.stdout.write(self.style.SUCCESS(
            f'Seeded {len(pending)} desktop(s): {detail}'))
        self.stdout.write(
            f'{len(already)} already had history and were left alone.')
