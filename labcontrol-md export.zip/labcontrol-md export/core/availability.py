"""
Availability recording — the write path for the live-status tables.

`Desktop.status` is a denormalised "what is it right now" cell. It cannot
answer "how long has this been up" or "how much is this lab actually used",
because it keeps no history. Everything in this module exists to build that
history without turning a 231-desktop fleet polled every two minutes into a
166 000-row-per-day table:

  DesktopStatusEvent   one row per *transition* only
  DesktopUptimeDaily   one row per desktop per day, credited incrementally

Call `record_many()` from any sweep that learns a desktop's state.
"""
from datetime import timedelta

from django.db import transaction
from django.utils import timezone

from .models import Desktop, DesktopStatusEvent, DesktopUptimeDaily


def _bucket(status):
    """Which daily column a state counts towards."""
    if status == 'online':
        return 'online_s'
    if status == 'offline':
        return 'offline_s'
    return 'unknown_s'


@transaction.atomic
def record_many(observations, source='ping', now=None):
    """
    Record a batch of (desktop, status, rtt_ms) observations.

    `observations` is an iterable of (Desktop, status, rtt_ms). Returns a
    summary dict. Runs in one transaction so a partial sweep cannot leave
    half-credited days behind.

    Time accounting: the gap since a desktop's previous check is credited to
    the state it was in *during* that gap — i.e. its previous status, not the
    one just observed. A machine seen online at 09:00 and offline at 09:02
    was online for those two minutes; it did not retroactively become offline.
    """
    now = now or timezone.now()
    today = timezone.localdate(now)

    obs = list(observations)
    if not obs:
        return {'events': 0, 'days_touched': 0, 'credited_s': 0}

    ids = [d.pk for d, _, _ in obs]

    # Current day rows for everything in this batch, in one query.
    rows = {r.desktop_id: r for r in
            DesktopUptimeDaily.objects.filter(desktop_id__in=ids, day=today)}

    # Last known status per desktop, from the event log rather than
    # Desktop.status, so this module is self-contained.
    last_event = {}
    for ev in (DesktopStatusEvent.objects
               .filter(desktop_id__in=ids)
               .order_by('desktop_id', '-changed_at')):
        last_event.setdefault(ev.desktop_id, ev)

    new_events, new_rows, upd_rows = [], [], []
    credited = 0

    for desktop, status, rtt in obs:
        prev_ev = last_event.get(desktop.pk)
        prev_status = prev_ev.status if prev_ev else ''

        row = rows.get(desktop.pk)
        if row is None:
            row = DesktopUptimeDaily(desktop=desktop, day=today)
            rows[desktop.pk] = row
            new_rows.append(row)
        elif row not in upd_rows:
            upd_rows.append(row)

        # ── credit the gap to the state that was in force during it ──
        if row.last_check_at:
            gap = int((now - row.last_check_at).total_seconds())
            if 0 < gap <= DesktopUptimeDaily.MAX_CREDIT_S:
                field = _bucket(prev_status or status)
                setattr(row, field, getattr(row, field) + gap)
                credited += gap
            # gaps beyond MAX_CREDIT_S are dropped: the server was not
            # watching, so nothing is known about that stretch.

        row.checks += 1
        row.last_check_at = now
        if status == 'online':
            row.last_seen_at = now
            if row.first_seen_at is None:
                row.first_seen_at = now

        # ── transition log ──
        if status != prev_status:
            duration = None
            if prev_ev:
                duration = int((now - prev_ev.changed_at).total_seconds())
            new_events.append(DesktopStatusEvent(
                desktop=desktop, status=status, previous_status=prev_status,
                changed_at=now, duration_s=duration, source=source,
                rtt_ms=rtt))

    if new_rows:
        DesktopUptimeDaily.objects.bulk_create(new_rows)
    if upd_rows:
        DesktopUptimeDaily.objects.bulk_update(
            upd_rows, ['online_s', 'offline_s', 'unknown_s', 'checks',
                       'first_seen_at', 'last_seen_at', 'last_check_at'])
    if new_events:
        DesktopStatusEvent.objects.bulk_create(new_events)

    return {'events': len(new_events),
            'days_touched': len(new_rows) + len(upd_rows),
            'credited_s': credited}


def live_status(managed_only=True):
    """
    Current status of every desktop, derived from the event log.

    This is the read side of "don't take online status from the desktop
    table": the answer comes from the newest DesktopStatusEvent, falling back
    to 'unknown' for a desktop never yet observed.
    """
    qs = Desktop.objects.all()
    if managed_only:
        qs = qs.filter(is_managed=True)

    latest = {}
    for ev in (DesktopStatusEvent.objects
               .filter(desktop__in=qs)
               .order_by('desktop_id', '-changed_at')
               .only('desktop_id', 'status', 'changed_at', 'rtt_ms')):
        latest.setdefault(ev.desktop_id, ev)

    out = []
    for d in qs.only('pk', 'device_name', 'ip_address', 'location_id'):
        ev = latest.get(d.pk)
        out.append({
            'id': d.pk,
            'name': d.device_name,
            'ip': d.ip_address,
            'lab_id': d.location_id,
            'status': ev.status if ev else 'unknown',
            'since': ev.changed_at.isoformat() if ev else None,
            'rtt_ms': ev.rtt_ms if ev else None,
        })
    return out


def utilisation_series(days=14, lab_id=None):
    """
    Daily utilisation for charting: one point per day, fleet or one lab.

    Percentages are of *observed* time, not wall-clock — a day the server
    spent offline contributes no observation and is reported as such rather
    than as 0% uptime, which would be a lie about the desktops.
    """
    start = timezone.localdate() - timedelta(days=days - 1)
    qs = DesktopUptimeDaily.objects.filter(day__gte=start)
    if lab_id:
        qs = qs.filter(desktop__location_id=lab_id)

    buckets = {}
    for r in qs.values('day', 'online_s', 'offline_s', 'unknown_s', 'checks'):
        b = buckets.setdefault(r['day'], {'online_s': 0, 'offline_s': 0,
                                          'unknown_s': 0, 'checks': 0})
        for k in b:
            b[k] += r[k]

    series = []
    for i in range(days):
        day = start + timedelta(days=i)
        b = buckets.get(day)
        tracked = (b['online_s'] + b['offline_s'] + b['unknown_s']) if b else 0
        series.append({
            'day': day.isoformat(),
            'label': day.strftime('%d %b'),
            'online_s': b['online_s'] if b else 0,
            'offline_s': b['offline_s'] if b else 0,
            'unknown_s': b['unknown_s'] if b else 0,
            'tracked_s': tracked,
            'checks': b['checks'] if b else 0,
            'pct': round(100.0 * b['online_s'] / tracked, 1) if tracked else None,
            'observed': tracked > 0,
        })
    return series


def per_desktop_totals(days=14, lab_id=None, limit=None):
    """Total online seconds per desktop over the window, busiest first."""
    start = timezone.localdate() - timedelta(days=days - 1)
    qs = DesktopUptimeDaily.objects.filter(day__gte=start)
    if lab_id:
        qs = qs.filter(desktop__location_id=lab_id)

    agg = {}
    for r in qs.select_related('desktop').values(
            'desktop_id', 'desktop__device_name', 'desktop__location__name',
            'online_s', 'offline_s', 'unknown_s'):
        a = agg.setdefault(r['desktop_id'], {
            'id': r['desktop_id'], 'name': r['desktop__device_name'],
            'lab': r['desktop__location__name'] or '—',
            'online_s': 0, 'tracked_s': 0})
        a['online_s'] += r['online_s']
        a['tracked_s'] += r['online_s'] + r['offline_s'] + r['unknown_s']

    rows = sorted(agg.values(), key=lambda x: -x['online_s'])
    for r in rows:
        r['pct'] = (round(100.0 * r['online_s'] / r['tracked_s'], 1)
                    if r['tracked_s'] else 0.0)
        r['hours'] = round(r['online_s'] / 3600.0, 1)
    return rows[:limit] if limit else rows
