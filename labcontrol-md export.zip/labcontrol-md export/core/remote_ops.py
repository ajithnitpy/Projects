"""
Remote Operations — Unified SSH Backend
========================================
Single SSH transport (paramiko / fabric / netmiko) for **both** Linux and
Windows desktops. Windows 10/11 ships with OpenSSH Server built-in — just
enable it once and SSH + SFTP work exactly like Linux.

The only difference is the *commands* executed:
  Linux   → bash / coreutils (useradd, df, who, etc.)
  Windows → PowerShell cmdlets (New-LocalUser, Get-PSDrive, query user, etc.)

Every public function takes a Desktop model instance, checks
`desktop.is_windows`, and picks the right command automatically.

No WinRM, no pywinrm, no pypsrp, no TrustedHosts — just SSH everywhere.
"""
from __future__ import annotations

import json
import re
import socket
import subprocess
import time
import platform
import concurrent.futures
from datetime import datetime
from typing import Optional, List, Dict, Any


# ═══════════════════════════════════════════════════════════════
#  REACHABILITY
# ═══════════════════════════════════════════════════════════════

def ping_host(ip: str, timeout: int = 2) -> Dict[str, Any]:
    """Quick ICMP ping."""
    out = {'target': ip, 'alive': False, 'rtt_ms': None}
    win = platform.system().lower() == 'windows'
    cmd = ['ping', '-n' if win else '-c', '1',
           '-w' if win else '-W', str(timeout * 1000 if win else timeout), ip]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              timeout=timeout + 2)
        out['alive'] = proc.returncode == 0
        m = re.search(r'time[=<]\s*(\d+(?:\.\d+)?)\s*ms', proc.stdout)
        if m:
            out['rtt_ms'] = float(m.group(1))
    except Exception as e:
        out['error'] = str(e)
    return out


# ═══════════════════════════════════════════════════════════════
#  WAKE-ON-LAN
# ═══════════════════════════════════════════════════════════════

def local_ipv4s() -> List[str]:
    """
    Every non-loopback IPv4 the server holds.

    A magic packet must be emitted on the target's own link. `sendto` to the
    limited broadcast 255.255.255.255 leaves via exactly one interface — the
    one the default route picks — so on a multi-homed box (this lab server has
    nine) every other segment silently never receives it. Binding a socket to
    each source address in turn is what actually puts the frame on every link.
    """
    addrs = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None,
                                       socket.AF_INET):
            addrs.add(info[4][0])
    except Exception:
        pass
    try:                                  # picks up the default-route address
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(('8.8.8.8', 80))
            addrs.add(s.getsockname()[0])
    except Exception:
        pass
    return sorted(a for a in addrs if a and not a.startswith('127.'))


def _magic_packet(mac_address: str) -> bytes:
    """6 bytes of 0xFF followed by the target MAC 16 times."""
    mac_clean = re.sub(r'[^0-9A-Fa-f]', '', mac_address or '')
    if len(mac_clean) != 12:
        raise ValueError(f'Invalid MAC: {mac_address!r}')
    return b'\xff' * 6 + bytes.fromhex(mac_clean) * 16


def wol_send(mac_address: str, broadcast: str = '255.255.255.255',
             port: int = 9, source_ips: Optional[List[str]] = None,
             ports: Optional[List[int]] = None) -> Dict[str, Any]:
    """
    Send a Wake-on-LAN magic packet.

    Emits from every local interface unless `source_ips` narrows it, and on
    both UDP/9 and UDP/7 (NICs differ on which they listen to). Reports how
    many datagrams actually left, so "sent" cannot quietly mean "sent on one
    of nine links".
    """
    result = {'success': False, 'mac': mac_address, 'detail': '',
              'sent': 0, 'attempts': 0, 'errors': []}
    try:
        magic = _magic_packet(mac_address)
    except ValueError as e:
        result['detail'] = f'WoL failed: {e}'
        return result

    sources = source_ips if source_ips is not None else local_ipv4s()
    if not sources:
        sources = ['']                              # let the OS choose
    for p in (ports or [port]):
        for src in sources:
            result['attempts'] += 1
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                    if src:
                        s.bind((src, 0))
                    s.sendto(magic, (broadcast, p))
                result['sent'] += 1
            except OSError as e:
                # A source with no route to this broadcast is normal on a
                # multi-homed host; record it without failing the whole send.
                result['errors'].append(f'{src or "default"}->{broadcast}:{p}: {e}')

    # If every bound source failed, the interface list was wrong for this
    # destination — fall back to an unbound socket and let the OS route it,
    # rather than reporting a failure the plain send would not have had.
    if result['sent'] == 0 and sources != ['']:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                s.sendto(magic, (broadcast, (ports or [port])[0]))
            result['sent'] += 1
            result['attempts'] += 1
            result['errors'].append('all bound sends failed; used default route')
        except OSError as e:
            result['errors'].append(f'default route: {e}')

    result['success'] = result['sent'] > 0
    result['detail'] = (f'{result["sent"]}/{result["attempts"]} datagram(s) '
                        f'to {broadcast} for {mac_address}')
    return result


# ═══════════════════════════════════════════════════════════════
#  SSH CONNECTION
# ═══════════════════════════════════════════════════════════════

def _ssh_client(host, username, password=None, key_path=None,
                port=22, timeout=10):
    """Return a connected paramiko SSHClient."""
    import paramiko
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    kw = {'hostname': host, 'port': port, 'username': username,
          'timeout': timeout, 'allow_agent': False, 'look_for_keys': False}
    if key_path:
        kw['key_filename'] = key_path
    elif password:
        kw['password'] = password
    c.connect(**kw)
    return c


# ═══════════════════════════════════════════════════════════════
#  SHELL EXECUTION  (3 backends, same SSH transport)
# ═══════════════════════════════════════════════════════════════

def _run_paramiko(host, username, command, password=None, key_path=None,
                  port=22, timeout=10, use_sudo=False,
                  sudo_password=None) -> Dict[str, Any]:
    res = {'backend': 'paramiko', 'command': command, 'stdout': '',
           'stderr': '', 'exit_code': -1, 'duration_ms': 0,
           'success': False, 'detail': ''}
    try:
        if use_sudo and not command.lstrip().startswith('sudo'):
            if sudo_password:
                command = f"echo '{sudo_password}' | sudo -S -p '' {command}"
            else:
                command = f'sudo -n {command}'
        start = time.time()
        client = _ssh_client(host, username, password, key_path, port, timeout)
        stdin, stdout, stderr = client.exec_command(command, timeout=timeout)
        res['stdout'] = stdout.read().decode('utf-8', errors='replace')
        res['stderr'] = stderr.read().decode('utf-8', errors='replace')
        res['exit_code'] = stdout.channel.recv_exit_status()
        res['success'] = res['exit_code'] == 0
        res['duration_ms'] = int((time.time() - start) * 1000)
        client.close()
    except Exception as e:
        res['detail'] = str(e)
    return res


def _run_fabric(host, username, command, password=None, key_path=None,
                port=22, timeout=10, use_sudo=False,
                sudo_password=None) -> Dict[str, Any]:
    res = {'backend': 'fabric', 'command': command, 'stdout': '',
           'stderr': '', 'exit_code': -1, 'duration_ms': 0,
           'success': False, 'detail': ''}
    try:
        from fabric import Connection
        ckw = {}
        if key_path:
            ckw['key_filename'] = key_path
        elif password:
            ckw['password'] = password
        start = time.time()
        with Connection(host=host, user=username, port=port,
                        connect_timeout=timeout,
                        connect_kwargs=ckw) as c:
            if use_sudo:
                r = c.sudo(command, hide=True, warn=True,
                           password=sudo_password or password)
            else:
                r = c.run(command, hide=True, warn=True)
            res['stdout'] = r.stdout
            res['stderr'] = r.stderr
            res['exit_code'] = r.return_code
            res['success'] = r.ok
        res['duration_ms'] = int((time.time() - start) * 1000)
    except Exception as e:
        res['detail'] = str(e)
    return res


def _run_netmiko(host, username, command, password=None,
                 device_type='linux', port=22, timeout=10) -> Dict[str, Any]:
    res = {'backend': 'netmiko', 'command': command, 'stdout': '',
           'stderr': '', 'exit_code': 0, 'duration_ms': 0,
           'success': False, 'detail': ''}
    try:
        from netmiko import ConnectHandler
        device = {'device_type': device_type, 'host': host,
                  'username': username, 'password': password or '',
                  'port': port, 'timeout': timeout}
        start = time.time()
        with ConnectHandler(**device) as conn:
            res['stdout'] = conn.send_command(command, read_timeout=timeout)
        res['duration_ms'] = int((time.time() - start) * 1000)
        res['success'] = True
    except Exception as e:
        res['detail'] = str(e)
    return res


def run_command(desktop, command: str, backend: str = None,
                use_sudo: bool = False) -> Dict[str, Any]:
    """
    Execute a shell command on a remote desktop via SSH.
    Works identically for Linux and Windows OpenSSH targets.

    On Windows desktops the OpenSSH server defaults to cmd.exe as the
    login shell. To run PowerShell commands prefix with 'powershell -c'
    or set the default shell to PowerShell (see README).

    Backend: 'paramiko' (default) | 'fabric' | 'netmiko'
    """
    if backend is None:
        backend = 'paramiko'

    common = dict(
        host=desktop.ip_address,
        username=desktop.ssh_username,
        password=desktop.ssh_password or None,
        key_path=desktop.ssh_key_path or None,
        port=desktop.ssh_port,
        command=command,
    )

    if backend == 'fabric':
        return _run_fabric(**common, use_sudo=use_sudo,
                           sudo_password=desktop.sudo_password or None)
    if backend == 'netmiko':
        return _run_netmiko(host=desktop.ip_address,
                            username=desktop.ssh_username,
                            password=desktop.ssh_password or None,
                            command=command, port=desktop.ssh_port)
    return _run_paramiko(**common, use_sudo=use_sudo,
                         sudo_password=desktop.sudo_password or None)


def _ps(cmd: str) -> str:
    """Wrap a PowerShell command so it runs via OpenSSH's default cmd shell."""
    # Escape double quotes for cmd.exe passthrough
    escaped = cmd.replace('"', '\\"')
    return f'powershell -NoProfile -Command "{escaped}"'


# ═══════════════════════════════════════════════════════════════
#  POWER MANAGEMENT
# ═══════════════════════════════════════════════════════════════

def power_on(desktop, method: str = 'wol', broadcast: str = None,
             repeat: int = 3) -> Dict[str, Any]:
    """
    Power on a desktop using the selected mechanism.

    method:
      'wol'          - standard Wake-on-LAN magic packet (default)
      'wol_directed' - directed broadcast to the desktop's own subnet
                       (for cross-VLAN wake; needs router support)
      'ipmi'         - out-of-band BMC power on (needs ipmi_host/user/pass)

    Returns a detailed result with per-attempt log for the terminal.
    """
    steps = []

    if method == 'ipmi':
        return _power_on_ipmi(desktop, steps)

    if not desktop.mac_address:
        return {'success': False, 'detail': 'No MAC address on file',
                'steps': ['ERROR: desktop has no MAC address configured']}

    # Destination set. A limited broadcast alone is not enough here: it leaves
    # via one interface only, and on a routed campus it never crosses into the
    # lab's segment. Adding the desktop's own /24 directed broadcast covers the
    # case where a router forwards it, and costs one extra datagram.
    octets = desktop.ip_address.split('.')
    directed = ('.'.join(octets[:3]) + '.255') if len(octets) == 4 else None

    if broadcast:
        destinations = [broadcast]
    elif method == 'wol_directed':
        destinations = [directed] if directed else ['255.255.255.255']
    else:
        destinations = ['255.255.255.255'] + ([directed] if directed else [])

    sources = local_ipv4s()
    steps.append(f'Target MAC: {desktop.mac_address}')
    steps.append(f'Broadcast:  {", ".join(destinations)} on UDP 9 and 7')
    steps.append(f'Interfaces: {len(sources)} local address(es)')
    steps.append(f'Sending {repeat} round(s)...')

    sent = attempts = 0
    for i in range(repeat):
        for dest in destinations:
            r = wol_send(desktop.mac_address, broadcast=dest,
                         source_ips=sources, ports=[9, 7])
            sent += r.get('sent', 0)
            attempts += r.get('attempts', 0)
            steps.append(f'  round {i+1}/{repeat} → {dest}: '
                         f'{r.get("sent", 0)}/{r.get("attempts", 0)} datagram(s)')

    success = sent > 0
    detail = (f'{sent}/{attempts} datagram(s) sent for {desktop.mac_address} '
              f'via {", ".join(destinations)}')
    if success:
        steps.append(f'✓ {detail}')
        steps.append('NOTE: WoL is fire-and-forget. Verify with a ping in ~30-60s.')
    else:
        steps.append('✗ No datagram left the host — check firewall / interfaces')

    return {'success': success, 'detail': detail, 'steps': steps,
            'sent': sent, 'attempts': attempts, 'verify_after': 45}


def _power_on_ipmi(desktop, steps) -> Dict[str, Any]:
    """Power on via IPMI (out-of-band BMC). Requires ipmitool + BMC creds."""
    import shutil
    ipmi_host = getattr(desktop, 'ipmi_host', '') or ''
    ipmi_user = getattr(desktop, 'ipmi_user', '') or ''
    ipmi_pass = getattr(desktop, 'ipmi_pass', '') or ''

    if not ipmi_host:
        return {'success': False,
                'detail': 'No IPMI/BMC host configured for this desktop',
                'steps': ['ERROR: ipmi_host not set. IPMI needs a BMC '
                          '(Dell iDRAC / HP iLO / Supermicro) with network access.']}
    if not shutil.which('ipmitool'):
        return {'success': False, 'detail': 'ipmitool not installed on server',
                'steps': ['ERROR: install ipmitool: apt-get install ipmitool']}

    steps.append(f'IPMI target: {ipmi_host}')
    cmd = ['ipmitool', '-I', 'lanplus', '-H', ipmi_host,
           '-U', ipmi_user, '-P', ipmi_pass, 'chassis', 'power', 'on']
    try:
        import subprocess
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        ok = r.returncode == 0
        steps.append(f'ipmitool chassis power on → rc={r.returncode}')
        if r.stdout.strip():
            steps.append(r.stdout.strip())
        if r.stderr.strip():
            steps.append(f'stderr: {r.stderr.strip()}')
        return {'success': ok,
                'detail': 'IPMI power-on sent' if ok else 'IPMI command failed',
                'steps': steps}
    except Exception as e:
        steps.append(f'ERROR: {e}')
        return {'success': False, 'detail': str(e), 'steps': steps}


POWER_OFF_MODES = ('shutdown', 'reboot', 'suspend')


def power_off(desktop, mode: str = 'shutdown') -> Dict[str, Any]:
    # Reject unknown modes rather than defaulting to 'shutdown'. A typo or a
    # UI sending 'restart' instead of 'reboot' must not silently power off a
    # whole lab when the operator asked for a reboot.
    if mode not in POWER_OFF_MODES:
        return {'success': False,
                'detail': f'Unknown power mode {mode!r} — '
                          f'expected one of {", ".join(POWER_OFF_MODES)}'}

    if desktop.is_windows:
        cmd_map = {
            'shutdown': _ps('Stop-Computer -Force'),
            'reboot':   _ps('Restart-Computer -Force'),
            'suspend':  'shutdown /h',
        }
    else:
        cmd_map = {
            'shutdown': 'shutdown -h now',
            'reboot':   'shutdown -r now',
            'suspend':  'systemctl suspend',
        }
    return run_command(desktop, cmd_map[mode], use_sudo=not desktop.is_windows)


# ═══════════════════════════════════════════════════════════════
#  SFTP FILE OPERATIONS (works identically on both)
# ═══════════════════════════════════════════════════════════════

def _sftp_open(desktop):
    client = _ssh_client(
        desktop.ip_address, desktop.ssh_username,
        password=desktop.ssh_password or None,
        key_path=desktop.ssh_key_path or None,
        port=desktop.ssh_port,
    )
    return client, client.open_sftp()


def sftp_list_dir(desktop, path: str = None) -> Dict[str, Any]:
    """List directory contents via SFTP — works on both Linux and Windows OpenSSH."""
    if path is None:
        path = desktop.default_browse_path
    res = {'success': False, 'path': path, 'entries': [], 'detail': ''}
    try:
        client, sftp = _sftp_open(desktop)
        try:
            for attr in sftp.listdir_attr(path):
                res['entries'].append({
                    'name': attr.filename,
                    'size': attr.st_size,
                    'mtime': (datetime.fromtimestamp(attr.st_mtime).isoformat()
                              if attr.st_mtime else ''),
                    'mode': oct(attr.st_mode or 0)[-4:],
                    'is_dir': bool(attr.st_mode and (attr.st_mode & 0o040000)),
                })
            res['entries'].sort(
                key=lambda e: (not e['is_dir'], e['name'].lower()))
            res['success'] = True
        finally:
            sftp.close(); client.close()
    except Exception as e:
        res['detail'] = str(e)
    return res


# Backward-compat alias
list_dir = sftp_list_dir


def sftp_read_file(desktop, path: str, max_bytes: int = 64*1024) -> Dict[str, Any]:
    """Read a small text file via SFTP."""
    res = {'success': False, 'path': path, 'content': '',
           'truncated': False, 'detail': ''}
    try:
        client, sftp = _sftp_open(desktop)
        try:
            with sftp.open(path, 'r') as f:
                data = f.read(max_bytes + 1)
                if isinstance(data, bytes):
                    data = data.decode('utf-8', errors='replace')
                if len(data) > max_bytes:
                    res['truncated'] = True
                    data = data[:max_bytes]
                res['content'] = data
                res['success'] = True
        finally:
            sftp.close(); client.close()
    except Exception as e:
        res['detail'] = str(e)
    return res


def sftp_delete_file(desktop, path: str) -> Dict[str, Any]:
    """Delete a single remote file via SFTP."""
    res = {'success': False, 'path': path, 'detail': ''}
    try:
        client, sftp = _sftp_open(desktop)
        try:
            sftp.remove(path)
            res['success'] = True
            res['detail'] = f'Deleted {path}'
        finally:
            sftp.close(); client.close()
    except Exception as e:
        res['detail'] = str(e)
    return res


#: Account names are f-string interpolated into sudo / Administrator shell
#: commands by every function below, so this is the only thing standing
#: between a form field and arbitrary remote code execution. Leading digits
#: are allowed because roll-number usernames (22cs101) are normal here.
#: Everything a shell treats specially — ; & | ` $ ( ) < > quotes, whitespace,
#: slashes — is excluded by construction.
USERNAME_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9._-]{0,31}$')

#: Never purge or delete these, on either OS.
PROTECTED_USERS = {
    'administrator', 'admin', 'guest', 'public', 'default', 'default user',
    'all users', 'root', 'daemon', 'bin', 'sys', 'nobody', 'systemd-network',
}


def valid_username(username: str) -> bool:
    """True if `username` is safe to interpolate into a remote command."""
    return bool(username) and bool(USERNAME_RE.match(username))


def _reject_user(username: str) -> Optional[str]:
    """Return a refusal reason for `username`, or None if it is acceptable."""
    if not valid_username(username):
        return (f'Refused: invalid username {username!r} — letters, digits, '
                f'dot, underscore and hyphen only (max 32)')
    if username.lower() in PROTECTED_USERS:
        return f'Refused: protected account "{username}"'
    return None


def purge_user_home(desktop, target_user: str,
                    dry_run: bool = False) -> Dict[str, Any]:
    """Purge contents of a user's home / profile folder."""
    res = {'success': False, 'target_user': target_user, 'file_count': 0,
           'detail': '', 'dry_run': dry_run}

    refusal = _reject_user(target_user)
    if refusal:
        res['detail'] = refusal
        return res

    if desktop.is_windows:
        if '\\' in target_user or '..' in target_user:
            res['detail'] = f'Refused: protected user "{target_user}"'
            return res
        home = f'C:\\Users\\{target_user}'
        if dry_run:
            cmd = _ps(f"(Get-ChildItem -LiteralPath '{home}' -Recurse -Force "
                      f"-ErrorAction SilentlyContinue).Count")
        else:
            cmd = _ps(f"$items = Get-ChildItem -LiteralPath '{home}' -Force; "
                      f"$c = $items.Count; "
                      f"$items | Remove-Item -Recurse -Force; "
                      f"Write-Output \"PURGED $c items from {home}\"")
    else:
        home = f'/home/{target_user}'
        if dry_run:
            cmd = f'find {home} -mindepth 1 | wc -l'
        else:
            cmd = (f'find {home} -mindepth 1 -delete && '
                   f'echo "PURGED" && ls -la {home} | wc -l')

    out = run_command(desktop, cmd, use_sudo=not desktop.is_windows)
    res['success'] = out.get('success', False)
    res['detail'] = (out.get('stdout', '') + out.get('stderr', '')
                     + out.get('detail', '')).strip()
    if dry_run and res['success']:
        try:
            res['file_count'] = int(out['stdout'].strip().splitlines()[-1])
        except Exception:
            pass
    return res


# ═══════════════════════════════════════════════════════════════
#  REMOTE OS USER MANAGEMENT
# ═══════════════════════════════════════════════════════════════

def user_create_remote(desktop, username: str, password: str,
                       full_name: str = '', create_home: bool = True,
                       shell: str = '') -> Dict[str, Any]:
    res = {'success': False, 'username': username, 'detail': ''}

    if desktop.is_windows:
        if not re.match(r'^[A-Za-z][\w.-]{0,30}$', username):
            res['detail'] = 'Invalid username'
            return res
        cmd = _ps(
            f"$sec = ConvertTo-SecureString '{password}' -AsPlainText -Force; "
            f"New-LocalUser -Name '{username}' -Password $sec "
            f"-FullName '{full_name}' -PasswordNeverExpires; "
            f"Add-LocalGroupMember -Group 'Users' -Member '{username}' "
            f"-ErrorAction SilentlyContinue; "
            f"Write-Output 'USER_CREATED'"
        )
    else:
        if not re.match(r'^[a-z][-a-z0-9_]{0,30}$', username):
            res['detail'] = 'Invalid username (lowercase, 1-31 chars)'
            return res
        home_flag = '-m' if create_home else '-M'
        comment = f'-c "{full_name}"' if full_name else ''
        shell_flag = f'-s {shell}' if shell else '-s /bin/bash'
        cmd = (f'useradd {home_flag} {shell_flag} {comment} {username} && '
               f'echo "{username}:{password}" | chpasswd')

    out = run_command(desktop, cmd, use_sudo=not desktop.is_windows)
    res['success'] = out.get('success', False)
    res['detail'] = (out.get('stdout', '') + out.get('stderr', '')
                     + out.get('detail', '')).strip()
    return res


def user_delete_remote(desktop, username: str,
                       remove_home: bool = True) -> Dict[str, Any]:
    res = {'success': False, 'username': username, 'detail': ''}

    refusal = _reject_user(username)
    if refusal:
        res['detail'] = refusal
        return res

    if desktop.is_windows:
        home_del = ''
        if remove_home:
            home_del = (f"if (Test-Path 'C:\\Users\\{username}') "
                        f"{{ Remove-Item 'C:\\Users\\{username}' "
                        f"-Recurse -Force }};")
        cmd = _ps(f"Remove-LocalUser -Name '{username}'; "
                  f"{home_del} Write-Output 'USER_DELETED'")
    else:
        if username in ('root', 'admin', '') or '/' in username:
            res['detail'] = 'Refused: protected user'
            return res
        flag = '-r' if remove_home else ''
        cmd = f'userdel {flag} {username}'

    out = run_command(desktop, cmd, use_sudo=not desktop.is_windows)
    res['success'] = out.get('success', False)
    res['detail'] = (out.get('stdout', '') + out.get('stderr', '')
                     + out.get('detail', '')).strip()
    return res


def user_lock_remote(desktop, username: str,
                     unlock: bool = False) -> Dict[str, Any]:
    res = {'success': False, 'username': username, 'detail': ''}

    refusal = _reject_user(username)
    if refusal:
        res['detail'] = refusal
        return res

    if desktop.is_windows:
        verb = 'Enable-LocalUser' if unlock else 'Disable-LocalUser'
        cmd = _ps(f"{verb} -Name '{username}'; Write-Output 'OK'")
    else:
        flag = '-U' if unlock else '-L'
        cmd = f'usermod {flag} {username}'

    out = run_command(desktop, cmd, use_sudo=not desktop.is_windows)
    res['success'] = out.get('success', False)
    res['detail'] = (out.get('stdout', '') + out.get('stderr', '')
                     + out.get('detail', '')).strip()
    return res


def user_discover_remote(desktop) -> Dict[str, Any]:
    """Discover local users on the remote machine."""
    res = {'success': False, 'users': [], 'detail': ''}

    if desktop.is_windows:
        cmd = _ps(
            "Get-LocalUser | ForEach-Object { "
            "[PSCustomObject]@{ "
            "username=$_.Name; full_name=$_.FullName; "
            "enabled=$_.Enabled; "
            "sid=$_.SID.Value "
            "} } | ConvertTo-Json -Compress -Depth 3"
        )
        out = run_command(desktop, cmd)
        if not out.get('success'):
            res['detail'] = out.get('stderr') or out.get('detail') or 'SSH failed'
            return res
        try:
            raw = (out.get('stdout') or '').strip()
            if not raw:
                res['success'] = True
                return res
            data = json.loads(raw)
            if isinstance(data, dict):
                data = [data]
            for u in data:
                res['users'].append({
                    'username': u.get('username', ''),
                    'uid': 0, 'gid': 0,
                    'gecos': u.get('full_name', '') or '',
                    'home': f'C:\\Users\\{u.get("username", "")}',
                    'shell': 'powershell.exe',
                    'is_locked': not bool(u.get('enabled', True)),
                })
            res['success'] = True
        except Exception as e:
            res['detail'] = f'Parse error: {e}'

    else:
        out = run_command(desktop, 'cat /etc/passwd')
        if not out.get('success'):
            res['detail'] = out.get('detail', 'SSH failed')
            return res
        for line in out['stdout'].splitlines():
            parts = line.split(':')
            if len(parts) < 7:
                continue
            try:
                uid = int(parts[2])
            except ValueError:
                continue
            if uid < 1000 and parts[0] != 'root':
                continue
            if parts[0] == 'nobody':
                continue
            res['users'].append({
                'username': parts[0], 'uid': uid, 'gid': int(parts[3] or 0),
                'gecos': parts[4], 'home': parts[5], 'shell': parts[6],
            })
        # Check lock status
        lock_out = run_command(desktop, 'passwd -Sa 2>/dev/null || true',
                               use_sudo=True)
        locked_set = set()
        if lock_out.get('success'):
            for ln in lock_out['stdout'].splitlines():
                cols = ln.split()
                if len(cols) >= 2 and cols[1] in ('L', 'LK'):
                    locked_set.add(cols[0])
        for u in res['users']:
            u['is_locked'] = u['username'] in locked_set
        res['success'] = True

    return res


# ═══════════════════════════════════════════════════════════════
#  BULK-SCAN OS-AWARE COMMAND HELPERS
# ═══════════════════════════════════════════════════════════════

_MAC_ANY = re.compile(r'([0-9A-Fa-f]{2}[:\-]){5}[0-9A-Fa-f]{2}')


def normalize_mac(raw: str) -> str:
    """
    Return 'AA:BB:CC:DD:EE:FF' for any common MAC spelling, or '' if none
    is present. Accepts colon, hyphen, bare-12-hex and Cisco dotted forms.
    """
    if not raw:
        return ''
    text = raw.strip()
    m = _MAC_ANY.search(text)
    if m:
        return m.group(0).replace('-', ':').upper()
    hexonly = re.sub(r'[^0-9A-Fa-f]', '', text)
    if len(hexonly) == 12:
        return ':'.join(hexonly[i:i + 2] for i in range(0, 12, 2)).upper()
    return ''


def get_mac_address(desktop) -> Dict[str, Any]:
    """
    Ask a desktop for the MAC of the NIC that holds its managed IP.

    Wake-on-LAN is addressed to a MAC, so a blank mac_address makes a desktop
    unwakeable. Harvesting over SSH beats scraping the server's ARP cache:
    ARP only sees the scanner's own broadcast domain and entries age out
    within minutes, so an ARP sweep silently misses most of a routed fleet.
    """
    ip = (desktop.ip_address or '').strip()
    if not re.match(r'^\d{1,3}(\.\d{1,3}){3}$', ip):
        return {'success': False, 'mac': '', 'detail': f'Invalid IP {ip!r}'}

    if desktop.is_windows:
        cmd = _ps(
            f"$a = Get-NetIPAddress -IPAddress '{ip}' -ErrorAction SilentlyContinue | "
            f"Select-Object -First 1; "
            f"if ($a) {{ (Get-NetAdapter -InterfaceIndex $a.InterfaceIndex)."
            f"MacAddress }} else {{ "
            f"(Get-NetAdapter | Where-Object {{$_.Status -eq 'Up'}} | "
            f"Select-Object -First 1).MacAddress }}"
        )
    else:
        cmd = (f"IF=$(ip -o -4 addr show | awk -v ip='{ip}' "
               f"'$4 ~ \"^\"ip\"/\" {{print $2; exit}}'); "
               f"if [ -n \"$IF\" ]; then cat /sys/class/net/$IF/address; "
               f"else cat /sys/class/net/$(ip route show default | "
               f"awk '{{print $5; exit}}')/address; fi")

    res = run_command(desktop, cmd, use_sudo=False)
    mac = normalize_mac(res.get('stdout', ''))
    if not mac:
        return {'success': False, 'mac': '',
                'detail': (res.get('stderr') or res.get('detail')
                           or 'No MAC in command output')[:200]}
    return {'success': True, 'mac': mac, 'detail': f'MAC {mac}'}


def cmd_disk_usage(desktop) -> Dict[str, Any]:
    if desktop.is_windows:
        return run_command(desktop, _ps(
            "Get-PSDrive -PSProvider FileSystem | "
            "Select-Object Name,"
            "@{N='UsedGB';E={[math]::Round($_.Used/1GB,2)}},"
            "@{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}} | "
            "Format-Table -AutoSize | Out-String"))
    return run_command(desktop, 'df -h /')


def cmd_uptime(desktop) -> Dict[str, Any]:
    if desktop.is_windows:
        return run_command(desktop, _ps(
            "$os = Get-CimInstance Win32_OperatingSystem; "
            "$up = (Get-Date) - $os.LastBootUpTime; "
            "Write-Output ('Up {0}d {1}h {2}m' -f "
            "$up.Days, $up.Hours, $up.Minutes)"))
    return run_command(desktop, 'uptime')


def cmd_logged_users(desktop) -> Dict[str, Any]:
    if desktop.is_windows:
        return run_command(desktop, 'query user')
    return run_command(desktop, 'who')


def cmd_os_inventory(desktop) -> Dict[str, Any]:
    if desktop.is_windows:
        return run_command(desktop, _ps(
            "Get-CimInstance Win32_OperatingSystem | "
            "Select-Object Caption,Version,OSArchitecture,"
            "CSName,InstallDate | Format-List | Out-String"))
    return run_command(desktop, 'cat /etc/os-release; uname -r; lscpu | head -3')


# ═══════════════════════════════════════════════════════════════
#  BULK RUNNER
# ═══════════════════════════════════════════════════════════════

def bulk_run(desktops: list, fn, max_workers: int = 30) -> List[Dict[str, Any]]:
    """Run fn(desktop) across many desktops in parallel."""
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as ex:
        fmap = {ex.submit(fn, d): d for d in desktops}
        for fut in concurrent.futures.as_completed(fmap):
            d = fmap[fut]
            try:
                r = fut.result()
            except Exception as e:
                r = {'success': False, 'detail': str(e)}
            r['device_name'] = d.device_name
            r['ip_address'] = d.ip_address
            results.append(r)
    return results


# ═══════════════════════════════════════════════════════════════
#  HOSTNAME & IP CHANGE  (OS-aware)
# ═══════════════════════════════════════════════════════════════

def change_hostname(desktop, new_hostname: str) -> Dict[str, Any]:
    """Change the hostname of a remote desktop. Reboot recommended after."""
    # RFC 1123 relaxed RFC 952: a label may start with a digit, so lab names
    # like "01-lab-pc" are valid. Max 63 chars (1 + 62).
    if not re.match(r'^[A-Za-z0-9][\w-]{0,62}$', new_hostname):
        return {'success': False, 'detail': 'Invalid hostname'}

    if desktop.is_windows:
        cmd = _ps(f"Rename-Computer -NewName '{new_hostname}' -Force; "
                  f"Write-Output 'HOSTNAME_CHANGED'")
    else:
        cmd = (f'hostnamectl set-hostname {new_hostname} && '
               f'sed -i "s/127.0.1.1.*/127.0.1.1 {new_hostname}/" /etc/hosts && '
               f'echo HOSTNAME_CHANGED')
    return run_command(desktop, cmd, use_sudo=not desktop.is_windows)


def change_ip_address(desktop, new_ip: str, netmask: str = '24',
                     gateway: str = '', interface: str = '') -> Dict[str, Any]:
    """Change static IP on a desktop. WARNING: connection will drop."""
    if not re.match(r'^\d+\.\d+\.\d+\.\d+$', new_ip):
        return {'success': False, 'detail': 'Invalid IP'}

    if desktop.is_windows:
        iface = interface or 'Ethernet'
        gw_clause = f"-DefaultGateway '{gateway}'" if gateway else ''
        cmd = _ps(
            f"$adapter = Get-NetAdapter -Name '{iface}' -ErrorAction Stop; "
            f"Remove-NetIPAddress -InterfaceAlias '{iface}' -Confirm:$false "
            f"  -ErrorAction SilentlyContinue; "
            f"New-NetIPAddress -InterfaceAlias '{iface}' "
            f"  -IPAddress '{new_ip}' -PrefixLength {netmask} {gw_clause}; "
            f"Write-Output 'IP_CHANGED'"
        )
    else:
        iface = interface or 'eth0'
        # Use nmcli for NetworkManager (most modern distros)
        cidr = f'{new_ip}/{netmask}'
        gw = f'ipv4.gateway {gateway}' if gateway else ''
        cmd = (f'nmcli con mod "$(nmcli -t -f NAME,DEVICE con show --active | '
               f'grep ":{iface}$" | cut -d: -f1)" '
               f'ipv4.addresses {cidr} {gw} ipv4.method manual && '
               f'nmcli con up "$(nmcli -t -f NAME,DEVICE con show --active | '
               f'grep ":{iface}$" | cut -d: -f1)" && echo IP_CHANGED')
    return run_command(desktop, cmd, use_sudo=not desktop.is_windows)


# ═══════════════════════════════════════════════════════════════
#  NETWORK DISCOVERY  (#6)
# ═══════════════════════════════════════════════════════════════

def discover_subnet(subnet: str = '192.168.1.0/24',
                    timeout: int = 1) -> Dict[str, Any]:
    """
    Sweep a subnet with parallel ping + SSH banner grab.
    Returns alive hosts with detected OS hints.
    """
    import ipaddress
    result = {'subnet': subnet, 'hosts': [], 'scanned': 0}

    try:
        net = ipaddress.ip_network(subnet, strict=False)
    except ValueError as e:
        result['error'] = str(e)
        return result

    targets = [str(ip) for ip in net.hosts()]
    if len(targets) > 256:
        result['error'] = 'Subnet too large (max /24)'
        return result

    def probe(ip):
        ping_res = ping_host(ip, timeout=timeout)
        if not ping_res.get('alive'):
            return None
        host = {'ip': ip, 'alive': True, 'rtt_ms': ping_res.get('rtt_ms'),
                'os_hint': 'unknown', 'ssh_open': False, 'banner': ''}
        # SSH banner grab on port 22
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(2)
                s.connect((ip, 22))
                banner = s.recv(256).decode('utf-8', errors='replace').strip()
                host['ssh_open'] = True
                host['banner'] = banner[:120]
                # OS detection from banner
                bl = banner.lower()
                if 'ubuntu' in bl or 'debian' in bl:
                    host['os_hint'] = 'linux'
                elif 'windows' in bl or 'win64' in bl:
                    host['os_hint'] = 'windows'
                elif 'openssh' in bl:
                    host['os_hint'] = 'linux'  # default for OpenSSH
        except (socket.timeout, ConnectionRefusedError, OSError):
            pass
        # Hostname via reverse DNS
        try:
            host['hostname'] = socket.gethostbyaddr(ip)[0]
        except (socket.herror, socket.gaierror):
            host['hostname'] = ''
        return host

    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as ex:
        for r in ex.map(probe, targets):
            result['scanned'] += 1
            if r:
                result['hosts'].append(r)

    result['hosts'].sort(key=lambda h: tuple(int(p) for p in h['ip'].split('.')))
    return result


# ═══════════════════════════════════════════════════════════════
#  SFTP WRITE / DOWNLOAD (for file manager)
# ═══════════════════════════════════════════════════════════════

def sftp_write_file(desktop, path: str, content: str) -> Dict[str, Any]:
    """Write text content to a remote file via SFTP (overwrites)."""
    res = {'success': False, 'path': path, 'detail': ''}
    try:
        client, sftp = _sftp_open(desktop)
        try:
            with sftp.open(path, 'w') as f:
                f.write(content)
            res['success'] = True
            res['detail'] = f'Wrote {len(content)} bytes to {path}'
        finally:
            sftp.close(); client.close()
    except Exception as e:
        res['detail'] = str(e)
    return res


def sftp_download_bytes(desktop, path: str, max_bytes: int = 100*1024*1024):
    """Download a remote file's raw bytes. Returns (bytes, error)."""
    try:
        client, sftp = _sftp_open(desktop)
        try:
            st = sftp.stat(path)
            if st.st_size > max_bytes:
                return None, f'File too large ({st.st_size} bytes, max {max_bytes})'
            with sftp.open(path, 'rb') as f:
                return f.read(), None
        finally:
            sftp.close(); client.close()
    except Exception as e:
        return None, str(e)


def sftp_upload_fileobj(desktop, fileobj, remote_path: str) -> Dict[str, Any]:
    """Upload a Django UploadedFile to a remote path via SFTP."""
    res = {'success': False, 'path': remote_path, 'detail': ''}
    try:
        client, sftp = _sftp_open(desktop)
        try:
            with sftp.open(remote_path, 'wb') as rf:
                for chunk in fileobj.chunks(chunk_size=1024*1024):
                    rf.write(chunk)
            res['success'] = True
            res['detail'] = f'Uploaded to {remote_path}'
        finally:
            sftp.close(); client.close()
    except Exception as e:
        res['detail'] = str(e)
    return res


def sftp_mkdir(desktop, path: str) -> Dict[str, Any]:
    res = {'success': False, 'path': path, 'detail': ''}
    try:
        client, sftp = _sftp_open(desktop)
        try:
            sftp.mkdir(path)
            res['success'] = True
            res['detail'] = f'Created {path}'
        finally:
            sftp.close(); client.close()
    except Exception as e:
        res['detail'] = str(e)
    return res


# ═══════════════════════════════════════════════════════════════
#  DEBUGGING SUGGESTIONS (analyze failed operations)
# ═══════════════════════════════════════════════════════════════

def suggest_debug(operation: str, result: dict, desktop=None) -> list:
    """
    Analyze a failed operation and return actionable debugging suggestions.
    Rule-based (fast, no LLM). For deeper analysis, the AI assistant's
    read-logs feature can be used.
    """
    if result.get('success'):
        return []

    detail = (result.get('detail', '') + ' ' +
              result.get('stderr', '')).lower()
    tips = []

    # SSH / auth
    if 'authentication' in detail or 'auth' in detail or 'password' in detail:
        tips.append('AUTH: Wrong SSH username/password. Verify credentials in the desktop record.')
        if desktop and desktop.is_windows:
            tips.append('WINDOWS: Confirm the SSH user is a local Administrator.')
    if 'timed out' in detail or 'timeout' in detail:
        tips.append('TIMEOUT: Host unreachable. Check the PC is powered on and on the network.')
        tips.append('Try a Ping first. If ping fails, the machine is off or on a different VLAN.')
    if 'connection refused' in detail or 'refused' in detail:
        tips.append('REFUSED: sshd not running on the target.')
        if desktop and desktop.is_windows:
            tips.append('WINDOWS: Run `Start-Service sshd` on the desktop (elevated PowerShell).')
        else:
            tips.append('LINUX: Run `sudo systemctl start ssh` on the desktop.')
    if 'no route to host' in detail or 'unreachable' in detail:
        tips.append('NETWORK: No route to host. Check VLAN/subnet and switch port.')
    if 'permission denied' in detail:
        tips.append('PERMISSION: The SSH user lacks rights. Use sudo (Linux) or an admin account (Windows).')
    if 'host key' in detail:
        tips.append('HOST KEY: SSH host key mismatch. The machine may have been reimaged.')

    # Power specific
    if operation == 'power_on':
        tips.append('WoL CHECKLIST:')
        tips.append('  1. BIOS: "Wake on LAN" / "Power on by PCI-E" must be enabled.')
        tips.append('  2. OS NIC: WoL magic packet must be enabled on the adapter.')
        tips.append('  3. Same broadcast domain: standard WoL does not cross subnets — use directed broadcast.')
        tips.append('  4. Fast Startup (Windows): disable it — it prevents WoL from S5.')
        tips.append('  5. Cabled: WoL over WiFi rarely works; use ethernet.')

    if operation in ('shutdown', 'reboot'):
        if desktop and desktop.is_windows:
            tips.append('WINDOWS: Shutdown needs admin. Check the SSH user is Administrator.')
        else:
            tips.append('LINUX: Shutdown needs sudo. Verify passwordless sudo for the SSH user.')

    # SFTP
    if operation.startswith('file') or operation.startswith('sftp'):
        if 'no such file' in detail:
            tips.append('PATH: File or directory does not exist. Check the path.')
        if 'permission' in detail:
            tips.append('SFTP: The user cannot access this path. Check file ownership/ACLs.')

    if not tips:
        tips.append(f'No specific rule matched. Raw error: {result.get("detail") or result.get("stderr") or "unknown"}')
        tips.append('Try the AI Assistant → "Read Shell Errors" for deeper analysis.')

    return tips


# ═══════════════════════════════════════════════════════════════
#  ARP NEIGHBOR DISCOVERY
# ═══════════════════════════════════════════════════════════════

import subprocess as _subprocess

# Minimal OUI → vendor map (first 3 MAC octets). Extend as needed.
_OUI_VENDORS = {
    '00:50:56': 'VMware', '00:0c:29': 'VMware', '00:1c:14': 'VMware',
    '08:00:27': 'VirtualBox', '52:54:00': 'QEMU/KVM',
    '00:15:5d': 'Microsoft Hyper-V',
    'b8:27:eb': 'Raspberry Pi', 'dc:a6:32': 'Raspberry Pi', 'e4:5f:01': 'Raspberry Pi',
    '00:1a:11': 'Google', '00:1b:63': 'Apple', '00:03:93': 'Apple', 'a4:83:e7': 'Apple',
    '00:d0:2d': 'Dell', '00:14:22': 'Dell', 'b0:83:fe': 'Dell', '18:03:73': 'Dell',
    '00:21:5a': 'HP', '00:1b:78': 'HP', '3c:d9:2b': 'HP', '98:e7:f4': 'HP',
    '00:1e:c9': 'Dell', 'ec:f4:bb': 'Dell',
    '00:e0:4c': 'Realtek', '52:54:ab': 'Realtek',
    '00:26:b9': 'Dell', 'f8:b1:56': 'Dell',
    '00:1d:09': 'Dell', '00:24:e8': 'Dell',
    '00:16:3e': 'Xen', 'fc:aa:14': 'GIGA-BYTE',
    '00:0d:3a': 'Microsoft', '00:17:fa': 'Microsoft',
    '2c:f0:5d': 'Micro-Star', '00:d8:61': 'Micro-Star',
    '00:1f:c6': 'ASUSTek', '04:d4:c4': 'ASUSTek', '2c:56:dc': 'ASUSTek',
    'd8:5e:d3': 'Espressif (ESP)', '24:6f:28': 'Espressif (ESP32)',
    '7c:9e:bd': 'Espressif (ESP32)', '30:ae:a4': 'Espressif (ESP32)',
    'cc:50:e3': 'Espressif (ESP)', 'a0:20:a6': 'Espressif',
    '00:1a:2b': 'Cisco', '00:1b:d4': 'Cisco', '00:23:04': 'Cisco',
    '00:26:0b': 'Cisco', '00:24:97': 'Cisco', 'e0:d1:73': 'TP-Link',
    '50:c7:bf': 'TP-Link', 'c4:6e:1f': 'TP-Link', '14:cc:20': 'TP-Link',
}


def _mac_vendor(mac: str) -> str:
    """Look up a hardware vendor from a MAC's OUI prefix."""
    if not mac:
        return ''
    norm = mac.lower().replace('-', ':')
    parts = norm.split(':')
    if len(parts) < 3:
        return ''
    prefix = ':'.join(parts[:3])
    return _OUI_VENDORS.get(prefix, '')


def _parse_arp_table(text: str) -> list:
    """Parse `arp -a` output (Linux or Windows format) into neighbor dicts."""
    import re
    neighbors = []
    seen = set()
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        # Match an IPv4 and a MAC anywhere on the line
        ip_m = re.search(r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})', line)
        mac_m = re.search(r'([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}', line)
        if not ip_m or not mac_m:
            continue
        ip = ip_m.group(1)
        mac = mac_m.group(0).lower().replace('-', ':')
        if mac in ('ff:ff:ff:ff:ff:ff', '00:00:00:00:00:00') or ip in seen:
            continue
        # Skip multicast / broadcast addresses
        if ip.startswith('224.') or ip.endswith('.255') or ip == '255.255.255.255':
            continue
        seen.add(ip)
        # Interface name if present (Linux: "on eth0"; Windows uses interface header)
        iface_m = re.search(r'\bon\s+(\S+)', line)
        neighbors.append({
            'ip': ip, 'mac': mac,
            'vendor': _mac_vendor(mac),
            'iface': iface_m.group(1) if iface_m else '',
        })
    return neighbors


def arp_scan(desktop=None, sweep: bool = True, subnet: str = None) -> dict:
    """
    Discover LAN neighbors via ARP.

    desktop : if None, scan is run on the LabControl server (LOCAL).
              Otherwise the scan runs on that desktop over SSH (REMOTE).
    sweep   : if True, ping-sweep the /24 first to populate the ARP cache.
    subnet  : override the /24 base (e.g. '192.168.1'); auto-derived if None.

    Returns { ok, source, host_ip, neighbors: [...], count, error }
    """
    result = {'ok': False, 'source': 'local' if desktop is None else 'remote',
              'host': 'server' if desktop is None else desktop.device_name,
              'neighbors': [], 'count': 0}

    is_windows = bool(desktop) and desktop.is_windows

    # ── Build the sweep + arp command ──
    if desktop is None:
        # LOCAL — run on the server. Detect OS by platform.
        import platform
        local_win = platform.system().lower().startswith('win')
        try:
            if sweep and subnet:
                # Fire-and-forget ping sweep to fill ARP cache
                if local_win:
                    for i in range(1, 255):
                        _subprocess.Popen(['ping', '-n', '1', '-w', '200', f'{subnet}.{i}'],
                                          stdout=_subprocess.DEVNULL, stderr=_subprocess.DEVNULL)
                else:
                    for i in range(1, 255):
                        _subprocess.Popen(['ping', '-c', '1', '-W', '1', f'{subnet}.{i}'],
                                          stdout=_subprocess.DEVNULL, stderr=_subprocess.DEVNULL)
                    import time; time.sleep(2)
            out = _subprocess.run(['arp', '-a'], capture_output=True, text=True, timeout=20)
            neighbors = _parse_arp_table(out.stdout)
            result['ok'] = True
            result['neighbors'] = neighbors
            result['count'] = len(neighbors)
        except Exception as e:
            result['error'] = str(e)
        return result

    # REMOTE — run over SSH on the desktop
    if not subnet:
        octs = desktop.ip_address.split('.')
        if len(octs) == 4:
            subnet = '.'.join(octs[:3])
    try:
        if is_windows:
            if sweep and subnet:
                sweep_cmd = (f"1..254 | ForEach-Object {{ "
                             f"Start-Process ping -ArgumentList '-n','1','-w','200','{subnet}.$_' "
                             f"-WindowStyle Hidden }}; Start-Sleep -Seconds 2; arp -a")
                cmd = _ps(sweep_cmd)
            else:
                cmd = _ps('arp -a')
        else:
            if sweep and subnet:
                cmd = (f"for i in $(seq 1 254); do ping -c1 -W1 {subnet}.$i "
                       f">/dev/null 2>&1 & done; sleep 2; arp -a 2>/dev/null || ip neigh")
            else:
                cmd = "arp -a 2>/dev/null || ip neigh"
        res = run_command(desktop, cmd)
        if not res.get('success'):
            result['error'] = res.get('detail') or res.get('stderr', 'scan failed')
            return result
        neighbors = _parse_arp_table(res.get('stdout', ''))
        result['ok'] = True
        result['neighbors'] = neighbors
        result['count'] = len(neighbors)
    except Exception as e:
        result['error'] = str(e)
    return result


# Network-infrastructure vendor hints (routers/switches/APs)
_INFRA_VENDORS = {'cisco', 'tp-link', 'netgear', 'ubiquiti', 'mikrotik',
                  'aruba', 'juniper', 'd-link', 'huawei', 'zyxel'}
_IOT_VENDORS = {'espressif', 'esp', 'raspberry pi', 'arduino', 'particle'}
_VIRTUAL_VENDORS = {'vmware', 'virtualbox', 'qemu', 'kvm', 'hyper-v', 'xen'}


def categorize_host(mac: str, ip: str, vendor: str, is_managed: bool) -> str:
    """Classify a discovered host into a category."""
    if is_managed:
        return 'managed'
    v = (vendor or '').lower()
    # Gateway addresses (.1 / .254) lean infrastructure
    last_octet = ip.split('.')[-1] if ip else ''
    if any(k in v for k in _VIRTUAL_VENDORS):
        return 'virtual'
    if any(k in v for k in _IOT_VENDORS):
        return 'iot'
    if any(k in v for k in _INFRA_VENDORS) or last_octet in ('1', '254'):
        return 'infrastructure'
    return 'unknown'
