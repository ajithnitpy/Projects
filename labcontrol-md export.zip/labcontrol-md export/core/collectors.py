"""
Collectors — periodic SSH scans that feed the tracking features.
Called by Celery tasks (or manually via management command / API).
"""
import json
import re
from datetime import timedelta
from django.utils import timezone
from django.db import models as dj_models

from . import remote_ops
from .models import (
    Desktop, LoginSession, UsageSnapshot,
    InstalledSoftware, SoftwarePolicy,
    GoldenConfig, DriftReport,
)


# ═══════════════════════════════════════════════════════════════
#  SESSION & USAGE COLLECTION
# ═══════════════════════════════════════════════════════════════

def collect_sessions(desktop) -> dict:
    """
    Poll a desktop's active login sessions and update LoginSession rows.
    Reconciles: opens new sessions, updates last_seen, closes gone ones.
    """
    now = timezone.now()
    result = {'desktop': desktop.device_name, 'active': 0, 'new': 0, 'closed': 0}

    if desktop.is_windows:
        # `query user` output: USERNAME SESSIONNAME ID STATE IDLE LOGON TIME
        out = remote_ops.run_command(desktop, 'query user')
        current = _parse_windows_query_user(out.get('stdout', ''))
    else:
        # `who -u` output: user tty date time idle pid (host)
        out = remote_ops.run_command(desktop, 'who -u')
        current = _parse_linux_who(out.get('stdout', ''))

    if not out.get('success'):
        result['error'] = out.get('detail') or out.get('stderr', 'scan failed')
        return result

    seen_keys = set()
    for sess in current:
        key = (sess['username'], sess['tty'])
        seen_keys.add(key)
        existing = LoginSession.objects.filter(
            desktop=desktop, username=sess['username'],
            tty=sess['tty'], is_active=True).first()
        if existing:
            existing.last_seen = now
            existing.idle_seconds = sess.get('idle_seconds', 0)
            existing.save(update_fields=['last_seen', 'idle_seconds'])
        else:
            LoginSession.objects.create(
                desktop=desktop, username=sess['username'],
                login_time=now, last_seen=now,
                tty=sess['tty'], source_ip=sess.get('source_ip', ''),
                idle_seconds=sess.get('idle_seconds', 0), is_active=True)
            result['new'] += 1
        result['active'] += 1

    # Close sessions no longer present
    for old in LoginSession.objects.filter(desktop=desktop, is_active=True):
        if (old.username, old.tty) not in seen_keys:
            old.is_active = False
            old.logout_time = now
            old.save(update_fields=['is_active', 'logout_time'])
            result['closed'] += 1

    # Usage snapshot for time-series
    UsageSnapshot.objects.create(
        desktop=desktop,
        logged_in_users=len(current),
        active_users=sum(1 for s in current if s.get('idle_seconds', 0) < 300),
        top_user=current[0]['username'] if current else '',
    )
    return result


def _parse_linux_who(text):
    sessions = []
    for line in text.strip().splitlines():
        parts = line.split()
        if len(parts) < 2:
            continue
        user, tty = parts[0], parts[1]
        idle_sec = 0
        source_ip = ''
        # idle field often like "00:12" or "."
        for p in parts:
            if re.match(r'^\d{2}:\d{2}$', p):
                h, m = p.split(':')
                idle_sec = int(h) * 3600 + int(m) * 60
            if p.startswith('(') and p.endswith(')'):
                source_ip = p.strip('()')
        sessions.append({'username': user, 'tty': tty,
                         'idle_seconds': idle_sec, 'source_ip': source_ip})
    return sessions


def _parse_windows_query_user(text):
    sessions = []
    lines = text.strip().splitlines()
    for line in lines[1:]:  # skip header
        # Columns are space-padded; username may have leading '>'
        cleaned = line.lstrip('>').strip()
        parts = cleaned.split()
        if len(parts) < 2:
            continue
        user = parts[0]
        # IDLE TIME column varies; try to find a state + idle
        idle_sec = 0
        for p in parts:
            if p.isdigit():
                idle_sec = int(p) * 60  # minutes → seconds (approx)
                break
            if re.match(r'^\d+:\d+$', p):
                h, m = p.split(':')
                idle_sec = int(h) * 3600 + int(m) * 60
                break
        sessions.append({'username': user, 'tty': 'console',
                         'idle_seconds': idle_sec, 'source_ip': ''})
    return sessions


# ═══════════════════════════════════════════════════════════════
#  SOFTWARE INVENTORY
# ═══════════════════════════════════════════════════════════════

def collect_software(desktop) -> dict:
    """Scan installed software and update the InstalledSoftware table."""
    result = {'desktop': desktop.device_name, 'found': 0, 'new': 0}

    if desktop.is_windows:
        cmd = remote_ops._ps(
            "Get-ItemProperty "
            "HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*, "
            "HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* "
            "| Where-Object DisplayName | "
            "Select-Object DisplayName,DisplayVersion,Publisher | ConvertTo-Json -Compress")
        out = remote_ops.run_command(desktop, cmd)
        pkgs = _parse_windows_software(out.get('stdout', ''))
        source = 'registry'
    else:
        cmd = "dpkg-query -W -f='${Package}\\t${Version}\\n' 2>/dev/null || rpm -qa"
        out = remote_ops.run_command(desktop, cmd)
        pkgs = _parse_linux_dpkg(out.get('stdout', ''))
        source = 'dpkg'

    if not out.get('success'):
        result['error'] = out.get('detail') or out.get('stderr', 'scan failed')
        return result

    now = timezone.now()
    for pkg in pkgs:
        obj, created = InstalledSoftware.objects.update_or_create(
            desktop=desktop, name=pkg['name'][:200], version=pkg['version'][:80],
            defaults={'publisher': pkg.get('publisher', '')[:200],
                      'source': source, 'last_seen': now})
        result['found'] += 1
        if created:
            result['new'] += 1

    # Remove software no longer present (older than this scan)
    InstalledSoftware.objects.filter(
        desktop=desktop, last_seen__lt=now - timedelta(minutes=1)).delete()
    return result


def _parse_linux_dpkg(text):
    pkgs = []
    for line in text.strip().splitlines():
        if '\t' in line:
            name, ver = line.split('\t', 1)
            pkgs.append({'name': name.strip(), 'version': ver.strip()})
        elif line.strip():
            pkgs.append({'name': line.strip(), 'version': ''})
    return pkgs


def _parse_windows_software(text):
    pkgs = []
    try:
        data = json.loads(text) if text.strip() else []
        if isinstance(data, dict):
            data = [data]
        for item in data:
            name = item.get('DisplayName')
            if name:
                pkgs.append({'name': name,
                             'version': item.get('DisplayVersion', '') or '',
                             'publisher': item.get('Publisher', '') or ''})
    except (json.JSONDecodeError, ValueError):
        pass
    return pkgs


def check_software_compliance(desktop) -> dict:
    """Check a desktop against active SoftwarePolicy rules."""
    result = {'desktop': desktop.device_name, 'violations': []}
    policies = SoftwarePolicy.objects.filter(is_active=True).filter(
        dj_models.Q(applies_to_lab__isnull=True) |
        dj_models.Q(applies_to_lab=desktop.location))
    installed = list(desktop.software.all())

    for pol in policies:
        matches = [s for s in installed
                   if pol.match_pattern.lower() in s.name.lower()]
        if pol.rule == 'required' and not matches:
            result['violations'].append(
                {'rule': 'required', 'software': pol.match_pattern,
                 'detail': 'Required software not installed'})
        elif pol.rule == 'forbidden' and matches:
            result['violations'].append(
                {'rule': 'forbidden', 'software': pol.match_pattern,
                 'detail': f'Forbidden software present: {matches[0].name}'})
    return result


# ═══════════════════════════════════════════════════════════════
#  CONFIGURATION DRIFT
# ═══════════════════════════════════════════════════════════════

def check_drift(desktop) -> dict:
    """Compare a desktop against its lab's active golden config."""
    result = {'desktop': desktop.device_name, 'has_drift': False, 'issues': 0}

    golden = GoldenConfig.objects.filter(
        lab=desktop.location, is_active=True,
        os_family=('windows' if desktop.is_windows else 'linux')).first()
    if not golden:
        result['error'] = 'No golden config for this lab/OS'
        return result

    missing_pkgs = []
    stopped_svcs = []
    changed_files = []

    # Package check
    expected_pkgs = _load_json(golden.expected_packages, [])
    if expected_pkgs:
        installed_names = set(
            s.name.lower() for s in desktop.software.all())
        for pkg in expected_pkgs:
            if pkg.lower() not in installed_names:
                missing_pkgs.append(pkg)

    # Service check
    expected_svcs = _load_json(golden.expected_services, [])
    for svc in expected_svcs:
        if desktop.is_windows:
            cmd = remote_ops._ps(f"(Get-Service '{svc}').Status")
        else:
            cmd = f'systemctl is-active {svc}'
        out = remote_ops.run_command(desktop, cmd)
        status = (out.get('stdout', '') or '').strip().lower()
        if 'running' not in status and 'active' not in status:
            stopped_svcs.append(svc)

    # File checksum check
    expected_files = _load_json(golden.expected_files, {})
    for path, expected_hash in expected_files.items():
        if desktop.is_windows:
            cmd = remote_ops._ps(f"(Get-FileHash '{path}' -Algorithm SHA256).Hash")
        else:
            cmd = f'sha256sum {path} 2>/dev/null | cut -d" " -f1'
        out = remote_ops.run_command(desktop, cmd)
        actual = (out.get('stdout', '') or '').strip().lower()
        if actual and actual != expected_hash.lower():
            changed_files.append(path)

    drift_count = len(missing_pkgs) + len(stopped_svcs) + len(changed_files)
    has_drift = drift_count > 0

    DriftReport.objects.create(
        desktop=desktop, golden=golden, has_drift=has_drift,
        missing_packages=json.dumps(missing_pkgs),
        stopped_services=json.dumps(stopped_svcs),
        changed_files=json.dumps(changed_files),
        drift_count=drift_count)

    result['has_drift'] = has_drift
    result['issues'] = drift_count
    result['missing_packages'] = missing_pkgs
    result['stopped_services'] = stopped_svcs
    result['changed_files'] = changed_files
    return result


def _load_json(text, default):
    try:
        return json.loads(text) if text.strip() else default
    except (json.JSONDecodeError, ValueError):
        return default


# Fix: import dj_models.Q lazily


# ═══════════════════════════════════════════════════════════════
#  NEIGHBOR DISCOVERY PERSISTENCE (dedup by MAC, log sightings)
# ═══════════════════════════════════════════════════════════════

def record_discovery(scan_result: dict) -> dict:
    """
    Persist an arp_scan() result into DiscoveredHost (deduplicated) +
    HostSighting (audit log). Returns a summary.

    Dedup key: MAC address; falls back to ip:<addr> when no MAC.
    Updates existing rows in place (last_seen, times_seen, IP, source flags).
    """
    from .models import DiscoveredHost, HostSighting, Desktop
    from . import remote_ops

    if not scan_result.get('ok'):
        return {'ok': False, 'error': scan_result.get('error', 'scan failed')}

    source = scan_result.get('source', 'local')   # local | remote
    scanned_by = scan_result.get('host', 'server')

    known_by_ip = {d.ip_address: d for d in Desktop.objects.all()}
    known_by_mac = {(d.mac_address or '').lower(): d
                    for d in Desktop.objects.all() if d.mac_address}

    created = updated = 0
    by_category = {}

    for n in scan_result.get('neighbors', []):
        mac = (n.get('mac') or '').lower()
        ip = n.get('ip', '')
        vendor = n.get('vendor', '')
        desktop = known_by_ip.get(ip) or known_by_mac.get(mac)
        category = remote_ops.categorize_host(mac, ip, vendor, bool(desktop))
        by_category[category] = by_category.get(category, 0) + 1

        # Find existing by MAC, else by IP (when no MAC)
        host = None
        if mac:
            host = DiscoveredHost.objects.filter(mac=mac).first()
        if host is None and not mac:
            host = DiscoveredHost.objects.filter(ip=ip, mac='').first()

        if host:
            # Update in place — dedup
            host.ip = ip
            host.vendor = vendor or host.vendor
            host.category = category
            host.desktop = desktop
            host.last_source = source
            host.discovered_via = scanned_by
            if source == 'local':
                host.seen_local = True
            else:
                host.seen_remote = True
            host.times_seen = (host.times_seen or 0) + 1
            host.save()
            updated += 1
        else:
            host = DiscoveredHost.objects.create(
                mac=mac, ip=ip, vendor=vendor, category=category,
                desktop=desktop, first_source=source, last_source=source,
                discovered_via=scanned_by,
                seen_local=(source == 'local'), seen_remote=(source == 'remote'),
                times_seen=1,
                hostname=(desktop.device_name if desktop else ''))
            created += 1

        # Append a sighting record
        HostSighting.objects.create(
            host=host, ip=ip, source=source, scanned_by=scanned_by)

    return {
        'ok': True, 'source': source, 'scanned_by': scanned_by,
        'total': created + updated, 'created': created, 'updated': updated,
        'by_category': by_category,
    }
