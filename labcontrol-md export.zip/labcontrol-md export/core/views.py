"""
LabControl Views
================
HTTP views for the lab desktop automation dashboard.
"""
import json
import time
from datetime import timedelta

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.utils import timezone
from django.db.models import Count, Q
from django.conf import settings
from django.views.decorators.http import require_POST

from .models import (
    Desktop, Location, DesktopUser,
    ActivityLog, PowerLog, ShellCommandLog, FileOperationLog,
    RemoteUserMgmtLog, ScanLog,
)
from .forms import (
    DesktopForm, LocationForm, ShellForm,
    CreateRemoteUserForm, FileBrowserForm, BulkScanForm,
)
from . import remote_ops
from .middleware import log_activity


# ─── Dashboard / Tile View ─────────────────────────────────────

@login_required
def dashboard(request):
    """Tile-card overview grouped by location."""
    locations = Location.objects.prefetch_related('desktops').all()
    ungrouped = Desktop.objects.filter(location__isnull=True)

    desktops_qs = Desktop.objects.all()
    stats = {
        'total':    desktops_qs.count(),
        'online':   desktops_qs.filter(status='online').count(),
        'offline':  desktops_qs.filter(status='offline').count(),
        'unknown':  desktops_qs.filter(status='unknown').count(),
        'locations':locations.count(),
    }

    recent_power    = PowerLog.objects.select_related('desktop','user')[:8]
    recent_activity = ActivityLog.objects.select_related('user')[:8]

    # One flat, filterable list rather than a tile section per lab — 231
    # desktops as grouped tiles meant ~1800px of scrolling to reach the last
    # lab. select_related keeps the Laboratory column to a single query.
    all_desktops = (Desktop.objects
                    .select_related('location')
                    .order_by('location__name', 'device_name'))

    # dashboard.html extends base.html (Tailwind), matching every other classic
    # page. dashboard_ace.html is the older Ace/Bootstrap variant, now unused.
    return render(request, 'core/dashboard.html', {
        'lab_name': settings.LAB_NAME,
        'all_desktops': all_desktops,
        'locations': locations,
        'ungrouped': ungrouped,
        'stats': stats,
        'recent_power': recent_power,
        'recent_activity': recent_activity,
    })


# ─── Desktop CRUD ──────────────────────────────────────────────

@login_required
def desktop_list(request):
    desktops = Desktop.objects.select_related('location').all()
    q = request.GET.get('q', '')
    loc = request.GET.get('loc', '')
    status = request.GET.get('status', '')
    if q:
        desktops = desktops.filter(
            Q(device_name__icontains=q) | Q(ip_address__icontains=q)
            | Q(make__icontains=q) | Q(model__icontains=q))
    if loc:
        desktops = desktops.filter(location_id=loc)
    if status:
        desktops = desktops.filter(status=status)

    from .models import Application

    # Left-navigator lab rows carry live online/total counts. Annotated
    # across the whole fleet, not the filtered queryset, so the counts stay
    # meaningful while a filter is applied.
    lab_rows = Location.objects.annotate(
        total=Count('desktops'),
        online=Count('desktops', filter=Q(desktops__status='online')),
    )

    return render(request, 'core/desktop_list.html', {
        'desktops':  desktops,
        'locations': Location.objects.all(),
        'lab_rows':  lab_rows,
        'applications': Application.objects.filter(is_active=True),
        'q': q, 'loc': loc, 'status': status,
    })


@login_required
def desktop_add(request):
    if request.method == 'POST':
        form = DesktopForm(request.POST)
        if form.is_valid():
            d = form.save(commit=False)
            d.added_by = request.user
            pw = form.cleaned_data.get('ssh_password')
            sp = form.cleaned_data.get('sudo_password')
            if pw: d.ssh_password = pw
            if sp: d.sudo_password = sp
            d.save()
            log_activity(request.user, 'desktop.add', d.device_name,
                         request=request)
            messages.success(request, f'Desktop "{d.device_name}" added.')
            return redirect('desktop_detail', pk=d.pk)
    else:
        form = DesktopForm()
    return render(request, 'core/desktop_form.html',
                  {'form': form, 'title': 'Add Desktop'})


@login_required
def desktop_edit(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    if request.method == 'POST':
        form = DesktopForm(request.POST, instance=d)
        if form.is_valid():
            obj = form.save(commit=False)
            pw = form.cleaned_data.get('ssh_password')
            sp = form.cleaned_data.get('sudo_password')
            if pw: obj.ssh_password = pw
            if sp: obj.sudo_password = sp
            obj.save()
            log_activity(request.user, 'desktop.edit', d.device_name,
                         request=request)
            messages.success(request, f'Desktop "{d.device_name}" updated.')
            return redirect('desktop_detail', pk=d.pk)
    else:
        form = DesktopForm(instance=d)
    return render(request, 'core/desktop_form.html',
                  {'form': form, 'title': f'Edit: {d.device_name}', 'desktop': d})


@login_required
def desktop_delete(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    if request.method == 'POST':
        name = d.device_name
        d.delete()
        log_activity(request.user, 'desktop.delete', name, request=request)
        messages.success(request, f'Desktop "{name}" deleted.')
        return redirect('dashboard')
    return render(request, 'core/desktop_confirm_delete.html', {'desktop': d})


@login_required
def desktop_detail(request, pk):
    d = get_object_or_404(Desktop, pk=pk)

    shell_form = ShellForm()
    file_form  = FileBrowserForm(initial={'path': d.default_browse_path})
    user_form  = CreateRemoteUserForm()

    return render(request, 'core/desktop_detail.html', {
        'desktop':    d,
        'shell_form': shell_form,
        'file_form':  file_form,
        'user_form':  user_form,
        'shell_logs': d.shell_logs.all()[:15],
        'power_logs': d.power_logs.all()[:10],
        'file_logs':  d.file_logs.all()[:10],
        'mgmt_logs':  d.user_mgmt_logs.all()[:10],
        'os_users':   d.os_users.all(),
    })


# ─── Power management ──────────────────────────────────────────

@login_required
@require_POST
def desktop_power_on(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    res = remote_ops.power_on(d)
    PowerLog.objects.create(
        desktop=d, user=request.user, action='wol_on',
        success=res['success'], detail=res.get('detail',''),
    )
    if res['success']:
        d.status = 'booting'
        d.save(update_fields=['status'])
        messages.success(request, f'Wake-on-LAN packet sent to {d.device_name}')
    else:
        messages.error(request, f'WoL failed: {res.get("detail")}')
    return redirect(request.META.get('HTTP_REFERER',
                    f'/desktops/{pk}/'))


@login_required
@require_POST
def desktop_power_off(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    mode = request.POST.get('mode', 'shutdown')
    res = remote_ops.power_off(d, mode=mode)
    PowerLog.objects.create(
        desktop=d, user=request.user, action=mode,
        success=res['success'], detail=res.get('detail','')[:1000],
    )
    if res['success']:
        d.status = 'shutdown'
        d.save(update_fields=['status'])
        messages.success(request, f'{mode.title()} sent to {d.device_name}')
    else:
        messages.error(request, f'Power-off failed: {res.get("detail")}')
    return redirect(request.META.get('HTTP_REFERER', f'/desktops/{pk}/'))


@login_required
@require_POST
def desktop_ping(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    res = remote_ops.ping_host(d.ip_address)
    if res['alive']:
        d.status = 'online'
        d.last_seen = timezone.now()
        d.last_ping_ms = res.get('rtt_ms')
    else:
        d.status = 'offline'
    d.save()
    return JsonResponse({
        'status': d.status,
        'rtt_ms': d.last_ping_ms,
        'alive':  res['alive'],
    })


# ─── Shell ─────────────────────────────────────────────────────

@login_required
@require_POST
def desktop_shell_run(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    form = ShellForm(request.POST)
    if not form.is_valid():
        messages.error(request, 'Invalid command form.')
        return redirect('desktop_detail', pk=pk)

    cmd     = form.cleaned_data['command']
    backend = form.cleaned_data['backend']
    use_sudo= form.cleaned_data['use_sudo']

    res = remote_ops.run_command(d, cmd, backend=backend, use_sudo=use_sudo)

    ShellCommandLog.objects.create(
        desktop=d, user=request.user, command=cmd[:2000],
        stdout=res.get('stdout','')[:8000],
        stderr=res.get('stderr','')[:4000],
        exit_code=res.get('exit_code'),
        duration_ms=res.get('duration_ms'),
        used_sudo=use_sudo, backend=res.get('backend', backend)[:20],
    )
    if res.get('success'):
        messages.success(request, f'Command OK (exit {res["exit_code"]}, '
                                   f'{res["duration_ms"]}ms)')
    else:
        messages.error(request, f'Command failed: {res.get("detail","")}')
    return redirect('desktop_detail', pk=pk)


# ─── File Browser ──────────────────────────────────────────────

@login_required
def desktop_files(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    path = request.GET.get('path') or d.default_browse_path
    res  = remote_ops.sftp_list_dir(d, path)

    FileOperationLog.objects.create(
        desktop=d, user=request.user, operation='list',
        target_path=path, file_count=len(res.get('entries',[])),
        success=res['success'], detail=res.get('detail','')[:500],
    )

    return render(request, 'core/file_browser.html', {
        'desktop': d, 'path': path, 'result': res,
    })


@login_required
def desktop_file_view(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    path = request.GET.get('path', '')
    res = remote_ops.sftp_read_file(d, path)
    FileOperationLog.objects.create(
        desktop=d, user=request.user, operation='view',
        target_path=path, success=res['success'],
        bytes_size=len(res.get('content','')),
        detail=res.get('detail','')[:500],
    )
    return render(request, 'core/file_view.html', {
        'desktop': d, 'path': path, 'result': res,
    })


@login_required
@require_POST
def desktop_file_delete(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    path = request.POST.get('path', '')
    res = remote_ops.sftp_delete_file(d, path)
    FileOperationLog.objects.create(
        desktop=d, user=request.user, operation='delete',
        target_path=path, success=res['success'],
        detail=res.get('detail','')[:500],
    )
    if res['success']:
        messages.success(request, f'Deleted: {path}')
    else:
        messages.error(request, f'Delete failed: {res.get("detail")}')

    # Detect parent directory using whichever separator dominates
    if d.is_windows and '\\' in path:
        parent = '\\'.join(path.split('\\')[:-1]) or 'C:\\'
    else:
        parent = '/'.join(path.split('/')[:-1]) or '/'
    return redirect(f'/desktops/{pk}/files/?path={parent}')


@login_required
@require_POST
def desktop_purge_user_home(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    target = request.POST.get('target_user', '').strip()
    if not target:
        messages.error(request, 'Target user required.')
        return redirect('desktop_detail', pk=pk)

    res = remote_ops.purge_user_home(d, target_user=target)

    home_label = (f'C:\\Users\\{target}' if d.is_windows
                  else f'/home/{target}')
    FileOperationLog.objects.create(
        desktop=d, user=request.user, operation='purge_home',
        target_path=home_label, target_user=target,
        success=res['success'], detail=res.get('detail','')[:1000],
    )
    if res['success']:
        messages.success(request, f"Purged {home_label} on {d.device_name}")
    else:
        messages.error(request, f"Purge failed: {res.get('detail')}")
    return redirect('desktop_detail', pk=pk)


# ─── Remote OS User Management ─────────────────────────────────

@login_required
@require_POST
def desktop_user_create(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    form = CreateRemoteUserForm(request.POST)
    if not form.is_valid():
        messages.error(request, 'Invalid user form.')
        return redirect('desktop_detail', pk=pk)
    cd = form.cleaned_data
    res = remote_ops.user_create_remote(
        d, username=cd['username'], password=cd['password'],
        full_name=cd['full_name'], create_home=cd['create_home'],
    )
    RemoteUserMgmtLog.objects.create(
        desktop=d, user=request.user, operation='create',
        target_user=cd['username'], success=res['success'],
        detail=res.get('detail','')[:500],
    )
    if res['success']:
        home_dir = (f'C:\\Users\\{cd["username"]}' if d.is_windows
                    else f'/home/{cd["username"]}')
        DesktopUser.objects.update_or_create(
            desktop=d, username=cd['username'],
            defaults={'full_name': cd['full_name'],
                      'home_dir': home_dir})
        messages.success(request, f'Created user {cd["username"]} on {d.device_name}')
    else:
        messages.error(request, f'Create failed: {res.get("detail")}')
    return redirect('desktop_detail', pk=pk)


@login_required
@require_POST
def desktop_user_delete(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    target = request.POST.get('target_user', '').strip()
    res = remote_ops.user_delete_remote(d, username=target, remove_home=True)
    RemoteUserMgmtLog.objects.create(
        desktop=d, user=request.user, operation='delete',
        target_user=target, success=res['success'],
        detail=res.get('detail','')[:500],
    )
    if res['success']:
        DesktopUser.objects.filter(desktop=d, username=target).delete()
        messages.success(request, f'Deleted user {target}')
    else:
        messages.error(request, f'Delete failed: {res.get("detail")}')
    return redirect('desktop_detail', pk=pk)


@login_required
@require_POST
def desktop_user_lock(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    target = request.POST.get('target_user', '').strip()
    unlock = request.POST.get('unlock') == '1'
    res = remote_ops.user_lock_remote(d, username=target, unlock=unlock)
    op = 'unlock' if unlock else 'lock'
    RemoteUserMgmtLog.objects.create(
        desktop=d, user=request.user, operation=op,
        target_user=target, success=res['success'],
        detail=res.get('detail','')[:500],
    )
    DesktopUser.objects.filter(desktop=d, username=target).update(
        is_locked=not unlock)
    messages.info(request, f'{op.title()} user {target}: '
                           f'{"OK" if res["success"] else "FAILED"}')
    return redirect('desktop_detail', pk=pk)


@login_required
@require_POST
def desktop_users_discover(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    res = remote_ops.user_discover_remote(d)
    RemoteUserMgmtLog.objects.create(
        desktop=d, user=request.user, operation='discover',
        target_user='*', success=res['success'],
        detail=f'Found {len(res.get("users", []))} users',
    )
    if res['success']:
        for u in res['users']:
            DesktopUser.objects.update_or_create(
                desktop=d, username=u['username'],
                defaults={
                    'uid': u['uid'], 'gid': u['gid'],
                    'full_name': (u.get('gecos') or '').split(',')[0],
                    'home_dir': u.get('home',''),
                    'shell':    u.get('shell',''),
                    'is_locked':u.get('is_locked', False),
                },
            )
        messages.success(request, f'Discovered {len(res["users"])} users on {d.device_name}')
    else:
        messages.error(request, f'Discovery failed: {res.get("detail")}')
    return redirect('desktop_detail', pk=pk)


# ─── Bulk Scan (single click across all desktops) ─────────────

@login_required
def bulk_scan(request):
    if request.method == 'POST':
        form = BulkScanForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            qs = Desktop.objects.filter(is_managed=True)
            if cd['location']:
                qs = qs.filter(location=cd['location'])
            desktops = list(qs)

            scan = ScanLog.objects.create(
                user=request.user, scan_type=cd['scan_type'],
                parameter=cd['parameter'] or '',
                target_count=len(desktops),
            )
            t0 = time.time()

            scan_type = cd['scan_type']
            param     = cd['parameter']

            def _runner(d):
                if scan_type == 'discover_users':
                    return remote_ops.user_discover_remote(d)
                if scan_type == 'disk_usage':
                    return remote_ops.cmd_disk_usage(d)
                if scan_type == 'uptime':
                    return remote_ops.cmd_uptime(d)
                if scan_type == 'logged_users':
                    return remote_ops.cmd_logged_users(d)
                if scan_type == 'os_inventory':
                    return remote_ops.cmd_os_inventory(d)
                if scan_type == 'purge_user_home':
                    if not param or not cd.get('confirm'):
                        return {'success': False,
                                'detail': 'Confirm checkbox + username required'}
                    return remote_ops.purge_user_home(d, target_user=param)
                if scan_type == 'custom':
                    return remote_ops.run_command(d, param or 'hostname')
                return {'success': False, 'detail': 'unknown scan type'}

            results = remote_ops.bulk_run(desktops, _runner,
                                          max_workers=settings.SCAN_MAX_WORKERS)

            ok = sum(1 for r in results if r.get('success'))
            scan.success_count = ok
            scan.failure_count = len(results) - ok
            scan.completed_at  = timezone.now()
            scan.duration_ms   = int((time.time() - t0) * 1000)
            scan.results_text  = json.dumps(results, default=str, indent=2)[:50000]
            scan.save()

            if scan_type == 'discover_users':
                for r in results:
                    if not r.get('success'):
                        continue
                    d = next((x for x in desktops
                              if x.device_name == r['device_name']), None)
                    if d:
                        for u in r.get('users', []):
                            DesktopUser.objects.update_or_create(
                                desktop=d, username=u['username'],
                                defaults={
                                    'uid': u['uid'], 'gid': u['gid'],
                                    'full_name':(u.get('gecos') or '').split(',')[0],
                                    'home_dir': u.get('home',''),
                                    'shell':    u.get('shell',''),
                                    'is_locked':u.get('is_locked', False),
                                },
                            )

            return render(request, 'core/scan_result.html', {
                'scan': scan, 'results': results,
            })
    else:
        form = BulkScanForm()

    recent = ScanLog.objects.all()[:15]
    return render(request, 'core/bulk_scan.html',
                  {'form': form, 'recent': recent})


# ─── Locations CRUD ────────────────────────────────────────────

@login_required
def location_manage(request):
    if request.method == 'POST':
        form = LocationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Location created.')
            return redirect('location_manage')
    else:
        form = LocationForm()

    from .models import Application, ScheduledTask

    locations = Location.objects.annotate(
        total = Count('desktops'),
        online= Count('desktops', filter=Q(desktops__status='online'))
    )
    return render(request, 'core/location_manage.html', {
        'form': form,
        'locations': locations,
        'applications': Application.objects.filter(is_active=True),
        'tasks': ScheduledTask.objects.select_related('lab').all(),
        'task_types': ScheduledTask.TASK_CHOICES,
    })


@login_required
def location_delete(request, pk):
    loc = get_object_or_404(Location, pk=pk)
    if request.method == 'POST':
        loc.delete()
        messages.success(request, 'Location deleted.')
    return redirect('location_manage')


# ─── Exam preparation: bulk-clear user data ───────────────────

@login_required
def exam_prep(request):
    """
    Make a lab exam-ready: clear student home folders across a whole lab in
    one operation, and optionally uninstall apps that must not be available
    during an exam.

    Read-only view — every action posts to /api/bulk-purge/ or
    /api/bulk-deploy/ so it streams into the ops terminal like everything
    else.
    """
    from .models import Application, FileOperationLog

    locations = Location.objects.annotate(
        total=Count('desktops'),
        online=Count('desktops', filter=Q(desktops__status='online')))

    # Recently seen OS accounts, so the operator can pick rather than type
    # (typing is where a wrong username comes from).
    known_users = (DesktopUser.objects
                   .values_list('username', flat=True)
                   .distinct().order_by('username')[:200])

    recent = (FileOperationLog.objects
              .filter(operation__in=['purge_home', 'scan_home'])
              .select_related('desktop', 'user')[:15])

    return render(request, 'core/exam_prep.html', {
        'locations': locations,
        'applications': Application.objects.filter(is_active=True),
        'known_users': known_users,
        'recent': recent,
    })


# ─── Icon-grid fleet monitor ──────────────────────────────────

@login_required
def monitor(request):
    """
    Dense icon-grid view of the whole fleet.

    The tile dashboard needs ~1800px of scroll at 231 desktops. This page
    keeps the chrome (toolbar, lab tabs, legend) fixed and scrolls only the
    grid, and defaults to one lab at a time so a lab fits on one screen.
    """
    locations = (Location.objects
                 .prefetch_related('desktops')
                 .annotate(total=Count('desktops'),
                           online=Count('desktops',
                                        filter=Q(desktops__status='online'))))
    ungrouped = Desktop.objects.filter(location__isnull=True)

    qs = Desktop.objects.all()
    stats = {
        'total':   qs.count(),
        'online':  qs.filter(status='online').count(),
        'offline': qs.filter(status='offline').count(),
        'unknown': qs.exclude(status__in=['online', 'offline']).count(),
    }
    return render(request, 'core/monitor.html', {
        'lab_name':  settings.LAB_NAME,
        'locations': locations,
        'ungrouped': ungrouped,
        'stats':     stats,
    })


# ─── Audit Log Views ──────────────────────────────────────────

@login_required
def audit_logs(request):
    tab = request.GET.get('tab', 'activity')

    page = {
        'activity':  ('Activity Log',
                      ActivityLog.objects.select_related('user')[:200]),
        'power':     ('Power Log',
                      PowerLog.objects.select_related('desktop','user')[:200]),
        'shell':     ('Shell Command Log',
                      ShellCommandLog.objects.select_related('desktop','user')[:200]),
        'files':     ('File Operations Log',
                      FileOperationLog.objects.select_related('desktop','user')[:200]),
        'usermgmt':  ('Remote User Mgmt Log',
                      RemoteUserMgmtLog.objects.select_related('desktop','user')[:200]),
        'scans':     ('Scan Log',
                      ScanLog.objects.select_related('user')[:100]),
    }

    title, logs = page.get(tab, page['activity'])
    return render(request, 'core/audit_logs.html', {
        'tab': tab, 'title': title, 'logs': logs,
    })


# ─── Application Catalog & Installation ─────────────────────────

@login_required
def app_catalog(request):
    """List the application catalog and let user pick apps + desktops to install."""
    from .models import Application, InstallJob
    apps = Application.objects.filter(is_active=True)
    desktops = Desktop.objects.filter(is_managed=True).select_related('location')
    recent_jobs = InstallJob.objects.select_related(
        'desktop', 'application', 'user')[:20]

    # Group apps by category
    grouped = {}
    for a in apps:
        grouped.setdefault(a.get_category_display(), []).append(a)

    return render(request, 'core/app_catalog.html', {
        'grouped_apps': grouped,
        'desktops': desktops,
        'recent_jobs': recent_jobs,
    })


@login_required
@require_POST
def app_install(request):
    """Install one or more checked apps onto one or more checked desktops."""
    from .models import Application, InstallJob
    app_ids     = request.POST.getlist('app_ids')
    desktop_ids = request.POST.getlist('desktop_ids')

    if not app_ids or not desktop_ids:
        messages.error(request, 'Select at least one app AND one desktop.')
        return redirect('app_catalog')

    apps     = Application.objects.filter(pk__in=app_ids, is_active=True)
    desktops = Desktop.objects.filter(pk__in=desktop_ids, is_managed=True)

    total = ok = fail = 0
    for d in desktops:
        for app in apps:
            cmd = app.install_command(d)
            res = remote_ops.run_command(d, cmd, use_sudo=not d.is_windows)
            InstallJob.objects.create(
                desktop=d, application=app, user=request.user,
                command=cmd[:2000],
                stdout=res.get('stdout','')[:6000],
                stderr=res.get('stderr','')[:3000],
                exit_code=res.get('exit_code'),
                success=res.get('success', False),
                duration_ms=res.get('duration_ms'),
            )
            total += 1
            if res.get('success'):
                ok += 1
            else:
                fail += 1

    messages.success(request,
        f'Install complete: {ok}/{total} succeeded, {fail} failed '
        f'across {desktops.count()} desktop(s).')
    return redirect('app_catalog')


# ─── AI Assistant (Local LLM via Ollama) ──────────────────────

@login_required
def ai_assistant(request):
    """
    Chat-style page where an admin types 'install firefox' (or any
    natural-language request) and the local LLM generates a structured
    Application record ready to save to the catalog.
    """
    from . import ai_agent
    from .models import Application, AIConversation

    # Check if Ollama is running
    status = ai_agent.is_available()

    # Recent conversation history (this user)
    recent = AIConversation.objects.filter(user=request.user)[:15]

    return render(request, 'core/ai_assistant.html', {
        'ollama_status': status,
        'recent':        recent,
    })


@login_required
@require_POST
def ai_generate(request):
    """
    Handle ANY chat query — troubleshooting, commands, installs, etc.
    Uses ai_agent.ask() which returns text + optional APP_JSON.
    """
    from . import ai_agent
    from .models import AIConversation

    prompt = (request.POST.get('prompt') or '').strip()
    if not prompt:
        return JsonResponse({'ok': False, 'error': 'Empty prompt'})

    result = ai_agent.ask(prompt)

    # Log the conversation
    conv = AIConversation.objects.create(
        user=request.user,
        prompt=prompt,
        response=result.get('response', ''),
        success=result.get('ok', False),
        model=result.get('model', ''),
        duration_ms=result.get('duration_ms'),
        error=result.get('error', '')[:500],
    )

    return JsonResponse({
        'ok':          result.get('ok', False),
        'response':    result.get('response', ''),
        'app':         result.get('app'),
        'error':       result.get('error', ''),
        'duration_ms': result.get('duration_ms'),
        'model':       result.get('model'),
        'conv_id':     conv.pk,
    })


@login_required
@require_POST
def ai_save_app(request):
    """
    Save the AI-generated Application to the catalog. Called when the
    admin clicks "Add to Catalog" after previewing the LLM output.
    """
    from .models import Application, AIConversation

    try:
        data = json.loads(request.body.decode('utf-8'))
    except json.JSONDecodeError:
        return JsonResponse({'ok': False, 'error': 'Invalid JSON'})

    app_data = data.get('app') or {}
    conv_id  = data.get('conv_id')

    if not app_data.get('name'):
        return JsonResponse({'ok': False, 'error': 'Missing app name'})

    # Avoid duplicates — update if name exists
    app, created = Application.objects.update_or_create(
        name=app_data['name'],
        defaults={
            'description':    app_data.get('description', ''),
            'category':       app_data.get('category', 'other'),
            'linux_pkg':      app_data.get('linux_pkg', ''),
            'linux_method':   app_data.get('linux_method', 'apt'),
            'windows_pkg':    app_data.get('windows_pkg', ''),
            'windows_method': app_data.get('windows_method', 'winget'),
            'custom_linux':   app_data.get('custom_linux', ''),
            'custom_windows': app_data.get('custom_windows', ''),
            'is_active':      True,
        },
    )

    # Link the conversation to the created app for traceability
    if conv_id:
        AIConversation.objects.filter(pk=conv_id).update(app_created=app)

    return JsonResponse({
        'ok':      True,
        'app_id':  app.pk,
        'created': created,
        'name':    app.name,
    })


# ─── Change hostname / IP on remote desktop ──────────────────

@login_required
@require_POST
def desktop_change_hostname(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    new_name = (request.POST.get('new_hostname') or '').strip()
    if not new_name:
        messages.error(request, 'Hostname required.')
        return redirect('desktop_detail', pk=pk)
    res = remote_ops.change_hostname(d, new_name)
    ShellCommandLog.objects.create(
        desktop=d, user=request.user,
        command=f'[change hostname → {new_name}]',
        stdout=res.get('stdout','')[:4000], stderr=res.get('stderr','')[:2000],
        exit_code=res.get('exit_code'), duration_ms=res.get('duration_ms'),
        used_sudo=not d.is_windows, backend='paramiko',
    )
    if res.get('success'):
        d.device_name = new_name
        d.save(update_fields=['device_name'])
        messages.success(request, f'Hostname changed to {new_name}')
    else:
        messages.error(request, f"Change failed: {res.get('detail') or res.get('stderr') or 'unknown'}")
    return redirect('desktop_detail', pk=pk)


@login_required
@require_POST
def desktop_change_ip(request, pk):
    d = get_object_or_404(Desktop, pk=pk)
    new_ip = (request.POST.get('new_ip') or '').strip()
    netmask= (request.POST.get('netmask') or '24').strip()
    gateway= (request.POST.get('gateway') or '').strip()
    iface  = (request.POST.get('interface') or '').strip()
    if not new_ip:
        messages.error(request, 'New IP required.')
        return redirect('desktop_detail', pk=pk)
    res = remote_ops.change_ip_address(d, new_ip, netmask=netmask,
                                       gateway=gateway, interface=iface)
    ShellCommandLog.objects.create(
        desktop=d, user=request.user,
        command=f'[change IP → {new_ip}/{netmask}]',
        stdout=res.get('stdout','')[:4000], stderr=res.get('stderr','')[:2000],
        exit_code=res.get('exit_code'), duration_ms=res.get('duration_ms'),
        used_sudo=not d.is_windows, backend='paramiko',
    )
    if res.get('success'):
        d.ip_address = new_ip
        d.save(update_fields=['ip_address'])
        messages.success(request, f'IP changed to {new_ip}/{netmask} — update DNS if needed')
    else:
        messages.error(request,
            f"Change failed: {res.get('detail') or res.get('stderr') or 'unknown'}")
    return redirect('desktop_detail', pk=pk)


# ─── Discovery scanner ──────────────────────────────────────

@login_required
def discovery(request):
    """Scan a subnet for live devices + report which aren't in the DB yet."""
    from .models import ScanLog
    cidr = request.GET.get('cidr', '192.168.1.0/24')
    results = []
    scanned = 0
    if request.GET.get('scan') == '1':
        # discover_subnet returns {'subnet', 'hosts', 'scanned'}, or a dict
        # carrying 'error' for an invalid or oversized (> /24) CIDR.
        scan = remote_ops.discover_subnet(cidr)
        if scan.get('error'):
            messages.error(request, f"Scan failed: {scan['error']}")
        else:
            results = scan.get('hosts', [])
            scanned = scan.get('scanned', 0)
            known_ips = set(Desktop.objects.values_list('ip_address', flat=True))
            for r in results:
                r['in_db'] = r['ip'] in known_ips
            # target_count = addresses probed; success/failure split the hosts
            # that answered by whether SSH (and so management) is reachable.
            ScanLog.objects.create(
                user=request.user, scan_type='discovery', parameter=cidr,
                target_count=scanned,
                success_count=sum(1 for r in results if r.get('ssh_open')),
                failure_count=sum(1 for r in results if not r.get('ssh_open')),
                results_text=json.dumps(results, default=str)[:20000],
                completed_at=timezone.now(),
            )
    return render(request, 'core/discovery.html', {
        'cidr': cidr, 'results': results, 'scanned': scanned,
    })


# ─── Bulk actions on multiple desktops ──────────────────────

@login_required
@require_POST
def bulk_action(request):
    """
    Run one action (shell command | delete-user | install-app) across many
    desktops selected via checkbox from the device list.
    """
    action = request.POST.get('action', 'shell')
    ids = request.POST.getlist('desktop_ids')
    desktops = Desktop.objects.filter(pk__in=ids, is_managed=True)
    if not desktops:
        messages.error(request, 'No desktops selected.')
        return redirect('desktop_list')

    results = []

    if action == 'shell':
        cmd = request.POST.get('command', '').strip()
        if not cmd:
            messages.error(request, 'Command required.')
            return redirect('desktop_list')
        def _runner(d):
            use_sudo = (request.POST.get('use_sudo') == '1'
                        and not d.is_windows)
            r = remote_ops.run_command(d, cmd, use_sudo=use_sudo)
            ShellCommandLog.objects.create(
                desktop=d, user=request.user, command=cmd[:2000],
                stdout=r.get('stdout','')[:6000], stderr=r.get('stderr','')[:3000],
                exit_code=r.get('exit_code'), duration_ms=r.get('duration_ms'),
                used_sudo=use_sudo, backend=r.get('backend','paramiko')[:20],
            )
            return r
        results = remote_ops.bulk_run(list(desktops), _runner)

    elif action == 'delete_user':
        target = (request.POST.get('target_user') or '').strip()
        if not target:
            messages.error(request, 'Target username required.')
            return redirect('desktop_list')
        def _runner(d):
            r = remote_ops.user_delete_remote(d, username=target,
                                               remove_home=True)
            RemoteUserMgmtLog.objects.create(
                desktop=d, user=request.user, operation='delete',
                target_user=target, success=r.get('success', False),
                detail=r.get('detail','')[:500],
            )
            return r
        results = remote_ops.bulk_run(list(desktops), _runner)

    ok = sum(1 for r in results if r.get('success'))
    messages.success(request,
        f"Bulk {action}: {ok}/{len(results)} succeeded "
        f"on {desktops.count()} desktop(s).")
    return render(request, 'core/bulk_result.html', {
        'action': action, 'results': results,
    })


# ─── Ping All + Auto-poll (#2) ────────────────────────────────

@login_required
def ping_all(request):
    """Ping all managed desktops and return JSON status."""
    desktops = Desktop.objects.filter(is_managed=True)
    results = []
    for d in desktops:
        res = remote_ops.ping_host(d.ip_address, timeout=2)
        alive = res.get('alive', False)
        rtt = res.get('rtt_ms')
        old_status = d.status
        d.status = 'online' if alive else 'offline'
        d.last_ping_ms = rtt
        d.last_seen = timezone.now() if alive else d.last_seen
        d.save(update_fields=['status', 'last_ping_ms', 'last_seen'])
        results.append({
            'id': d.pk,
            'name': d.device_name,
            'ip': d.ip_address,
            'alive': alive,
            'rtt_ms': rtt,
            'status': d.status,
            'changed': old_status != d.status,
        })
    return JsonResponse({
        'ok': True,
        'count': len(results),
        'online': sum(1 for r in results if r['alive']),
        'offline': sum(1 for r in results if not r['alive']),
        'results': results,
    })


# ─── Package Repository (upload + deploy) ─────────────────────

@login_required
def package_repo(request):
    """List uploaded packages and allow new uploads."""
    from .models import PackageFile
    packages = PackageFile.objects.all()
    desktops = Desktop.objects.filter(is_managed=True).select_related('location')
    return render(request, 'core/package_repo.html', {
        'packages': packages, 'desktops': desktops,
    })


@login_required
@require_POST
def package_upload(request):
    """Handle package file upload to the server repository."""
    from .models import PackageFile
    f = request.FILES.get('package_file')
    if not f:
        messages.error(request, 'No file selected')
        return redirect('package_repo')
    name = request.POST.get('display_name', f.name).strip()
    desc = request.POST.get('description', '').strip()
    pkg = PackageFile.objects.create(
        name=name, description=desc,
        file=f, original_filename=f.name,
        file_size=f.size, uploaded_by=request.user,
    )
    messages.success(request, f'Uploaded: {pkg.original_filename} ({pkg.file_size_display})')
    return redirect('package_repo')


@login_required
@require_POST
def package_deploy(request):
    """Copy a package to selected desktops via SFTP and optionally install."""
    from .models import PackageFile, InstallJob
    pkg_id = request.POST.get('package_id')
    desktop_ids = request.POST.getlist('desktop_ids')
    auto_install = request.POST.get('auto_install') == '1'

    if not pkg_id or not desktop_ids:
        messages.error(request, 'Select a package and at least one desktop')
        return redirect('package_repo')

    pkg = get_object_or_404(PackageFile, pk=pkg_id)
    desktops = Desktop.objects.filter(pk__in=desktop_ids, is_managed=True)

    ok = fail = 0
    for d in desktops:
        try:
            # Determine remote path based on OS
            fname = pkg.original_filename
            if d.is_windows:
                remote_path = f'C:\\Temp\\{fname}'
                remote_dir = 'C:\\Temp'
            else:
                remote_path = f'/tmp/{fname}'
                remote_dir = '/tmp'

            # Ensure directory exists
            if d.is_windows:
                remote_ops.run_command(d, f'mkdir C:\\Temp 2>nul & echo ok')
            else:
                remote_ops.run_command(d, f'mkdir -p {remote_dir}')

            # SFTP upload
            client = remote_ops._ssh_client(
                d.ip_address, d.ssh_username,
                password=d.ssh_password or None,
                key_path=d.ssh_key_path or None,
                port=d.ssh_port,
            )
            sftp = client.open_sftp()
            sftp.put(pkg.file.path, remote_path)
            sftp.close()
            client.close()

            detail = f'Copied to {remote_path}'

            # Auto-install if requested
            if auto_install:
                ext = fname.rsplit('.', 1)[-1].lower() if '.' in fname else ''
                if d.is_windows:
                    if ext == 'msi':
                        cmd = f'msiexec /i "{remote_path}" /quiet /norestart'
                    elif ext == 'exe':
                        cmd = f'Start-Process -FilePath "{remote_path}" -ArgumentList "/S","/silent","/quiet" -Wait'
                    else:
                        cmd = f'echo "Unknown extension .{ext} — manual install needed"'
                    cmd = remote_ops._ps(cmd)
                else:
                    if ext == 'deb':
                        cmd = f'dpkg -i {remote_path} && apt-get install -f -y'
                    elif ext == 'rpm':
                        cmd = f'rpm -ivh {remote_path}'
                    elif ext in ('sh', 'run'):
                        cmd = f'chmod +x {remote_path} && {remote_path}'
                    elif ext == 'tar' or fname.endswith('.tar.gz'):
                        cmd = f'tar xzf {remote_path} -C /opt/'
                    else:
                        cmd = f'echo "Unknown extension .{ext} — manual install needed"'

                res = remote_ops.run_command(d, cmd, use_sudo=not d.is_windows)
                detail += f' → Install: {"OK" if res.get("success") else "FAIL"}'

                InstallJob.objects.create(
                    desktop=d, application=None, user=request.user,
                    command=cmd[:2000],
                    stdout=res.get('stdout', '')[:6000],
                    stderr=res.get('stderr', '')[:3000],
                    exit_code=res.get('exit_code'),
                    success=res.get('success', False),
                    duration_ms=res.get('duration_ms'),
                )
                if res.get('success'):
                    ok += 1
                else:
                    fail += 1
            else:
                ok += 1

        except Exception as e:
            fail += 1
            detail = f'Error: {e}'

    messages.info(request,
        f'Deploy: {ok} OK, {fail} failed across {desktops.count()} desktop(s)')
    return redirect('package_repo')
