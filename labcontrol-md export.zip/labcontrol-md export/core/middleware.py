"""
Activity Logging Middleware
===========================
Records every authenticated POST/PUT/DELETE/PATCH request to the
ActivityLog table for audit purposes. Skips static/admin/favicon paths.
"""
from django.conf import settings
from django.http import JsonResponse
from django.utils.deprecation import MiddlewareMixin


SKIP_PREFIXES = ('/static/', '/media/', '/favicon', '/admin/jsi18n')
LOGGED_METHODS = {'POST', 'PUT', 'DELETE', 'PATCH'}


class ApiJsonAuthMiddleware(MiddlewareMixin):
    """
    Make /api/ speak JSON even when the session has expired.

    @login_required answers an unauthenticated request with a 302 to the HTML
    login page. A browser fetch() follows that redirect silently, so the JSON
    parser is handed '<!DOCTYPE html...' and throws

        Unexpected token '<', "<!DOCTYPE "... is not valid JSON

    which tells the operator nothing about the actual cause. Sessions last 24h
    (SESSION_COOKIE_AGE), so every long-lived dashboard hits this daily, and
    the 20-second status poll then repeats the error forever. Convert it to a
    plain 401 the client can recognise.
    """

    def process_response(self, request, response):
        if (request.path.startswith('/api/')
                and response.status_code in (301, 302)):
            target = response.get('Location', '')
            if settings.LOGIN_URL.rstrip('/') in target:
                return JsonResponse(
                    {'ok': False, 'error': 'Not authenticated — your session '
                                           'expired. Reload the page to sign in.',
                     'auth_required': True},
                    status=401)
        return response


class ActivityLogMiddleware(MiddlewareMixin):
    def process_response(self, request, response):
        try:
            if (request.method in LOGGED_METHODS
                    and request.user.is_authenticated
                    and not any(request.path.startswith(p) for p in SKIP_PREFIXES)
                    and response.status_code < 500):
                from .models import ActivityLog
                ip = (request.META.get('HTTP_X_FORWARDED_FOR', '')
                      .split(',')[0].strip()
                      or request.META.get('REMOTE_ADDR'))
                ActivityLog.objects.create(
                    user=request.user,
                    action=request.method,
                    method=request.method,
                    path=request.path[:300],
                    ip_addr=ip,
                    user_agent=request.META.get('HTTP_USER_AGENT', '')[:300],
                )
        except Exception:
            pass
        return response


def log_activity(user, action, target='', detail='', request=None):
    """Helper to manually log a custom activity."""
    from .models import ActivityLog
    ip = None
    ua = ''
    if request:
        ip = (request.META.get('HTTP_X_FORWARDED_FOR', '').split(',')[0].strip()
              or request.META.get('REMOTE_ADDR'))
        ua = request.META.get('HTTP_USER_AGENT', '')[:300]
    ActivityLog.objects.create(
        user=user, action=action[:120], target=target[:240],
        detail=detail, ip_addr=ip, user_agent=ua,
    )
