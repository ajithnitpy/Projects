# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

---

## 0. Where the code actually is

The Django project is **not** at the repo root. Layout:

```
C:\Users\ajith\Labcontrol\
├── CLAUDE.md                     <- this file (root copy)
├── labcontrol-md export.zip      <- archive, ignore
└── labcontrol-md export\         <- THE PROJECT — cd here to run anything
    ├── manage.py
    ├── CLAUDE.md                 <- identical copy; keep both in sync when editing
    ├── labcontrol\               <- Django project package
    └── core\                     <- the single Django app
```

`cd "labcontrol-md export"` before any `manage.py` / `pip` / `python` command.
There is **no virtualenv and no installed Django in this tree** — `manage.py check`
cannot run until one is created (see §10). `python -m py_compile` works and passes today.

Not a git repository. No `.cursorrules`, no `.github/copilot-instructions.md`.

Companion docs in the project dir: `README.md` (user-facing install/usage),
`SPA_SETUP.md` (Vite build path), `IMPORT_EXPORT.md` (admin CSV/XLSX flows),
`setup_openssh_labcontrol.ps1` + `setup_openssh_manual_steps.ps1` (Windows target prep).

---

## 1. What this is

**LabControl** is a Django-based central control automation system for managing a
university computer-lab fleet (Linux + Windows desktops) entirely over SSH.

Built for **NIT Puducherry (NITPY), Karaikal** — Department of CSE. Manages lab
desktops for teaching labs, a GPU/ML lab, and faculty machines.

Capabilities: power control (Wake-on-LAN / shutdown / restart), live telemetry,
remote file manager, software inventory, config-drift detection, login-session
tracking, reservations, scheduled-task definitions, ARP neighbour discovery with a
deduplicated host registry, an Ollama-backed AI assistant, and full audit logging.

### Deployment reality (important)

- Runs on a **Windows server**, path style `D:\Projects\<project>\`
- **Python 3.14** (3.14.5 locally), virtualenv at `env\`
- Accessed on the LAN at e.g. `172.24.11.200:6600` (README says `:8000` — both are
  just `runserver` arguments; nothing in the code hardcodes a port)
- Target desktops are on the same or adjacent subnets
- The project folder has been renamed several times (`labcontrol-enhanced`,
  `labcontrol-filemanager_3`, `labcontrol-Vite-File_manager`, now
  `labcontrol-md export`). Don't assume a folder name; the Django project package
  is always `labcontrol/`, the app is always `core/`.

---

## 2. Hard-won constraints — read these first

These caused real, repeated breakage. Do not regress them.

### 2.1 Django must be >= 5.1.16 — never loosen the pin

**Symptom:** every Django admin changelist crashes with
`AttributeError: 'super' object has no attribute 'dicts' and no __dict__ for setting new attributes`
raised from `django/template/context.py` in `__copy__`.

**Cause:** Python 3.14 changed `super()` behaviour in a way that broke
`BaseContext.__copy__()` in Django <= 5.1.15. The admin changelist copies template
context to render sortable headers, so *every* admin list page 500s.

`requirements.txt` previously read `Django>=4.2,<5.2`, which **permitted and would
install the broken versions**. That was the recurrence mechanism — every fresh
virtualenv reintroduced the bug, three times over. It now reads:

```
Django>=5.1.16,<6.0
```

with a comment explaining why. **Do not widen this range**, and if an existing
environment is already broken, `pip install --upgrade "Django>=5.1.16,<6.0"`.

If the user reports the `'super' object has no attribute 'dicts'` error, it is
*always* this — never a code bug. Check the installed version first
(`python -c "import django; print(django.get_version())"`), not the pin.

### 2.2 SSH is the only transport — no WinRM

Windows 10/11 ship OpenSSH Server built in. Using SSH for both OSes means one
credential model, one connection path, one set of error handling. PowerShell
commands are wrapped by the `_ps()` helper in `remote_ops.py:214`:

```python
_ps("Get-Process")  # -> powershell -NoProfile -Command "Get-Process"
```

Three SSH backends coexist behind one `run_command(desktop, cmd, backend=...)`
facade (`remote_ops.py:178`): `_run_paramiko` (default), `_run_fabric`,
`_run_netmiko`. Add capability to `run_command`, not to callers.

Windows OpenSSH gotchas already solved (see the setup scripts):
- registry `DefaultShell` must point at `powershell.exe`
- the admin `authorized_keys` override in `sshd_config` must be commented out
- the SSH user must be in the local Administrators group for power operations

**Do not** introduce WinRM, pywinrm, or a per-OS transport split.

### 2.3 No duplicate model / admin / API definitions

A previous build had **two parallel implementations** of the same five features
merged into one tree. Result: `RuntimeWarning: Model 'core.X' was already
registered` plus a hard crash `AlreadyRegistered: InstalledSoftware`.

The stale set used models `UserSession` / `TaskRun` and a file `services.py`. The
correct set uses `LoginSession` and `collectors.py`. **If you see `UserSession`,
`TaskRun`, or `services.py` referenced anywhere, it is dead code — remove it,
don't revive it.**

> ⚠️ `core/tasks.py` is the one exception to the old "delete on sight" rule. It
> does not exist today, but `settings.CELERY_BEAT_SCHEDULE` *references* it. See §8
> — a future `core/tasks.py` holding Celery tasks is wanted, not dead code.

Current verified state: **23 models, 23 admin registrations, 0 duplicates**;
`core/urls.py` → `core/api.py` cross-reference is clean (43 routed endpoints,
47 module-level `def`s — the extra four are the private helpers `_desktop_dict`,
`_size_display`, `_resolve_targets` and `_power_log_action`); every `views.X`
named in `urls.py` exists.

### 2.4 Duplicate function definitions — RESOLVED, keep it that way

Python silently keeps the **second** definition in each pair; Django's URL
resolver keeps the **first** match for resolution but the **last** registration
for `reverse()`. That combination let the two halves of a pair disagree silently.

**`core/views.py` and `core/urls.py` — cleaned up.** Four shadowing views
(`desktop_change_hostname`, `desktop_change_ip`, `discovery`, `bulk_action`) and
their duplicate route registrations were removed. In every case the **first**
definition was the correct one, because it matched the templates and carried the
audit writes the second copy dropped:

- `bulk_result.html` reads `r.device_name` / `r.ip_address`, which
  `remote_ops.bulk_run()` supplies — the deleted copy looped serially and set
  `r['device']`, a key the template never reads, so device names rendered blank.
- `discovery.html` posts `name="cidr"` and iterates `results` checking `r.in_db`
  — the deleted copy passed `subnet` / `result` and set `in_inventory`.
- The survivors write `ShellCommandLog` / `RemoteUserMgmtLog` / `ScanLog` rows;
  the deleted copies wrote none.

`bulk_action` kept path **`/bulk/`** (the one `reverse()` was already emitting,
so no rendered form changed); `/bulk-action/` is gone. Nothing referenced it —
every call site uses `{% url 'bulk_action' %}`.

**`core/remote_ops.py` — also cleaned up.** Three pairs
(`change_hostname`, `change_ip_address`, `discover_subnet`) collapsed to one each.
Here the **second** (previously live) definition was kept every time, so runtime
behaviour is unchanged — Python was already using it. All three callers live in
`core/views.py` and pass positionally or by a keyword the survivor accepts.

`discover_subnet` was the dangerous one, and it was **live breakage**: the deleted
copy took `cidr=` and returned a `List[Dict]`, the survivor takes `subnet=` and
returns `{'subnet', 'hosts', 'scanned'}` (or `{'error': ...}`). The `discovery`
view iterated the result as a list, so `for r in results` yielded string keys and
`r['in_db'] = ...` raised `TypeError` on every scan. The view now reads the dict
shape and surfaces `scan['error']` via `messages.error`.

**Capability deliberately dropped with the deleted copies** — none of this was
reachable, but it's the design input someone may want back:

- `change_hostname` — **leading digits restored, dots still rejected.** The
  deleted regex allowed `^[A-Za-z0-9][\w.-]{0,62}$`; the survivor started as
  `^[a-zA-Z][\w-]{0,62}$` and is now `^[A-Za-z0-9][\w-]{0,62}$`, so `01-lab-pc`
  validates (RFC 1123 permits a leading digit) but `pc.lab.local` does not —
  `hostnamectl set-hostname` wants a short label, not an FQDN.
  **This regex is the only sanitiser on `new_hostname`**, which is f-string
  interpolated straight into a shell / PowerShell command. Any future widening
  must keep `;`, `'`, `"`, `$`, backtick, `|`, `&`, and whitespace excluded, or it
  becomes command injection reachable from `POST /desktops/<pk>/hostname/`.
- `change_ip_address` (Linux) — the deleted copy had an `ip addr flush/add`
  **fallback for non-NetworkManager hosts**; the survivor is nmcli-only. In
  exchange the survivor targets the requested interface
  (`grep ":{iface}$"`) instead of blindly taking the first active connection via
  `head -1`, which could reconfigure the wrong NIC. Net: safer, less portable.
- `change_ip_address` (Windows) — the survivor validates the adapter first with
  `Get-NetAdapter -ErrorAction Stop`; the deleted copy did not.
- `discover_subnet` — the deleted copy had an `ssh_port` parameter (default 22);
  the survivor hardcodes 22. No caller ever passed it.

Detect regressions with:

```bash
for f in core/views.py core/api.py core/models.py core/remote_ops.py; do
  echo "$f: $(grep -oh '^def [a-zA-Z0-9_]*' "$f" | sort | uniq -d)"
done
grep -o "path('[^']*'" core/urls.py | sort | uniq -d   # duplicate paths
grep -o "name='[^']*'" core/urls.py | sort | uniq -d   # duplicate route names
```

### 2.5 Migrations are not committed

`core/migrations/` contains **only `__init__.py`**. Every fresh checkout must run
`python manage.py makemigrations core` before `migrate`. Do not assume a migration
history exists, and do not hand-write a `0001_initial.py`.

---

## 3. Architecture

```
Browser
  ├── /            classic Django server-rendered pages
  │                  └── all 17 pages -> base.html (Tailwind CDN)
  └── /app/  /spa/ React SPA (one template + one JSX file)
         │
         ├── JSON REST API  (core/api.py, 43 endpoints under /api/)
         │
         ├── core/remote_ops.py   SSH / SFTP / WoL / ARP / telemetry
         ├── core/collectors.py   on-demand scans -> DB
         └── core/ai_agent.py     Ollama client
                    │
              MySQL or SQLite (23 models)
                    │
              Lab desktops (SSH :22)
```

### Two blended UI layers — why both exist

The classic multi-page Django UI came first. The SPA was added because every
action caused a full page reload. Rather than throw away working pages, both
layers coexist:

- They share **one Django session cookie** — no double login.
- The classic sidebar has an "Open Live SPA →" link at the top
  (`base.html:181`, `base_ace.html:54`).
- The SPA sidebar has a "Classic Pages" section linking back
  (`app.jsx:611`, `DJANGO_PAGES`).
- `/app/` and `/spa/` both serve `templates/core/spa.html`, wired in
  `labcontrol/urls.py` via `urlpatterns.insert(0, ...)` — they are inserted
  *before* the `core.urls` include, so they win over any `core` route.

### API conventions

`core/api.py` is **plain Django** — no DRF, no serializers. Everything returns
`JsonResponse`. The house style, which new endpoints must follow:

- `@login_required` (35 of them) plus `@require_POST` / `@require_GET`.
- `@ensure_csrf_cookie` only on `api_csrf`, which the SPA calls once on boot.
- Mutating responses carry `steps[]` (the operation narration) and, on failure,
  `debug_suggestions[]` from `remote_ops.suggest_debug()`.
- `_desktop_dict()` is the single Desktop→JSON shape. Use it; don't hand-roll.
- `PackageFile` is imported inside a `try/except ImportError` for older schemas.

**The backend is framework-agnostic.** Any client works if it: `GET /api/csrf/`
once, sends `X-CSRFToken` from the cookie on POSTs, and uses
`credentials: "include"`. `POST /api/login/` authenticates.

### Why not Next.js

The user asked for Next.js. The actual requirement was "operations without full
page reloads". Next.js would have meant a second Node server, CORS config, JWT or
session bridging, and two deployments to run on a Windows lab server. A React SPA
served from Django gives the same VDOM benefit with **one server, one port, one
session**. This was a deliberate pushback, and it stands.

### Why CDN Babel instead of a Vite build

`templates/core/spa.html` loads React 18 + Babel from unpkg and transpiles
`static/js/app.jsx` **in the browser** (`<script type="text/babel">`, line 31).
Zero build step, no Node.js on the server. Costs ~500 KB of CDN JS and ~1s of
first-render transpile — acceptable for an internal tool, and it avoids adding npm
to a Python-only Windows deployment.

`SPA_SETUP.md` documents the Vite path for when optimisation matters. If the lab
is ever air-gapped, download the three CDN scripts into `static/js/vendor/` and
repoint the `<script>` tags. **`base.html` also pulls Tailwind and lucide from a
CDN** — an air-gap plan must cover those too, not just React.

---

## 4. Code map

Line counts verified; keep them updated when they drift materially.

| File | Lines | Role |
|---|---|---|
| `core/remote_ops.py` | 1121 | All remote I/O: SSH exec (paramiko/fabric/netmiko), SFTP, WoL, power, ARP scan, telemetry, debug suggestions |
| `core/api.py` | 1433 | JSON REST API — 43 routed endpoints, consumed by the SPA and the classic ops toolbar |
| `core/views.py` | 1090 | Classic server-rendered pages |
| `core/models.py` | 821 | 23 models |
| `static/js/app.jsx` | 742 | The entire React SPA, 9 pages |
| `core/ai_agent.py` | 405 | Ollama HTTP client (pure urllib) |
| `core/collectors.py` | 378 | SSH scans → DB (sessions, software, drift, discovery) |
| `core/management/commands/seed_lab.py` | 269 | Demo data; creates `admin`/`admin` |
| `core/admin.py` | 196 | Admin registration for all 23 models |
| `labcontrol/settings.py` | 207 | Incl. Celery config (§8), upload tuning (§5) and `LOGGING` (§9) |
| `core/resources.py` | 150 | django-import-export for Location / Desktop / DesktopUser |
| `core/urls.py` | 126 | Classic + API routes |
| `core/forms.py` | 115 | ModelForms for the classic pages |
| `static/css/labcontrol-ace.css` | 105 | LabControl additions on top of Ace |
| `static/js/labcontrol-terminal.js` | 112 | `lcLog()` / `lcApi()` for classic pages |
| `static/js/labcontrol-ops.js` | 161 | Shared Wake/Shutdown/Restart/Ping scope logic for all three classic pages |
| `core/middleware.py` | 50 | `ActivityLogMiddleware` + `log_activity()` helper |
| `core/management/commands/run_collectors.py` | 55 | Manual collector runner |
| `core/templatetags/lc_extras.py` | 26 | `|split` and `|filesize` filters |
| `labcontrol/celery.py` | 19 | Celery app — see §8, no tasks exist yet |
| `labcontrol/logging_filters.py` | 45 | `SuppressBrokenPipe` for the `django.server` logger (§9) |

### The 23 models

**Fleet:** `Location`, `Desktop`, `DesktopUser`
**Software:** `Application`, `InstallJob`, `PackageFile`
**Audit (6):** `ActivityLog`, `PowerLog`, `ShellCommandLog`, `FileOperationLog`,
`RemoteUserMgmtLog`, `ScanLog`
**AI:** `AIConversation`
**Sessions:** `LoginSession`, `UsageSnapshot`
**Inventory:** `InstalledSoftware`, `SoftwarePolicy`
**Drift:** `GoldenConfig`, `DriftReport`
**Scheduling:** `Reservation`, `ScheduledTask`
**Discovery:** `DiscoveredHost`, `HostSighting`

`Desktop` is the hub: SSH credentials (`ssh_username` / `ssh_password` /
`ssh_key_path` / `ssh_port` / `use_sudo` / `sudo_password`), hardware metadata,
`os_type` from a 10-value choice list spanning the Linux and Windows families
(`remote_ops` branches on it to decide whether to wrap in `_ps()`), runtime state
(`status`, `last_seen`, `last_ping_ms`, `last_user`), and `is_managed` — the flag
that gates collectors and bulk operations.

---

## 5. Design decisions and rationale

### AI assistant is general-purpose, not install-only

Originally the system prompt forced JSON-only output and made the agent *refuse*
anything that wasn't an app-install request. That made it useless for the thing
admins actually need — troubleshooting.

Now `ai_agent.ask()` (line 337) answers any sysadmin question and *optionally*
emits an `<APP_JSON>...</APP_JSON>` block when it detects an installable app,
which the UI turns into a "Save to Catalog" button. `_extract_json()` pulls it out
and strips it from the displayed text.

`/api/ai/read-logs/` pulls the last 10 failed `ShellCommandLog` or `PowerLog`
entries and asks the LLM to diagnose them — turning the audit log into a
troubleshooting input.

Default model is **`qwen2.5-coder:7b`** (`settings.OLLAMA_MODEL`), 120 s timeout,
`http://127.0.0.1:11434`. The README's troubleshooting row mentions `llama3.2:3b`
— the settings default is authoritative. `ai_agent.is_available()` is the health
probe; the UI degrades gracefully when Ollama is down.

### Debug suggestions are rule-based, not LLM

`remote_ops.suggest_debug(operation, result, desktop)` (line 975) pattern-matches
error text (auth failure, timeout, connection refused, permission denied,
host-key mismatch) and returns concrete fixes — including the full WoL checklist
for power-on failures. Rule-based because it must be instant, deterministic, and
work when Ollama is down. The LLM path is the *escalation*, not the default.

### Host registry deduplicates by MAC, not IP

`DiscoveredHost` is keyed on MAC because IPs move under DHCP — the same laptop at
`.24` today and `.30` next week must be **one** row with `times_seen` incremented,
not two. Falls back to IP when ARP returns no MAC.

`HostSighting` is a separate append-only log of every appearance (IP, source,
scanner, timestamp) so you keep "when did this device first appear" history
without polluting the unique list.

`categorize_host()` (`remote_ops.py:1197`) assigns: `managed` (matches a known
Desktop) / `infrastructure` (network-vendor OUI or `.1`/`.254`) / `iot`
(Espressif, Raspberry Pi) / `virtual` (VMware, VirtualBox, Hyper-V, QEMU) /
`unknown`.

Scans run **local** (on the server) or **remote** (over SSH on any desktop) —
remote matters because ARP only sees the scanner's own broadcast domain, so
mapping another VLAN requires a scanner that lives on it.

### Telemetry batches in parallel

`/api/telemetry-batch/` uses `ThreadPoolExecutor(max_workers=20)`. Serial SSH to
50 desktops would take ~50× one connection; parallel makes it ~3s. Per-device
`/api/telemetry/<id>/` returns the fuller payload (all disks, all NICs).
`remote_ops.bulk_run()` (line 669) is the general fan-out helper, defaulting to
`SCAN_MAX_WORKERS = 30` from settings.

### Power-on has three mechanisms

`power_on(desktop, method=...)` (`remote_ops.py:225`):
- `wol` — magic packet, 3 rounds, **emitted from every local interface** to
  both `255.255.255.255` and the target's own `/24` directed broadcast, on
  UDP 9 and UDP 7
- `wol_directed` — derives the target's `/24` broadcast (e.g. `192.168.1.255`) so
  WoL crosses VLANs where the router forwards directed broadcasts
- `ipmi` — out-of-band via `ipmitool` against a BMC; requires `ipmi_host/user/pass`
  fields that **do not yet exist on the Desktop model** — `_power_on_ipmi()`
  checks and returns a clear error

WoL is fire-and-forget; the response includes `verify_after: 45` as a hint to
re-ping rather than claiming success.

**Why the multi-interface send matters.** `sendto('255.255.255.255')` leaves via
exactly one interface — whichever the default route picks. The lab server holds
**nine** IPv4 addresses (172.18.7.230, 172.18.2.225, 200.175.2.1 and six
192.168.x gateways), so the old single-socket send reached one segment and
silently missed the rest. `wol_send()` now binds a socket to each address in
turn: a wake went from 1 datagram per round to 18. Sources with no route to a
given broadcast fail individually and are recorded in `errors` without failing
the send; if *every* bound source fails it retries once unbound so the OS can
route it. UDP 7 is included alongside 9 because NICs differ on which they listen
to. `local_ipv4s()` is the enumeration helper.

**`ok: true` from a bulk power call does not mean the machines woke** — it means
the request was processed. `labcontrol-ops.js:lcPower()` grades the batch on the
per-desktop results and logs `err`/`warn`/`ok` accordingly, and calls out a
no-MAC batch explicitly. Before that, waking 80 desktops where 76 had no MAC
logged a green "done".

### Account names are the injection surface — one validator gates them all

`purge_user_home`, `user_delete_remote`, `user_lock_remote` and
`user_create_remote` all f-string a username straight into a sudo /
Administrator shell command. Guards used to be per-function and inconsistent:
`user_lock_remote` had none, `user_delete_remote` checked only a protected-name
list, and `purge_user_home` blocked `/` and `..` but permitted `;`, `&&`, `|`,
backticks and spaces. Purging user `student; reboot` on Linux built

```
find /home/student; reboot -mindepth 1 -delete
```

— a sudo reboot, and `bulk_action`'s `delete_user` already fanned that shape
across many desktops.

All four now call `remote_ops._reject_user()`, backed by
`USERNAME_RE = ^[A-Za-z0-9][A-Za-z0-9._-]{0,31}$` plus a `PROTECTED_USERS`
set. Leading digits are allowed on purpose — roll-number logins (`22cs101`)
are normal here. **Do not widen this regex**: every shell metacharacter is
excluded by construction, and `/api/bulk-purge/` rejects a whole request if
any one name fails, rather than purging the valid subset.

### Exam prep clears data; it never deletes accounts

`/exam-prep/` (`views.exam_prep` → `api_bulk_purge`) empties student home
folders across a lab so machines are exam-ready. Deliberate properties:

- **Lab-scoped only** — no "selected desktops" mode. A half-cleared lab is
  worse than an uncleared one.
- **Dry run is mandatory before a real clear.** The dry run counts files and
  deletes nothing; the real button stays disabled until one has run, and any
  change to scope or usernames re-arms that gate.
- **Typed confirmation** of the lab name (or `FLEET`) — not a generic confirm,
  because deleting student work is irreversible and uncopied.
- Writes `FileOperationLog` rows (`scan_home` for dry runs, `purge_home` for
  real ones), so the page can show a history of what was cleared.

`Application.uninstall_command()` mirrors `install_command()` for the
"remove applications" step, and `api_bulk_deploy` takes `mode: 'uninstall'`.
A catalog entry built from a **custom** install script has no inverse and
reports a failure rather than silently falling through to the *install*
command — which is exactly the bug the first draft of that button had.

### Bulk operations resolve one target set, three ways

Every fleet-wide control funnels through `api._resolve_targets(data)`, which
reads a payload in strict priority order:

| Payload | Target |
|---|---|
| `{'desktop_ids': [1,2]}` | that explicit selection |
| `{'lab_id': 4}` | every managed desktop in one Location |
| `{'scope': 'all'}` | the whole managed fleet |

`static/js/labcontrol-ops.js:lcCurrentTarget()` mirrors that precedence on the
browser side, so the Dashboard, All Desktops and Locations pages all answer
"what will this button hit?" identically. Endpoints using it: `api_bulk_power`,
`api_bulk_ping`, `api_bulk_deploy`.

Two safety properties are deliberate and **must not be relaxed**:

- **An explicitly empty `desktop_ids` is an error, not a fleet-wide fan-out.**
  `[]` means "nothing is checked"; treating that as "everything" would turn a
  mis-click into a whole-campus shutdown.
- **Unknown power actions are rejected, never coerced.** `BULK_POWER_ACTIONS`
  gates the API and `remote_ops.POWER_OFF_MODES` gates the transport. Before
  this, `power_off()` ended in `cmd_map.get(mode, cmd_map['shutdown'])`, so a UI
  sending `'restart'` (rather than the correct `'reboot'`) would silently
  **shut down** every target instead of rebooting it.

Fleet-wide destructive actions additionally require typing `FLEET` into a
prompt; lab- and selection-scoped ones use a plain confirm.

`_power_log_action()` maps the API's `'wol'` onto `PowerLog.ACTION_CHOICES`'
`'wol_on'`. Django does not validate choices on `.create()`, so before this the
audit log stored a value outside its own choice list and the Audit Logs page
rendered the raw string instead of "Wake-on-LAN".

### Ping sweeps are parallel, but the ORM stays single-threaded

`api_ping_all` and `api_bulk_ping` fan out with `ThreadPoolExecutor`
(`SCAN_MAX_WORKERS`, default 30) and `ex.map`, which preserves input order so
`probes[i]` pairs with `targets[i]`. **DB writes happen afterwards on the
request thread via `bulk_update`** — writing from the pool would serialise on
SQLite's write lock anyway, and risks `database is locked`. Keep that split if
you add more parallel collectors.

### Every mutation is audited for free

`ActivityLogMiddleware` (`core/middleware.py`) writes an `ActivityLog` row for
**every authenticated POST/PUT/DELETE/PATCH** under 500, skipping
`/static/`, `/media/`, `/favicon`, `/admin/jsi18n`. New mutating endpoints get
audit coverage automatically — do not hand-roll it. The middleware swallows all
exceptions by design so logging failures can never break a request; use
`log_activity()` for richer manual entries.

### Export redacts SSH passwords

`core/resources.py` masks `ssh_password` as `***REDACTED***` via
`dehydrate_ssh_password`. Keep it. Import/export covers Location, Desktop, and
DesktopUser only; templates live in `sample_imports/`.

### Accessibility is a requirement, not a nicety

The neighbour-discovery graph (`app.jsx:177`, `NeighborDiscovery`) is paired with
an equivalent **accessible table** — `<caption>`, `<th scope="col">`,
`<th scope="row">` — because an SVG graph conveys nothing to a screen reader. The
SVG carries `role="img"` and a descriptive `aria-label`. Any future visualisation
must ship the same table equivalent.

### Large uploads stream, never buffer

`settings.py`: `DATA_UPLOAD_MAX_MEMORY_SIZE = None`,
`FILE_UPLOAD_MAX_MEMORY_SIZE = 10 MB`,
`FILE_UPLOAD_HANDLERS = [TemporaryFileUploadHandler]`, `SESSION_COOKIE_AGE = 86400`.
Uploads write in 1 MB chunks. A 10 GB ISO works. Browser side uses
`XMLHttpRequest` with `upload.onprogress` for a real progress bar (`fetch` can't
report upload progress).

---

## 6. The operations terminal

A footer-docked terminal streams what is happening over SSH — the command, its
stdout, the result, and debug tips — with millisecond timestamps and levels
(`cmd` / `out` / `ok` / `warn` / `err` / `info`).

- **SPA:** React `OpsContext` (`app.jsx:70`) provides `log(level, msg)`;
  `OpsTerminal` takes a `leftOffset` prop so it aligns beside the collapsible
  sidebar. Present on all 9 SPA pages.
- **Classic:** `static/js/labcontrol-terminal.js` exposes `lcLog()` and `lcApi()`.
  `lcApi()` is a CSRF-aware fetch wrapper that narrates itself — it logs the
  request, then replays `steps[]` / `debug_suggestions[]` from the response.
  State survives navigation via `sessionStorage`; open/closed in `localStorage`.

**Both shells now load it.** `base_ace.html` always did; `base.html` now loads
`labcontrol-terminal.js` too and carries its own copy of the terminal markup plus
Tailwind-palette styles for the `.lc-term-*` classes (the Ace build styles those
in `labcontrol-ace.css`, which `base.html` does not load). So `lcLog()` /
`lcApi()` are defined on **every** classic page.

One cross-shell wrinkle: `lcToggleTerminal()` used to assign
`c.className = 'fa fa-chevron-…'` to the caret. On the Tailwind pages that
element is a lucide `<svg>` after `createIcons()`, where `className` is a
read-only `SVGAnimatedString`. It now branches on `tagName` — `<i>` gets the
FontAwesome classes, anything else gets a CSS rotate.

**Every new operation button should call through `lcApi()` (classic) or `log()`
(SPA)** so it appears in the terminal. This is the app's core UX promise.

---

## 7. UI theming — two systems (Ace is now orphaned)

| Layer | Templates | Styling |
|---|---|---|
| All 17 classic pages | `*.html` → `base.html` | **Tailwind via CDN** + lucide icons via CDN, IBM Plex Mono, custom dark palette |
| SPA | `spa.html` + `app.jsx` | Inline-style dark NOC theme — Space Mono, cyan `#00F0FF` / lime `#39FF14` / rose `#FF2D55` |

**The dashboard was migrated off Ace, not onto it.** `views.dashboard` now renders
`templates/core/dashboard.html` (Tailwind), so the landing page matches every other
classic page. That template was the *original* pre-Ace dashboard, revived and
brought up to date with the ops toolbar, tile selection checkboxes,
`data-status-for` / `data-lab-online` repaint hooks and per-lab power buttons.

`templates/core/_ops_toolbar.html` is a shared include (scope picker + Ping /
Wake / Restart / Shutdown All) used by **`dashboard`, `desktop_list` and
`location_manage`**, all driving the same `labcontrol-ops.js`.

The dashboard's 2-minute auto-poll deliberately calls `/api/bulk-ping/` with
`{scope:'all'}` directly instead of going through `lcCurrentTarget()` — an
unattended background poll must always cover the whole fleet, never silently
narrow to whatever is checked or picked in the scope selector.

### Ace is dead code now — and that resolves the licence problem

`dashboard_ace.html` is the only template still extending `base_ace.html`, and
**no view renders it**. The whole Ace stack is unreferenced:
`templates/core/base_ace.html`, `templates/core/dashboard_ace.html`,
`static/css/labcontrol-ace.css`, `static/vendor/ace/`, and the
`static/vendor/assets/fonts/Kanit/` duplicate that `ace-font.css` needed.

⚠️ **Licence:** `ace.css`, `ace-themes.css`, and `ace.js` all carry the header
*"You need a commercial license to use this product"* (active-themes.com, now
defunct). The GitHub copy it came from is an unauthorised redistribution. **Since
nothing loads Ace any more, deleting those files closes the obligation** — that
is the recommended cleanup, but it has not been done (the user should confirm
before ~40 MB of vendored assets are removed). Do not reintroduce Ace; if a
component library is ever wanted, AdminLTE / Tabler / CoreUI Free are MIT.

---

## 8. Celery: configured, but no tasks exist

Previously documented as "not built at all" — the truth is more dangerous than
that. The *scaffolding is wired and would load*, then fail at runtime:

| Piece | Status |
|---|---|
| `celery`, `redis`, `django-celery-beat`, `django-celery-results` in `requirements.txt` | ✅ present |
| `labcontrol/celery.py` (app, `autodiscover_tasks()`) | ✅ present |
| `labcontrol/__init__.py` imports `celery_app` (in a `try/except ImportError`) | ✅ present |
| `CELERY_BROKER_URL` / `CELERY_RESULT_BACKEND` → `redis://localhost:6379/0` | ✅ present |
| `CELERY_BEAT_SCHEDULE` with 3 entries | ✅ present |
| **`core/tasks.py`** | ❌ **does not exist** |
| `django_celery_beat` / `django_celery_results` in `INSTALLED_APPS` | ❌ **absent** |
| A running worker or beat process | ❌ none |

`CELERY_BEAT_SCHEDULE` names three tasks that must be created for any of this to
work:

```python
'core.tasks.run_due_tasks'      # every 60 s  — fire due ScheduledTask rows
'core.tasks.poll_all_usage'     # every 300 s — write UsageSnapshot rows
'core.tasks.nightly_inventory'  # every 86400 s — collect_software fleet-wide
```

So `ScheduledTask` rows are editable in admin, listed in the SPA, and now
creatable/deletable from the Locations page (`/api/tasks/create/`,
`/api/tasks/delete/`) — but **nothing fires them**. Both the create response
(`detail`) and `/api/scheduled-tasks/` (`scheduler_running: false`) say so
explicitly, and the Locations form carries a visible warning, so the UI never
implies a schedule is live. Wiring this up is the single highest-value remaining item:
it turns sessions/inventory/drift from on-demand into continuously self-updating,
and makes nightly-shutdown / morning-wake real. The implementation is mostly
`core/tasks.py` delegating to existing `collectors.py` and `remote_ops.py`
functions — plus adding the two apps to `INSTALLED_APPS`.

Note `CELERY_TIMEZONE = TIME_ZONE if 'TIME_ZONE' in dir() else 'UTC'` — `dir()` at
module scope does list module globals, so this resolves to `Asia/Kolkata`, but the
guard is pointless and reads like a bug. Simplify it when you touch this.

Also absent: alerting/notifications, health scoring, automated remediation
playbooks, PXE reimaging, energy reporting, `ipmi_*` fields on `Desktop`.

---

## 9. Gotchas that waste an hour

- **`run_collectors --online-only` can never be turned off.** It is declared
  `action='store_true', default=True`, so the flag is always `True` and the
  queryset is always `filter(status='online')`. If `Desktop.status` is stale
  (nothing has pinged recently), collectors silently process **zero** desktops and
  report success. Run `/api/ping-all/` or the classic Ping All first. Fixing the
  flag means `BooleanOptionalAction` or an explicit `--all` opt-out.
- **Wake-on-LAN silently covers a data problem: a blank `Desktop.mac_address`.**
  A magic packet is addressed to a MAC, so `power_on()` refuses outright with
  "No MAC address on file" — correct behaviour, but if most of the fleet has no
  MAC then "Wake All" looks broken. On the NITPY fleet 219 of 231 rows had no
  MAC, and the 12 that did matched the server's ARP cache exactly: they had been
  harvested from ARP, which only sees the scanner's own broadcast domain and
  whose entries age out in ~2 minutes, so a one-off ARP sweep captures almost
  nothing. Fix with `POST /api/collect-macs/` ("Fix MACs" in the ops toolbar),
  which reads each machine's own MAC over SSH — subnet-independent and exact.
  `remote_ops.normalize_mac()` accepts colon, hyphen, bare-12-hex and Cisco
  dotted forms, plus PowerShell's table output with headers.
- **A MAC is necessary but not sufficient for WoL.** Also required: BIOS
  "Wake on LAN" enabled, Windows Fast Startup disabled, "Wake on Magic Packet"
  on the NIC, wired ethernet, and the packet actually reaching the target's
  layer-2 segment. The lab server sits on `172.18.7.230/16`, so lab subnets
  like `172.18.204.x` are *on-link* (Find-NetRoute returns an empty NextHop)
  and the default limited broadcast `255.255.255.255` leaves the right NIC —
  but whether it crosses into each lab's VLAN is a switch question. If a
  desktop has a MAC and still will not wake, try `method='wol_directed'`.
- Collectors also require `is_managed=True`. A desktop added without it is invisible
  to every bulk operation.
- **`collectors.record_discovery()` exists but has no CLI surface** —
  `run_collectors --type` only accepts `sessions|software|drift|all`. Discovery
  runs only through the API/UI path.
- **Drift and compliance produce nothing until baselines exist.** Create
  `GoldenConfig` and `SoftwarePolicy` rows in admin first, or `check_drift()` /
  `check_software_compliance()` return empty results that look like "no problems".
- `settings.ALLOWED_HOSTS = ['*']` and a hardcoded fallback `SECRET_KEY`. Both are
  environment-overridable (`LABCONTROL_SECRET_KEY`, `LABCONTROL_DEBUG`) — set them
  for any exposure beyond the lab LAN.
- MySQL is opt-in via `LABCONTROL_USE_MYSQL=1`; default is SQLite at
  `labcontrol.sqlite3`.
- **`- Broken pipe from ('x.x.x.x', N)` is silenced on purpose — it was never a
  bug.** Django's dev server logs it at INFO on the `django.server` logger from
  `WSGIServer.handle_error()`, and only when `is_broken_pipe_error()` is true, so
  it always means *the client* hung up. The usual shape is an **idle keep-alive**
  connection reset after the response was fully read; an abort *mid-body* takes a
  different path and is already swallowed one layer down by
  `ServerHandler.handle_error()` — which is why such a request logs neither a
  broken pipe *nor* a request line. Everyday causes: a browser navigating away,
  a cancelled static asset, the dashboard's 2-minute `/api/bulk-ping/` poll
  dropped on a page change, `Invoke-WebRequest` / `curl -I` closing early.
  `settings.LOGGING` attaches `labcontrol.logging_filters.SuppressBrokenPipe` to
  the `django.server` handler to drop exactly that record — it matches the raw
  format string, not the rendered text, so an unrelated log line that merely
  mentions a broken pipe (an SSH failure from `remote_ops`, say) is never
  swallowed. Set `LABCONTROL_LOG_BROKEN_PIPE=1` to get the notices back. This is
  a `runserver`-only code path; it never fires under a production WSGI server.

---

## 10. Working with this user

- Prefers **terse directives** and expects complete, runnable implementations —
  not snippets or scaffolding.
- Iterates fast and stacks features; **verify before delivering**.
- Deploys to Windows — use Windows-safe paths and commands in instructions.
- Wants **previews**. Screenshots of the real rendered page (Playwright against a
  live dev server) beat mockups. Standalone `.jsx` previews with mock data are
  used when the live API isn't reachable in the sandbox.
- Be honest about what is stubbed vs working. Several turns ended by explicitly
  flagging what was *not* wired up (Celery, unconverted pages) — keep doing that.

### Verification checklist before delivering

Run from `labcontrol-md export/`.

```bash
python -m py_compile core/*.py labcontrol/*.py    # works with no venv; passes today
python manage.py check                            # needs Django installed; catches admin double-registration
python manage.py makemigrations --check --dry-run

# duplicate-def guard (see §2.4)
for f in core/views.py core/api.py core/remote_ops.py core/models.py; do
  grep -oh "^def [a-zA-Z0-9_]*" "$f" | sort | uniq -d
done

# urls -> api cross-reference: every api.X / views.X in urls.py must exist
grep -oh "api\.[a-zA-Z0-9_]*"   core/urls.py | sed 's/api\.//'   | sort -u
grep -oh "views\.[a-zA-Z0-9_]*" core/urls.py | sed 's/views\.//' | sort -u
```

JSX must transpile — `app.jsx` is compiled **in the browser**, so a syntax error
is a blank page with a console-only trace. Babel is **not installed** in this tree;
install it once:

```bash
npm install --no-save @babel/core @babel/preset-react
node -e "require('@babel/core').transformSync(
  require('fs').readFileSync('static/js/app.jsx','utf8'),
  {presets:['@babel/preset-react']}); console.log('JSX OK')"
```

---

## 11. Quick start

```bash
cd "labcontrol-md export"
python -m venv env && env\Scripts\activate     # Windows
pip install -r requirements.txt
pip install --upgrade "Django>=5.1.16,<6.0"    # mandatory, see 2.1
python manage.py makemigrations core            # migrations are NOT committed, see 2.5
python manage.py migrate
python manage.py seed_lab                       # creates admin / admin
python manage.py runserver 0.0.0.0:6600
```

Classic UI `/` · SPA `/app/` or `/spa/` · Admin `/admin/`

Sessions / Inventory / Drift pages stay empty until desktops are **online** (§9)
and:

```bash
python manage.py run_collectors --type all
python manage.py run_collectors --type software --lab 3   # limit to one Location
```

If migrations mention `UserSession` or `TaskRun`: delete `core/migrations/0*.py`
(keep `__init__.py`) and `labcontrol.sqlite3`, then re-migrate. Those models are dead.
