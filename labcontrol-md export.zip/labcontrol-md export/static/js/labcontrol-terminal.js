/* ══════════════════════════════════════════════════════════
   LabControl — Operations Terminal (classic Django pages)
   Streams background operations on every page.
   ══════════════════════════════════════════════════════════ */
(function (w) {
  var MAX = 300;
  var lines = [];

  function ts() {
    var d = new Date();
    return d.toLocaleTimeString('en-GB', { hour12: false }) + '.' +
           String(d.getMilliseconds()).padStart(3, '0');
  }

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  w.lcLog = function (level, msg) {
    lines.push({ t: ts(), l: level || 'info', m: msg });
    if (lines.length > MAX) lines.shift();
    render();
    try { sessionStorage.setItem('lcTermLines', JSON.stringify(lines.slice(-80))); } catch (e) {}
  };

  function render() {
    var body = document.getElementById('lc-term-body');
    var count = document.getElementById('lc-term-count');
    if (!body) return;
    if (!lines.length) {
      body.innerHTML = '<div class="lc-term-empty">Operations will stream here.</div>';
    } else {
      body.innerHTML = lines.map(function (x) {
        return '<div class="lc-term-line">' +
          '<span class="lc-term-time">' + x.t + '</span>' +
          '<span class="lc-term-lvl lvl-' + x.l + '">' + esc(x.l) + '</span>' +
          '<span class="lc-term-msg lvl-' + (x.l === 'out' ? 'out' : x.l) + '">' + esc(x.m) + '</span>' +
          '</div>';
      }).join('');
      body.scrollTop = body.scrollHeight;
    }
    if (count) count.textContent = lines.length + ' events';
  }

  w.lcToggleTerminal = function () {
    var t = document.getElementById('lc-terminal');
    var c = document.getElementById('lc-term-caret');
    if (!t) return;
    var open = t.classList.toggle('expanded');
    t.classList.toggle('collapsed', !open);
    /* base.html keys --lc-term-h off this class, and .lc-content reserves
       exactly that much bottom padding — otherwise an expanded terminal
       covers the last ~240px of the page and you cannot reach the controls
       underneath it. */
    document.body.classList.toggle('lc-term-open', open);
    /* Pages that size a pane to the remaining viewport need to re-measure. */
    if (typeof w.lcOnChrome === 'function') {
      setTimeout(function () { try { w.lcOnChrome(); } catch (e) {} }, 200);
    }
    /* Ace pages keep an <i class="fa ..."> caret; the Tailwind pages use a
       lucide icon that createIcons() has already swapped for an <svg>, where
       className is an SVGAnimatedString and not assignable. Rotate instead. */
    if (c) {
      if (c.tagName && c.tagName.toLowerCase() === 'i') {
        c.className = 'fa fa-chevron-' + (open ? 'down' : 'up') + ' ml-2';
      } else {
        c.style.transition = 'transform .18s';
        c.style.transform = open ? 'rotate(180deg)' : '';
      }
    }
    try { localStorage.setItem('lcTermOpen', open ? '1' : '0'); } catch (e) {}
    if (open) render();
  };

  w.lcClearTerminal = function () {
    lines = [];
    try { sessionStorage.removeItem('lcTermLines'); } catch (e) {}
    render();
  };

  /* CSRF-aware fetch that narrates itself into the terminal */
  function csrf() {
    var m = document.cookie.match('(^|;)\\s*csrftoken\\s*=\\s*([^;]+)');
    return m ? m.pop() : '';
  }

  w.lcApi = function (url, opts) {
    opts = opts || {};
    var label = opts.label || (opts.method || 'GET') + ' ' + url;
    w.lcLog('cmd', label);
    var headers = Object.assign({ 'X-CSRFToken': csrf() }, opts.headers || {});
    if (opts.body && !(opts.body instanceof FormData)) headers['Content-Type'] = 'application/json';
    return fetch(url, { credentials: 'same-origin', method: opts.method || 'GET',
                        headers: headers, body: opts.body })
      .then(function (r) {
        /* An expired session used to redirect to the HTML login page, and
           r.json() then failed with "Unexpected token '<'" — an error that
           says nothing about the real cause. Detect it and say so. */
        var ct = r.headers.get('content-type') || '';
        if (r.status === 401 || (r.redirected && /login/.test(r.url))) {
          w.lcAuthExpired = true;
          throw new Error('session expired — reload the page to sign in');
        }
        if (ct.indexOf('application/json') === -1) {
          throw new Error('server returned ' + r.status + ' ' +
                          (ct.split(';')[0] || 'unknown type') +
                          ' instead of JSON');
        }
        return r.json();
      })
      .then(function (data) {
        if (data.ok === false) {
          w.lcLog('err', data.error || data.detail || 'operation failed');
          (data.debug_suggestions || []).forEach(function (s) { w.lcLog('warn', s); });
        } else {
          (data.steps || []).forEach(function (s) { w.lcLog('out', s); });
          w.lcLog('ok', opts.okMsg || (data.detail || 'done'));
        }
        return data;
      })
      .catch(function (e) { w.lcLog('err', 'network error: ' + e.message); throw e; });
  };

  document.addEventListener('DOMContentLoaded', function () {
    /* restore previous session's tail + open state */
    try {
      var saved = sessionStorage.getItem('lcTermLines');
      if (saved) lines = JSON.parse(saved);
    } catch (e) {}
    if (localStorage.getItem('lcTermOpen') === '1') w.lcToggleTerminal();
    else render();
    w.lcLog('info', 'Terminal ready · ' + document.title.split('·')[0].trim());
  });
})(window);
