const { useState, useEffect, useCallback, useRef } = React;

/* ═══════════════════════════════════════════════════════════════
   LabControl SPA — served from Django, wired to the live API.
   Pages: Dashboard · File Manager · Sessions · Inventory ·
          Drift · Reservations · Schedules · AI · Logs
   ═══════════════════════════════════════════════════════════════ */

const C = {
  bg: "#05080F", bgCard: "#0B1120", bgPanel: "#111827", border: "#1E293B",
  cyan: "#00F0FF", lime: "#39FF14", rose: "#FF2D55", amber: "#FFB800",
  purple: "#A855F7", blue: "#3B82F6", text: "#F1F5F9", muted: "#94A3B8", dim: "#475569",
};
const MONO = "'Space Mono','JetBrains Mono',monospace";

// ─── API layer ───────────────────────────────────────────────
function getCookie(n) {
  const v = document.cookie.match("(^|;)\\s*" + n + "\\s*=\\s*([^;]+)");
  return v ? v.pop() : "";
}
async function api(path, opts = {}) {
  const h = { "X-CSRFToken": getCookie("csrftoken"), ...opts.headers };
  if (opts.body && !(opts.body instanceof FormData)) h["Content-Type"] = "application/json";
  const r = await fetch(path, { credentials: "include", ...opts, headers: h });
  if (r.headers.get("content-type")?.includes("application/json")) return r.json();
  return r;
}
function fmtTime(iso) { return iso ? new Date(iso).toLocaleString("en-GB", { hour12: false }) : "—"; }
function sizeStr(n) {
  if (n > 1e9) return (n/1e9).toFixed(1)+" GB"; if (n > 1e6) return (n/1e6).toFixed(1)+" MB";
  if (n > 1024) return (n/1024).toFixed(1)+" KB"; return n+" B";
}

// ─── Shared UI ───────────────────────────────────────────────
const S = {
  card: { background: C.bgCard, border: `1px solid ${C.border}`, borderRadius: 12, padding: 20, marginBottom: 16 },
  btn: (col=C.cyan) => ({ background: col+"15", color: col, border: `1px solid ${col}33`, padding: "8px 16px",
    borderRadius: 8, fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: MONO, transition: "all .2s" }),
  btnSm: (col=C.cyan) => ({ background: col+"15", color: col, border: `1px solid ${col}33`, padding: "4px 10px",
    borderRadius: 6, fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: MONO }),
  input: { background: C.bg, border: `1px solid ${C.border}`, color: C.text, padding: "8px 12px",
    borderRadius: 8, fontSize: 13, fontFamily: MONO, width: "100%" },
  th: { textAlign: "left", padding: "10px 14px", color: C.muted, fontSize: 11, fontWeight: 700,
    textTransform: "uppercase", letterSpacing: 1 },
  td: { padding: "8px 14px", fontSize: 12, borderBottom: `1px solid ${C.border}44` },
  label: { fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1.5, color: C.muted, marginBottom: 8 },
};

function Table({ cols, children }) {
  return (
    <div style={{ ...S.card, padding: 0, overflow: "hidden" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: MONO }}>
        <thead><tr style={{ background: C.bgPanel, borderBottom: `1px solid ${C.border}` }}>
          {cols.map((c, i) => <th key={i} style={S.th}>{c}</th>)}
        </tr></thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}
function Badge({ color, children }) {
  return <span style={{ padding: "2px 8px", borderRadius: 4, fontSize: 10, fontWeight: 700,
    background: color+"22", color, border: `1px solid ${color}44` }}>{children}</span>;
}
function Empty({ msg }) {
  return <tr><td colSpan={20} style={{ padding: 30, textAlign: "center", color: C.dim, fontSize: 13 }}>{msg}</td></tr>;
}

// ─── Terminal (global op log) ────────────────────────────────
const OpsContext = React.createContext(() => {});

function OpsTerminal({ lines, open, onToggle, onClear, leftOffset = 0 }) {
  const ref = useRef();
  useEffect(() => { if (ref.current) ref.current.scrollTop = ref.current.scrollHeight; }, [lines]);
  const col = { info: C.cyan, ok: C.lime, err: C.rose, warn: C.amber, cmd: C.purple, out: C.muted };
  return (
    <div style={{ position: "fixed", bottom: 0, left: leftOffset, right: 0, zIndex: 90, background: C.bgPanel,
      borderTop: `2px solid ${C.cyan}44`, height: open ? 220 : 38, overflow: "hidden",
      transition: "height .3s, left .2s" }}>
      <div style={{ height: 38, display: "flex", alignItems: "center", padding: "0 16px", gap: 12, cursor: "pointer",
        borderBottom: open ? `1px solid ${C.border}` : "none" }} onClick={onToggle}>
        <span style={{ display: "flex", gap: 6 }}>
          {[C.rose, C.amber, C.lime].map(c => <span key={c} style={{ width: 10, height: 10, borderRadius: "50%", background: c }} />)}
        </span>
        <span style={{ fontSize: 12, fontWeight: 700, color: C.cyan, fontFamily: MONO }}>⌁ OPERATIONS TERMINAL</span>
        <span style={{ fontSize: 10, color: C.dim }}>{lines.length} events</span>
        <div style={{ flex: 1 }} />
        {open && <button onClick={e => { e.stopPropagation(); onClear(); }} style={S.btnSm(C.dim)}>CLEAR</button>}
        <span style={{ color: C.muted }}>{open ? "▾" : "▴"}</span>
      </div>
      {open && <div ref={ref} style={{ height: 182, overflowY: "auto", padding: "8px 16px", background: "#020509",
        fontFamily: MONO, fontSize: 12, lineHeight: 1.55 }}>
        {!lines.length && <div style={{ color: C.dim, padding: 16, textAlign: "center" }}>Operations will stream here as you use the app.</div>}
        {lines.map((l, i) => <div key={i} style={{ display: "flex", gap: 10 }}>
          <span style={{ color: C.dim, minWidth: 72, fontSize: 11 }}>{l.time}</span>
          <span style={{ color: col[l.level] || C.text, minWidth: 40, fontSize: 11, fontWeight: 700, textTransform: "uppercase" }}>{l.level}</span>
          <span style={{ color: l.level === "out" ? C.muted : (col[l.level] || C.text), flex: 1, whiteSpace: "pre-wrap", wordBreak: "break-word" }}>{l.msg}</span>
        </div>)}
      </div>}
    </div>
  );
}

// ─── Dashboard ───────────────────────────────────────────────
function Dashboard() {
  const log = React.useContext(OpsContext);
  const [data, setData] = useState(null);
  const [pinging, setPinging] = useState(false);
  const load = useCallback(() => api("/api/dashboard/").then(r => r.ok && setData(r)), []);
  useEffect(() => { load(); const t = setInterval(load, 120000); return () => clearInterval(t); }, [load]);

  const pingAll = async () => {
    setPinging(true); log("cmd", "Pinging all managed desktops...");
    const r = await api("/api/ping-all/");
    if (r.ok) { log("ok", `Ping complete: ${r.online} online, ${r.offline} offline`); load(); }
    setPinging(false);
  };
  const power = async (id, action, name) => {
    if (action !== "wol" && !confirm(`${action} ${name}?`)) return;
    log("cmd", `[${name}] ${action}`);
    const r = await api(`/api/power/${id}/`, { method: "POST", body: JSON.stringify({ action }) });
    (r.steps || []).forEach(s => log("out", s));
    if (r.ok) log("ok", `[${name}] ${action} accepted`);
    else { log("err", `[${name}] ${r.detail || "failed"}`); (r.debug_suggestions||[]).forEach(s => log("warn", s)); }
    setTimeout(load, 2500);
  };

  if (!data) return <Loading />;
  const all = [...data.labs.flatMap(l => l.desktops.map(d => ({ ...d, _lab: l }))), ...(data.unassigned||[])];
  return (
    <div>
      <div style={{ display: "flex", gap: 12, marginBottom: 20, flexWrap: "wrap" }}>
        {[["TOTAL", data.stats.total, C.text], ["ONLINE", data.stats.online, C.lime],
          ["OFFLINE", data.stats.offline, C.rose], ["LABS", data.stats.locations, C.cyan]].map(([l,v,c]) =>
          <div key={l} style={{ ...S.card, marginBottom: 0, flex: 1, minWidth: 120 }}>
            <div style={S.label}>{l}</div>
            <div style={{ fontSize: 30, fontWeight: 900, color: c, fontFamily: MONO }}>{v}</div>
          </div>)}
        <div style={{ ...S.card, marginBottom: 0, display: "flex", alignItems: "center" }}>
          <button style={S.btn(C.amber)} onClick={pingAll} disabled={pinging}>{pinging ? "⏳ Pinging…" : "⚡ Ping All"}</button>
        </div>
      </div>

      {/* ARP neighbor discovery — inline on the dashboard */}
      <NeighborDiscovery devices={all} />

      {data.labs.map(lab => (
        <div key={lab.id} style={{ marginBottom: 28 }}>
          <h3 style={{ color: C.text, fontFamily: MONO, borderLeft: `4px solid ${lab.color||C.cyan}`, paddingLeft: 12, marginBottom: 12 }}>
            {lab.name} <span style={{ color: C.dim, fontSize: 12, fontWeight: 400 }}>{lab.building}/{lab.room}</span>
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(300px,1fr))", gap: 14 }}>
            {lab.desktops.map(d => {
              const sc = d.status === "online" ? C.lime : C.rose;
              return <div key={d.id} style={{ ...S.card, marginBottom: 0, borderLeft: `3px solid ${sc}` }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                  <strong style={{ fontFamily: MONO }}>{d.is_windows ? "🪟" : "🐧"} {d.device_name}</strong>
                  <Badge color={sc}>● {d.status}</Badge>
                </div>
                <div style={{ fontSize: 11, color: C.muted, fontFamily: MONO, marginBottom: 10 }}>
                  {d.ip_address}{d.last_ping_ms ? ` · ${d.last_ping_ms}ms` : ""}</div>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  <button style={S.btnSm(C.lime)} onClick={() => power(d.id, "wol", d.device_name)}>⚡ Wake</button>
                  <button style={S.btnSm(C.amber)} onClick={() => power(d.id, "reboot", d.device_name)}>🔄 Restart</button>
                  <button style={S.btnSm(C.rose)} onClick={() => power(d.id, "shutdown", d.device_name)}>⏻ Shutdown</button>
                </div>
              </div>;
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── ARP Neighbor Discovery (graph + accessible table) ──────
function NeighborDiscovery({ devices }) {
  const log = React.useContext(OpsContext);
  const [scanning, setScanning] = useState(false);
  const [data, setData] = useState(null);
  const [target, setTarget] = useState("local");
  const [view, setView] = useState("both"); // graph | table | both | registry
  const [registry, setRegistry] = useState(null);

  const loadRegistry = useCallback(async () => {
    const r = await api("/api/hosts/");
    if (r.ok) setRegistry(r);
  }, []);
  useEffect(() => { loadRegistry(); }, [loadRegistry]);

  const scan = async () => {
    setScanning(true);
    const src = target === "local" ? "server (local)" : `desktop #${target} (remote)`;
    log("cmd", `arp neighbor discovery on ${src} — ping-sweep + arp -a`);
    const q = target === "local" ? "" : `?desktop_id=${target}`;
    const r = await api(`/api/neighbors/${q}`);
    if (r.ok) {
      setData(r);
      const rec = r.recorded || {};
      log("ok", `Discovered ${r.count} neighbors (${r.managed_count} managed) via ${r.source} scan on ${r.host}`);
      if (rec.ok) log("info", `Registry updated: ${rec.created} new, ${rec.updated} existing (deduplicated by MAC)`);
      loadRegistry();
    } else {
      log("err", `Neighbor scan failed: ${r.error || "unknown"}`);
    }
    setScanning(false);
  };

  // Radial graph layout: scanner at center, neighbors on a ring
  const renderGraph = () => {
    if (!data) return null;
    const nodes = data.graph.nodes;
    const W = 620, H = 420, cx = W/2, cy = H/2;
    const ring = nodes.filter(n => n.type !== "scanner");
    const R = Math.min(170, 90 + ring.length * 4);
    const pos = { host: { x: cx, y: cy } };
    ring.forEach((n, i) => {
      const a = (i / Math.max(ring.length, 1)) * 2 * Math.PI - Math.PI/2;
      pos[n.id] = { x: cx + R * Math.cos(a), y: cy + R * Math.sin(a) };
    });
    const nodeColor = (t) => t === "scanner" ? C.cyan : t === "managed" ? C.lime : C.amber;
    return (
      <svg width="100%" viewBox={`0 0 ${W} ${H}`} role="img"
           aria-label={`Network topology graph: ${data.host} connected to ${ring.length} discovered neighbors`}
           style={{ background: "#020509", borderRadius: 10, border: `1px solid ${C.border}` }}>
        {data.graph.edges.map((e, i) => {
          const a = pos[e.from], b = pos[e.to];
          if (!a || !b) return null;
          return <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={C.border} strokeWidth={1.5} />;
        })}
        {nodes.map(n => {
          const p = pos[n.id]; if (!p) return null;
          const isHost = n.type === "scanner";
          const col = nodeColor(n.type);
          return (
            <g key={n.id}>
              <circle cx={p.x} cy={p.y} r={isHost ? 26 : 16} fill={col + "22"} stroke={col}
                strokeWidth={2} style={{ filter: `drop-shadow(0 0 6px ${col}66)` }} />
              <text x={p.x} y={isHost ? p.y+3 : p.y-22} textAnchor="middle" fill={col}
                fontSize={isHost ? 13 : 10} fontWeight="700" fontFamily={MONO}>
                {isHost ? "◉" : ""}{n.label.length > 14 ? n.label.slice(0,14)+"…" : n.label}
              </text>
              {!isHost && <text x={p.x} y={p.y+3} textAnchor="middle" fill={C.dim} fontSize={8} fontFamily={MONO}>
                {n.ip.split(".").slice(-1)[0]}
              </text>}
            </g>
          );
        })}
      </svg>
    );
  };

  const managedRing = data ? data.graph.nodes.filter(n => n.type === "managed").length : 0;
  const unknownRing = data ? data.graph.nodes.filter(n => n.type === "unknown").length : 0;

  return (
    <div style={{ ...S.card, marginBottom: 24 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14, flexWrap: "wrap" }}>
        <strong style={{ fontFamily: MONO, fontSize: 15 }}>🛰 Neighbor Discovery (ARP)</strong>
        <select value={target} onChange={e => setTarget(e.target.value)} style={{ ...S.input, width: "auto" }}
          aria-label="Scan source">
          <option value="local">Local — scan from server</option>
          {devices.filter(d => d.status === "online").map(d =>
            <option key={d.id} value={d.id}>Remote — {d.device_name} ({d.ip_address})</option>)}
        </select>
        <button style={S.btn(C.cyan)} onClick={scan} disabled={scanning}>
          {scanning ? "⏳ Sweeping subnet…" : "🔍 Discover Neighbors"}
        </button>
        {data && <div style={{ display: "flex", gap: 8, marginLeft: "auto" }}>
          {["both","graph","table","registry"].map(v =>
            <button key={v} style={view===v ? S.btnSm(C.cyan) : S.btnSm(C.dim)} onClick={() => setView(v)}>{v}</button>)}
        </div>}
        {!data && registry && registry.total > 0 && <button style={{ ...S.btnSm(C.purple), marginLeft: "auto" }}
          onClick={() => setView("registry")}>📋 View Registry ({registry.total})</button>}
      </div>

      {!data && <div style={{ color: C.dim, fontSize: 13, padding: "12px 0" }}>
        Populate the ARP cache by ping-sweeping the subnet, then map every attached device.
        Run locally on the server or remotely on any online desktop over SSH.
      </div>}

      {data && <div style={{ fontSize: 12, color: C.muted, marginBottom: 14, fontFamily: MONO }}>
        {data.source === "local" ? "🖥 Local scan on server" : `🔗 Remote scan on ${data.host}`} ·
        <span style={{ color: C.text }}> {data.count} devices</span> ·
        <span style={{ color: C.lime }}> {managedRing} managed</span> ·
        <span style={{ color: C.amber }}> {unknownRing} unmanaged</span>
      </div>}

      {data && (view === "graph" || view === "both") && (
        <div style={{ marginBottom: view === "both" ? 20 : 0 }}>{renderGraph()}</div>
      )}

      {/* Accessible table — screen-reader equivalent of the graph */}
      {data && (view === "table" || view === "both") && (
        <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: MONO, fontSize: 12 }}>
          <caption style={{ textAlign: "left", color: C.muted, fontSize: 11, padding: "0 0 8px",
            captionSide: "top" }}>
            Network neighbors discovered by {data.host} — {data.count} devices attached to the local segment.
            Each row is a device connected to the scanning host.
          </caption>
          <thead>
            <tr style={{ background: C.bgPanel, borderBottom: `1px solid ${C.border}` }}>
              <th scope="col" style={S.th}>IP Address</th>
              <th scope="col" style={S.th}>MAC Address</th>
              <th scope="col" style={S.th}>Hardware Vendor</th>
              <th scope="col" style={S.th}>Interface</th>
              <th scope="col" style={S.th}>Status</th>
            </tr>
          </thead>
          <tbody>
            {data.table.map((r, i) => (
              <tr key={i} style={{ borderBottom: `1px solid ${C.border}44` }}>
                <th scope="row" style={{ ...S.td, color: C.cyan, fontWeight: 700 }}>{r.ip}</th>
                <td style={S.td}>{r.mac}</td>
                <td style={S.td}>{r.vendor}</td>
                <td style={{ ...S.td, color: C.dim }}>{r.iface}</td>
                <td style={S.td}>{r.device_name
                  ? <Badge color={C.lime}>✓ {r.device_name}</Badge>
                  : <Badge color={C.amber}>unmanaged</Badge>}</td>
              </tr>
            ))}
            {!data.table.length && <tr><td colSpan={5} style={{ ...S.td, textAlign: "center", color: C.dim }}>
              No neighbors found in the ARP cache</td></tr>}
          </tbody>
        </table>
      )}

      {/* Deduplicated host registry — grouped by category */}
      {view === "registry" && registry && (
        <div>
          <div style={{ display: "flex", gap: 10, marginBottom: 14, flexWrap: "wrap" }}>
            {Object.entries(registry.by_category || {}).map(([cat, n]) => {
              const col = cat === "managed" ? C.lime : cat === "iot" ? C.cyan
                : cat === "infrastructure" ? C.amber : cat === "virtual" ? C.purple : C.dim;
              return <span key={cat} style={{ background: col+"22", color: col,
                border: `1px solid ${col}44`, padding: "4px 10px", fontSize: 11, borderRadius: 4,
                fontWeight: 700 }}>
                {cat}: {n}</span>;
            })}
          </div>
          <div style={{ fontSize: 11, color: C.muted, marginBottom: 10, fontFamily: MONO }}>
            {registry.total} unique hosts on record · deduplicated by MAC across all local + remote scans
          </div>
          <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: MONO, fontSize: 12 }}>
            <caption style={{ textAlign: "left", color: C.muted, fontSize: 11, padding: "0 0 8px", captionSide: "top" }}>
              Unique host registry — every distinct device ever discovered, deduplicated by hardware MAC address.
              Columns show the category, how many times each host has been seen, and whether it was found by local or remote scans.
            </caption>
            <thead><tr style={{ background: C.bgPanel, borderBottom: `1px solid ${C.border}` }}>
              <th scope="col" style={S.th}>IP</th><th scope="col" style={S.th}>MAC</th>
              <th scope="col" style={S.th}>Category</th><th scope="col" style={S.th}>Vendor</th>
              <th scope="col" style={S.th}>Seen</th><th scope="col" style={S.th}>Source</th>
              <th scope="col" style={S.th}>Last Seen</th>
            </tr></thead>
            <tbody>
              {registry.hosts.map(h => {
                const col = h.category === "managed" ? C.lime : h.category === "iot" ? C.cyan
                  : h.category === "infrastructure" ? C.amber : h.category === "virtual" ? C.purple : C.dim;
                return <tr key={h.id} style={{ borderBottom: `1px solid ${C.border}44` }}>
                  <th scope="row" style={{ ...S.td, color: C.cyan, fontWeight: 700 }}>{h.ip}</th>
                  <td style={S.td}>{h.mac || "—"}</td>
                  <td style={S.td}><span style={{ color: col, fontWeight: 700 }}>{h.category}</span>
                    {h.device_name ? ` (${h.device_name})` : ""}</td>
                  <td style={S.td}>{h.vendor || "—"}</td>
                  <td style={{ ...S.td, color: C.muted }}>×{h.times_seen}</td>
                  <td style={S.td}>
                    {h.seen_local && <span style={{ color: C.cyan }}>local </span>}
                    {h.seen_remote && <span style={{ color: C.amber }}>remote</span>}
                  </td>
                  <td style={{ ...S.td, color: C.dim, fontSize: 11 }}>{fmtTime(h.last_seen)}</td>
                </tr>;
              })}
              {!registry.hosts.length && <tr><td colSpan={7} style={{ ...S.td, textAlign: "center", color: C.dim }}>
                Registry empty — run a discovery scan to populate it</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}


function FileManager() {
  const log = React.useContext(OpsContext);
  const [devices, setDevices] = useState([]);
  const [deviceId, setDeviceId] = useState(null);
  const [path, setPath] = useState("");
  const [entries, setEntries] = useState([]);
  const [edit, setEdit] = useState(null);
  const [content, setContent] = useState("");
  const uploadRef = useRef();

  useEffect(() => { api("/api/dashboard/").then(r => {
    if (r.ok) { const ds = [...r.labs.flatMap(l => l.desktops), ...(r.unassigned||[])];
      setDevices(ds); if (ds[0]) { setDeviceId(ds[0].id); } }
  }); }, []);

  const dev = devices.find(d => d.id === deviceId);
  const load = useCallback((p) => {
    if (!deviceId) return;
    log("cmd", `sftp: ls ${p || "(home)"}`);
    api(`/api/files/${deviceId}/?path=${encodeURIComponent(p||"")}`).then(r => {
      if (r.ok) { setEntries(r.entries||[]); setPath(r.path||p); log("ok", `Listed ${(r.entries||[]).length} entries`); }
      else log("err", r.detail || r.error || "list failed");
    });
  }, [deviceId, log]);
  useEffect(() => { if (deviceId) load(""); }, [deviceId, load]);

  const openFile = (e) => {
    log("cmd", `sftp: get ${path}/${e.name}`);
    api(`/api/fm/${deviceId}/read/?path=${encodeURIComponent(path + "/" + e.name)}`).then(r => {
      if (r.ok) { setEdit({ ...e, full: path + "/" + e.name }); setContent(r.content||""); log("ok", `Opened ${e.name}`); }
      else log("err", r.detail || r.error);
    });
  };
  const save = () => {
    log("cmd", `sftp: put ${edit.full}`);
    api(`/api/fm/${deviceId}/write/`, { method: "POST", body: JSON.stringify({ path: edit.full, content }) })
      .then(r => { log(r.ok ? "ok" : "err", r.detail || r.error); if (r.ok) setEdit(null); });
  };
  const download = (e) => {
    log("cmd", `sftp: download ${e.name}`);
    window.location = `/api/fm/${deviceId}/download/?path=${encodeURIComponent(path + "/" + e.name)}`;
  };
  const del = (e) => { if (!confirm(`Delete ${e.name}?`)) return;
    log("warn", `sftp: rm ${e.name}`);
    api(`/api/fm/${deviceId}/delete/`, { method: "POST", body: JSON.stringify({ path: path + "/" + e.name }) })
      .then(r => { log(r.ok ? "ok" : "err", r.detail || r.error); if (r.ok) load(path); });
  };
  const upload = (file) => {
    if (!file) return;
    log("cmd", `sftp: put ${file.name} (${sizeStr(file.size)})`);
    const fd = new FormData(); fd.append("file", file); fd.append("path", path);
    const xhr = new XMLHttpRequest();
    xhr.upload.onprogress = e => e.lengthComputable && log("out", `  ${Math.round(e.loaded/e.total*100)}%`);
    xhr.onload = () => { const r = JSON.parse(xhr.responseText); log(r.ok?"ok":"err", r.detail||r.error); load(path); };
    xhr.open("POST", `/api/fm/${deviceId}/upload/`);
    xhr.setRequestHeader("X-CSRFToken", getCookie("csrftoken"));
    xhr.send(fd);
  };
  const nav = (e) => { if (!e.is_dir) return;
    if (e.name === "..") { const p = path.replace(/\/+$/,"").split("/"); p.pop(); load(p.join("/")||"/"); }
    else load((path.replace(/\/+$/,"")+"/"+e.name)); };

  return (
    <div>
      <h2 style={{ color: C.text, fontFamily: MONO, marginBottom: 16 }}>📂 Remote File Manager</h2>
      <div style={{ display: "flex", gap: 12, marginBottom: 16, flexWrap: "wrap" }}>
        <select value={deviceId||""} onChange={e => setDeviceId(+e.target.value)} style={{ ...S.input, width: "auto" }}>
          {devices.map(d => <option key={d.id} value={d.id}>{d.is_windows?"🪟":"🐧"} {d.device_name}</option>)}
        </select>
        <div style={{ ...S.input, flex: 1, color: C.cyan }}>{path || "(home)"}</div>
        <input ref={uploadRef} type="file" style={{ display: "none" }} onChange={e => upload(e.target.files[0])} />
        <button style={S.btn(C.lime)} onClick={() => uploadRef.current.click()}>⬆ Upload</button>
      </div>
      <Table cols={["Name", "Size", "Modified", "Actions"]}>
        {entries.map((e, i) => <tr key={i}>
          <td style={S.td}><span style={{ cursor: e.is_dir?"pointer":"default", color: e.is_dir?C.cyan:C.text }}
            onClick={() => e.is_dir && nav(e)}>{e.is_dir ? (e.name===".."?"↰ ":"📁 ") : "📄 "}{e.name}</span></td>
          <td style={S.td}>{e.is_dir ? "—" : sizeStr(e.size)}</td>
          <td style={{ ...S.td, color: C.dim }}>{e.mtime || "—"}</td>
          <td style={S.td}>{!e.is_dir && <span style={{ display: "flex", gap: 6 }}>
            <button style={S.btnSm(C.cyan)} onClick={() => openFile(e)}>View</button>
            <button style={S.btnSm(C.lime)} onClick={() => download(e)}>↓</button>
            <button style={S.btnSm(C.rose)} onClick={() => del(e)}>✕</button>
          </span>}</td>
        </tr>)}
        {!entries.length && <Empty msg="Empty or not loaded" />}
      </Table>
      {edit && <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.75)", zIndex: 95,
        display: "flex", alignItems: "center", justifyContent: "center" }} onClick={e => e.target===e.currentTarget && setEdit(null)}>
        <div style={{ ...S.card, width: "85%", maxWidth: 800, maxHeight: "80vh", display: "flex", flexDirection: "column" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
            <strong style={{ color: C.cyan, fontFamily: MONO }}>✎ {edit.full}</strong>
            <button style={{ background: "none", border: "none", color: C.muted, fontSize: 20, cursor: "pointer" }} onClick={() => setEdit(null)}>✕</button>
          </div>
          <textarea value={content} onChange={e => setContent(e.target.value)} spellCheck={false}
            style={{ flex: 1, minHeight: 300, background: "#020509", color: C.text, border: `1px solid ${C.border}`,
              padding: 16, fontFamily: MONO, fontSize: 13, resize: "none" }} />
          <div style={{ marginTop: 12 }}><button style={S.btn(C.lime)} onClick={save}>💾 Save to Remote</button></div>
        </div>
      </div>}
    </div>
  );
}

// ─── Generic list pages ──────────────────────────────────────
function Sessions() {
  const [rows, setRows] = useState([]);
  useEffect(() => { api("/api/sessions/?active=1").then(r => r.ok && setRows(r.sessions)); }, []);
  return (<div><h2 style={{ color: C.text, fontFamily: MONO, marginBottom: 16 }}>👥 Active Sessions</h2>
    <Table cols={["User", "Desktop", "Login", "Duration", "Idle", "TTY"]}>
      {rows.map(s => <tr key={s.id}>
        <td style={{ ...S.td, color: C.cyan }}>{s.username}</td><td style={S.td}>{s.desktop}</td>
        <td style={{ ...S.td, color: C.dim }}>{fmtTime(s.login_time)}</td><td style={S.td}>{s.duration}</td>
        <td style={S.td}>{Math.floor(s.idle_seconds/60)}m</td><td style={{ ...S.td, color: C.dim }}>{s.tty}</td>
      </tr>)}{!rows.length && <Empty msg="No active sessions. Run: python manage.py run_collectors --type sessions" />}
    </Table></div>);
}
function Inventory() {
  const [rows, setRows] = useState([]); const [q, setQ] = useState("");
  const load = useCallback(() => api(`/api/software/?search=${encodeURIComponent(q)}`).then(r => r.ok && setRows(r.software)), [q]);
  useEffect(() => { load(); }, [load]);
  return (<div><h2 style={{ color: C.text, fontFamily: MONO, marginBottom: 16 }}>📦 Software Inventory</h2>
    <input style={{ ...S.input, marginBottom: 16 }} placeholder="Search software…" value={q} onChange={e => setQ(e.target.value)} />
    <Table cols={["Software", "Version", "Desktop", "Publisher", "Source"]}>
      {rows.map((s, i) => <tr key={i}><td style={{ ...S.td, color: C.cyan }}>{s.name}</td>
        <td style={S.td}>{s.version||"—"}</td><td style={S.td}>{s.desktop}</td>
        <td style={{ ...S.td, color: C.dim }}>{s.publisher||"—"}</td><td style={S.td}><Badge color={C.blue}>{s.source}</Badge></td>
      </tr>)}{!rows.length && <Empty msg="No inventory. Run: python manage.py run_collectors --type software" />}
    </Table></div>);
}
function Drift() {
  const [rows, setRows] = useState([]);
  useEffect(() => { api("/api/drift/").then(r => r.ok && setRows(r.reports)); }, []);
  return (<div><h2 style={{ color: C.text, fontFamily: MONO, marginBottom: 16 }}>🔀 Configuration Drift</h2>
    <Table cols={["Desktop", "Status", "Issues", "Missing Packages", "Stopped Services", "Checked"]}>
      {rows.map((r, i) => <tr key={i}><td style={{ ...S.td, color: C.cyan }}>{r.desktop}</td>
        <td style={S.td}>{r.has_drift ? <Badge color={C.rose}>DRIFT</Badge> : <Badge color={C.lime}>CLEAN</Badge>}</td>
        <td style={S.td}>{r.drift_count}</td>
        <td style={{ ...S.td, color: C.amber }}>{(r.missing_packages||[]).join(", ")||"—"}</td>
        <td style={{ ...S.td, color: C.amber }}>{(r.stopped_services||[]).join(", ")||"—"}</td>
        <td style={{ ...S.td, color: C.dim }}>{fmtTime(r.checked_at)}</td>
      </tr>)}{!rows.length && <Empty msg="No drift reports. Run: python manage.py run_collectors --type drift" />}
    </Table></div>);
}
function Reservations() {
  const [rows, setRows] = useState([]);
  useEffect(() => { api("/api/reservations/?upcoming=1").then(r => r.ok && setRows(r.reservations)); }, []);
  return (<div><h2 style={{ color: C.text, fontFamily: MONO, marginBottom: 16 }}>📅 Reservations</h2>
    <Table cols={["Desktop", "User", "Purpose", "Start", "End", "Hours", "Status"]}>
      {rows.map(r => <tr key={r.id}><td style={{ ...S.td, color: C.cyan }}>{r.desktop}</td><td style={S.td}>{r.user}</td>
        <td style={S.td}>{r.purpose||"—"}</td><td style={{ ...S.td, color: C.dim }}>{fmtTime(r.start)}</td>
        <td style={{ ...S.td, color: C.dim }}>{fmtTime(r.end)}</td><td style={S.td}>{r.hours}h</td>
        <td style={S.td}><Badge color={C.lime}>{r.status}</Badge></td>
      </tr>)}{!rows.length && <Empty msg="No upcoming reservations. Create via /admin/core/reservation/add/" />}
    </Table></div>);
}
function Schedules() {
  const [rows, setRows] = useState([]);
  useEffect(() => { api("/api/scheduled-tasks/").then(r => r.ok && setRows(r.tasks)); }, []);
  return (<div><h2 style={{ color: C.text, fontFamily: MONO, marginBottom: 16 }}>⏰ Scheduled Tasks</h2>
    <Table cols={["Name", "Type", "Lab", "Cron", "Enabled", "Last Run"]}>
      {rows.map(t => <tr key={t.id}><td style={{ ...S.td, color: C.cyan }}>{t.name}</td><td style={S.td}>{t.task_display}</td>
        <td style={S.td}>{t.lab||"all"}</td><td style={{ ...S.td, fontFamily: MONO, color: C.dim }}>{t.cron}</td>
        <td style={S.td}>{t.is_enabled ? <Badge color={C.lime}>ON</Badge> : <Badge color={C.dim}>OFF</Badge>}</td>
        <td style={{ ...S.td, color: C.dim }}>{fmtTime(t.last_run)}</td>
      </tr>)}{!rows.length && <Empty msg="No scheduled tasks. Create via /admin/core/scheduledtask/add/" />}
    </Table></div>);
}
function AIAssist() {
  const log = React.useContext(OpsContext);
  const [prompt, setPrompt] = useState(""); const [resp, setResp] = useState(null); const [busy, setBusy] = useState(false);
  const ask = async () => { if (!prompt.trim()) return; setBusy(true); log("cmd", `AI: ${prompt.slice(0,50)}`);
    const r = await api("/api/ai/ask/", { method: "POST", body: JSON.stringify({ prompt }) });
    setResp(r); setBusy(false); log(r.ok?"ok":"err", `AI responded (${r.duration_ms}ms)`); };
  const readLogs = async () => { setBusy(true); log("cmd", "AI: reading shell error logs");
    const r = await api("/api/ai/read-logs/", { method: "POST", body: JSON.stringify({ log_type: "shell" }) });
    setResp(r); setBusy(false); };
  return (<div><h2 style={{ color: C.text, fontFamily: MONO, marginBottom: 16 }}>🤖 AI Assistant</h2>
    <div style={S.card}>
      <textarea style={{ ...S.input, height: 70, resize: "vertical" }} value={prompt} onChange={e => setPrompt(e.target.value)}
        placeholder="Ask anything: install apps, troubleshoot, suggest commands…"
        onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); ask(); } }} />
      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
        <button style={S.btn(C.cyan)} onClick={ask} disabled={busy}>{busy ? "⏳…" : "✨ Ask"}</button>
        <button style={S.btn(C.amber)} onClick={readLogs} disabled={busy}>📋 Read Error Logs</button>
      </div>
    </div>
    {resp && <div style={S.card}>
      <div style={{ marginBottom: 8 }}><Badge color={resp.ok?C.lime:C.rose}>{resp.ok?"OK":"ERR"}</Badge>
        <span style={{ marginLeft: 8, fontSize: 11, color: C.dim }}>{resp.duration_ms}ms · {resp.model}</span></div>
      {resp.error && <div style={{ color: C.rose, fontSize: 13 }}>{resp.error}</div>}
      <div style={{ fontSize: 13, lineHeight: 1.6, whiteSpace: "pre-wrap", color: C.text }}>{resp.response}</div>
    </div>}
  </div>);
}
function Logs() {
  const [rows, setRows] = useState([]); const [type, setType] = useState("shell");
  const load = useCallback(() => api(`/api/logs/?type=${type}&limit=60`).then(r => r.ok && setRows(r.logs)), [type]);
  useEffect(() => { load(); }, [load]);
  return (<div><h2 style={{ color: C.text, fontFamily: MONO, marginBottom: 16 }}>📊 Audit Logs</h2>
    <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
      {["shell","power","activity"].map(t => <button key={t} style={type===t?S.btn(C.cyan):S.btn(C.dim)} onClick={() => setType(t)}>{t}</button>)}
    </div>
    <div style={S.card}>{rows.map((l, i) => <div key={i} style={{ padding: "6px 0", borderBottom: `1px solid ${C.border}44`, fontSize: 12, fontFamily: MONO }}>
      {type==="shell" && <span><span style={{ color: C.cyan }}>{l.desktop}</span> · {l.command} · exit <span style={{ color: l.exit_code===0?C.lime:C.rose }}>{l.exit_code}</span></span>}
      {type==="power" && <span><span style={{ color: C.cyan }}>{l.desktop}</span> · {l.action} · <span style={{ color: l.success?C.lime:C.rose }}>{l.success?"OK":"FAIL"}</span></span>}
      {type==="activity" && <span><span style={{ color: C.muted }}>{l.user}</span> · {l.action} {l.path}</span>}
    </div>)}{!rows.length && <div style={{ color: C.dim, textAlign: "center", padding: 20 }}>No logs</div>}</div>
  </div>);
}
function Loading() { return <div style={{ color: C.muted, padding: 40, fontFamily: MONO }}>Loading…</div>; }

// ─── App shell ───────────────────────────────────────────────
// SPA pages (rendered inside this React app)
const PAGES = {
  dashboard: { label: "Dashboard", icon: "🖥", comp: Dashboard },
  files: { label: "File Manager", icon: "📂", comp: FileManager },
  sessions: { label: "Sessions", icon: "👥", comp: Sessions },
  inventory: { label: "Inventory", icon: "📦", comp: Inventory },
  drift: { label: "Config Drift", icon: "🔀", comp: Drift },
  reservations: { label: "Reservations", icon: "📅", comp: Reservations },
  schedules: { label: "Schedules", icon: "⏰", comp: Schedules },
  ai: { label: "AI Assistant", icon: "🤖", comp: AIAssist },
  logs: { label: "Audit Logs", icon: "📊", comp: Logs },
};

// Existing Django template pages (open in same tab, outside React)
const DJANGO_PAGES = [
  { label: "Classic Dashboard", icon: "🗂", url: "/" },
  { label: "Desktop List", icon: "🖥", url: "/desktops/" },
  { label: "App Catalog", icon: "📥", url: "/apps/" },
  { label: "Package Repo", icon: "📦", url: "/packages/" },
  { label: "Discovery", icon: "🛰", url: "/discovery/" },
  { label: "Locations", icon: "📍", url: "/locations/" },
  { label: "Django Admin", icon: "⚙", url: "/admin/" },
];

const SIDEBAR_W = 220;

function App() {
  const [page, setPage] = useState("dashboard");
  const [user, setUser] = useState(null);
  const [form, setForm] = useState({ username: "", password: "" });
  const [err, setErr] = useState("");
  const [termOpen, setTermOpen] = useState(true);
  const [lines, setLines] = useState([]);
  const [collapsed, setCollapsed] = useState(false);

  const log = useCallback((level, msg) => {
    const now = new Date();
    const time = now.toLocaleTimeString("en-GB", { hour12: false }) + "." + String(now.getMilliseconds()).padStart(3, "0");
    setLines(p => [...p.slice(-300), { time, level, msg }]);
  }, []);

  useEffect(() => { fetch("/api/csrf/", { credentials: "include" }); api("/api/me/").then(r => r.ok && setUser(r.user)); }, []);
  useEffect(() => { if (user) log("info", `Session active — ${Object.keys(PAGES).length} modules loaded`); }, [user, log]);

  const login = async () => {
    const r = await api("/api/login/", { method: "POST", body: JSON.stringify(form) });
    if (r.ok) { setUser(r.user); log("info", `Logged in as ${r.user}`); } else setErr(r.error || "Login failed");
  };

  if (!user) return (
    <div style={{ background: C.bg, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: MONO }}>
      <div style={{ ...S.card, width: 360, textAlign: "center" }}>
        <div style={{ fontSize: 40 }}>🖥</div>
        <h1 style={{ color: C.cyan, margin: "8px 0" }}>LabControl</h1>
        <div style={{ color: C.dim, fontSize: 12, marginBottom: 20 }}>Central Control Automation System</div>
        <input style={{ ...S.input, marginBottom: 12 }} placeholder="Username" value={form.username}
          onChange={e => setForm(p => ({ ...p, username: e.target.value }))} onKeyDown={e => e.key==="Enter"&&login()} />
        <input style={{ ...S.input, marginBottom: 16 }} type="password" placeholder="Password" value={form.password}
          onChange={e => setForm(p => ({ ...p, password: e.target.value }))} onKeyDown={e => e.key==="Enter"&&login()} />
        {err && <div style={{ color: C.rose, fontSize: 12, marginBottom: 12 }}>{err}</div>}
        <button style={{ ...S.btn(C.cyan), width: "100%" }} onClick={login}>Login</button>
      </div>
    </div>
  );

  const Page = PAGES[page].comp;
  const sw = collapsed ? 56 : SIDEBAR_W;
  const navItem = (active) => ({
    display: "flex", alignItems: "center", gap: 10, width: "100%",
    background: active ? C.cyan + "18" : "transparent",
    color: active ? C.cyan : C.muted, border: "none",
    borderLeft: active ? `3px solid ${C.cyan}` : "3px solid transparent",
    padding: collapsed ? "10px 0" : "10px 16px", justifyContent: collapsed ? "center" : "flex-start",
    fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: MONO, textAlign: "left",
    textDecoration: "none", transition: "all .15s",
  });

  return (
    <OpsContext.Provider value={log}>
      <div style={{ background: C.bg, minHeight: "100vh", color: C.text, display: "flex" }}>

        {/* ─── SIDEBAR ─── */}
        <aside style={{ width: sw, minWidth: sw, background: C.bgPanel, borderRight: `1px solid ${C.border}`,
          position: "fixed", top: 0, bottom: 0, left: 0, zIndex: 60, display: "flex", flexDirection: "column",
          transition: "width .2s", overflow: "hidden" }}>
          {/* Brand */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "16px", borderBottom: `1px solid ${C.border}` }}>
            <span style={{ fontSize: 22 }}>🖥</span>
            {!collapsed && <span style={{ fontSize: 16, fontWeight: 900, color: C.cyan, fontFamily: MONO }}>LabControl</span>}
          </div>

          {/* Scrollable nav */}
          <div style={{ flex: 1, overflowY: "auto", paddingTop: 8 }}>
            {!collapsed && <div style={{ ...S.label, padding: "8px 16px 4px" }}>SPA Modules</div>}
            {Object.entries(PAGES).map(([k, p]) => (
              <button key={k} onClick={() => setPage(k)} style={navItem(page === k)} title={p.label}>
                <span style={{ fontSize: 15 }}>{p.icon}</span>{!collapsed && p.label}
              </button>
            ))}
            {!collapsed && <div style={{ ...S.label, padding: "16px 16px 4px" }}>Classic Pages</div>}
            {collapsed && <div style={{ height: 1, background: C.border, margin: "8px 12px" }} />}
            {DJANGO_PAGES.map((p) => (
              <a key={p.url} href={p.url} style={navItem(false)} title={p.label}>
                <span style={{ fontSize: 15 }}>{p.icon}</span>{!collapsed && p.label}
              </a>
            ))}
          </div>

          {/* User + collapse */}
          <div style={{ borderTop: `1px solid ${C.border}`, padding: collapsed ? "10px 0" : "10px 16px" }}>
            {!collapsed && <div style={{ fontSize: 11, color: C.muted, marginBottom: 8, fontFamily: MONO }}>👤 {user}</div>}
            <div style={{ display: "flex", gap: 6, justifyContent: collapsed ? "center" : "flex-start" }}>
              <button style={S.btnSm(C.dim)} onClick={() => setCollapsed(c => !c)} title="Toggle sidebar">
                {collapsed ? "»" : "«"}
              </button>
              {!collapsed && <button style={S.btnSm(C.rose)} onClick={async () => { await api("/api/logout/"); setUser(null); }}>Logout</button>}
            </div>
          </div>
        </aside>

        {/* ─── MAIN CONTENT ─── */}
        <main style={{ marginLeft: sw, flex: 1, minHeight: "100vh", transition: "margin .2s",
          paddingBottom: termOpen ? 232 : 50 }}>
          {/* Top status bar */}
          <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 24px",
            background: C.bgPanel, borderBottom: `1px solid ${C.border}`, position: "sticky", top: 0, zIndex: 40 }}>
            <span style={{ fontSize: 15, fontWeight: 700, color: C.text, fontFamily: MONO }}>
              {PAGES[page].icon} {PAGES[page].label}
            </span>
            <div style={{ flex: 1 }} />
            <span style={{ fontSize: 11, color: C.dim, fontFamily: MONO }}>
              {lines.length ? `last: ${lines[lines.length-1].msg.slice(0,40)}` : "ready"}
            </span>
          </div>
          <div style={{ padding: 24 }}><Page /></div>
        </main>

        {/* ─── FOOTER TERMINAL (persists across all pages) ─── */}
        <OpsTerminal lines={lines} open={termOpen} onToggle={() => setTermOpen(o => !o)}
          onClear={() => setLines([])} leftOffset={sw} />
      </div>
    </OpsContext.Provider>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
