/* ══════════════════════════════════════════════════════════
   LabControl — shared fleet / lab / selection operations.

   Used by the Dashboard (Ace), All Desktops and Locations pages so the
   global Wake / Shutdown / Restart / Ping controls behave identically
   everywhere. Requires labcontrol-terminal.js for lcApi() / lcLog().

   Target precedence, matching api._resolve_targets():
     1. checked desktops   -> {desktop_ids: [...]}
     2. a chosen lab       -> {lab_id: n}
     3. otherwise          -> {scope: 'all'}
   ══════════════════════════════════════════════════════════ */
(function (w, d) {

  var SEL = '.lc-sel:checked, .dev-check:checked, .bulk-chk:checked';

  function selectedIds() {
    var seen = {};
    return Array.prototype.map.call(d.querySelectorAll(SEL), function (c) {
      return +c.value;
    }).filter(function (id) {
      if (!id || seen[id]) return false;
      seen[id] = 1; return true;
    });
  }

  /* The lab picker is optional; pages without one fall through to fleet. */
  function labScope() {
    var el = d.getElementById('lc-lab-scope');
    if (el && el.value) {
      return { id: +el.value,
               name: el.options[el.selectedIndex].getAttribute('data-name')
                     || el.options[el.selectedIndex].text };
    }
    if (w.LC_LAB_ID) return { id: +w.LC_LAB_ID, name: w.LC_LAB_NAME || 'this lab' };
    return null;
  }

  function currentTarget() {
    var ids = selectedIds();
    if (ids.length) {
      return { body: { desktop_ids: ids },
               label: ids.length + ' selected desktop' + (ids.length > 1 ? 's' : ''),
               fleetWide: false };
    }
    var lab = labScope();
    if (lab) {
      return { body: { lab_id: lab.id },
               label: 'every desktop in ' + lab.name,
               fleetWide: false };
    }
    return { body: { scope: 'all' },
             label: 'EVERY managed desktop in the fleet',
             fleetWide: true };
  }
  w.lcCurrentTarget = currentTarget;

  var VERB = { wol: 'Wake', shutdown: 'Shut down', reboot: 'Restart',
               suspend: 'Suspend' };

  /* Destructive actions get a confirm; fleet-wide destructive actions get a
     typed confirmation, because one stray click would take down every lab. */
  function confirmed(action, t) {
    if (action === 'wol') return true;
    var verb = VERB[action] || action;
    if (t.fleetWide) {
      var typed = prompt(
        verb.toUpperCase() + ' ' + t.label + '.\n\n' +
        'This interrupts anyone currently working on those machines.\n' +
        'Type FLEET to confirm.');
      if (typed !== 'FLEET') {
        w.lcLog('info', 'fleet-wide ' + action + ' cancelled');
        return false;
      }
      return true;
    }
    return confirm(verb + ' ' + t.label + '?');
  }

  /* Repaint every element that advertises a desktop's status.
     Only the two shapes this function actually understands get their text
     rewritten — a bare marker element (the monitor page's 8px dot, say) must
     keep its own content, or it ends up with the word "online" stuffed inside
     it. Pages with richer markup hook lcOnStatus to finish the job. */
  function paintStatus(id, status) {
    Array.prototype.forEach.call(
      d.querySelectorAll('[data-status-for="' + id + '"], .lc-status[data-dev="' + id + '"]'),
      function (el) {
        if (el.classList.contains('lc-status')) {
          el.className = 'lc-status lc-status-' + status;
          el.textContent = status;
        } else if (el.classList.contains('badge')) {
          el.className = 'badge badge-' + status;
          el.textContent = '● ' + status;
        }
      });
    if (typeof w.lcOnStatus === 'function') {
      try { w.lcOnStatus(id, status); } catch (e) {}
    }
  }
  w.lcPaintStatus = paintStatus;

  /* Refresh a lab's "online" counter wherever it is rendered (the All
     Desktops navigator and the Locations cards both use this hook). */
  w.lcPaintLabCount = function (labId, online) {
    Array.prototype.forEach.call(
      d.querySelectorAll('[data-lab-online="' + labId + '"]'),
      function (el) { el.textContent = online; });
  };

  w.lcPower = function (action) {
    var t = currentTarget();
    if (!confirmed(action, t)) return;
    var body = Object.assign({ action: action }, t.body);
    w.lcApi('/api/bulk-power/', {
      method: 'POST', body: JSON.stringify(body),
      label: (VERB[action] || action).toLowerCase() + ' → ' + t.label
    }).then(function (r) {
      if (!r || r.ok === false) return;
      var res = r.results || [];
      var good = 0;
      res.forEach(function (x) {
        if (x.success) good++;
        w.lcLog(x.success ? 'ok' : 'err', '[' + x.device + '] ' + (x.detail || ''));
        (x.debug_suggestions || []).forEach(function (s) { w.lcLog('warn', '  ' + s); });
      });
      /* ok:true only means the request was processed. Grading the batch on
         per-desktop results stops a wake where every machine refused from
         reading as a green success. */
      var level = good === 0 ? 'err' : (good < res.length ? 'warn' : 'ok');
      w.lcLog(level, r.summary || '');
      if (good === 0 && res.length) {
        var noMac = res.filter(function (x) {
          return /no mac address/i.test(x.detail || '');
        }).length;
        if (noMac) {
          w.lcLog('warn', noMac + ' of ' + res.length +
            ' have no MAC on file — Wake-on-LAN cannot address them. ' +
            'Run "Fix MACs" on this scope first.');
        }
      }
      /* WoL is fire-and-forget — re-poll rather than claim success. */
      if (action === 'wol' && good) {
        w.lcLog('info', 're-checking status in 45s (WoL is unacknowledged)');
        setTimeout(function () { w.lcPing(true); }, 45000);
      }
    });
  };

  w.lcPing = function (quiet) {
    var t = currentTarget();
    var body = JSON.stringify(t.body);
    /* The response's steps[] already carry the online/offline counts, which
       lcApi replays as OUT lines — so okMsg just closes the operation rather
       than repeating them. */
    return w.lcApi('/api/bulk-ping/', {
      method: 'POST', body: body,
      label: 'live status check → ' + t.label,
      okMsg: 'status check complete'
    }).then(function (r) {
      if (!r || r.ok === false) return r;
      (r.results || []).forEach(function (x) { paintStatus(x.id, x.status); });
      var on = d.getElementById('stat-online'), off = d.getElementById('stat-offline');
      if (on && t.body.scope === 'all') on.textContent = r.online;
      if (off && t.body.scope === 'all') off.textContent = r.offline;
      /* Lab navigator counters are server-rendered at page load; a lab-scoped
         sweep must refresh the one it just measured or it reads stale. */
      if (t.body.lab_id) w.lcPaintLabCount(t.body.lab_id, r.online);
      return r;
    });
  };

  /* (see remote_ops.wol_send for the multi-interface send)                */

  /* Harvest MACs over SSH. A desktop with no MAC can never be woken —
     power_on() refuses it before sending anything — so this is the fix for
     "Wake All did nothing". Only fills blanks unless the operator opts in. */
  w.lcCollectMacs = function () {
    var t = currentTarget();
    var overwrite = confirm(
      'Read the MAC address of ' + t.label + ' over SSH.\n\n' +
      'OK      = refresh every MAC (overwrite existing)\n' +
      'Cancel  = only fill in the missing ones (recommended)');
    var body = Object.assign({ overwrite: overwrite }, t.body);
    w.lcApi('/api/collect-macs/', {
      method: 'POST', body: JSON.stringify(body),
      label: 'MAC harvest → ' + t.label
    }).then(function (r) {
      if (!r || r.ok === false) return;
      (r.results || []).forEach(function (x) {
        if (!x.success) w.lcLog('warn', '[' + x.device + '] ' + x.detail);
      });
      w.lcLog(r.updated ? 'ok' : 'info', r.summary || '');
      if (r.updated) w.lcLog('info', 'reload the page to see the new MACs');
    });
  };

  /* ── Select-all helpers ─────────────────────────────────── */

  w.lcSelectAll = function (checked, scopeSel) {
    var boxes = d.querySelectorAll(scopeSel || '.lc-sel');
    Array.prototype.forEach.call(boxes, function (c) {
      if (c.offsetParent !== null || !scopeSel) c.checked = checked;
    });
    w.lcUpdateSelCount();
  };

  w.lcUpdateSelCount = function () {
    var n = selectedIds().length;
    Array.prototype.forEach.call(d.querySelectorAll('.lc-sel-count'), function (el) {
      el.textContent = n ? n + ' selected' : 'none selected — actions apply to the whole scope';
    });
  };

  d.addEventListener('change', function (e) {
    if (e.target && e.target.classList &&
        (e.target.classList.contains('lc-sel') ||
         e.target.classList.contains('dev-check') ||
         e.target.classList.contains('bulk-chk'))) {
      w.lcUpdateSelCount();
    }
  });

  d.addEventListener('DOMContentLoaded', function () { w.lcUpdateSelCount(); });

  /* ══════════════════════════════════════════════════════════
     Shared status auto-refresh — every classic page, one mechanism.

     Two different jobs, deliberately split:

       SWEEP  POST /api/bulk-ping/  actually pings the fleet. Expensive, so
              exactly one browser tab runs it per interval. The winner is
              chosen with a localStorage lease, otherwise five open tabs
              would mean five ICMP sweeps of 231 machines every cycle.

       SYNC   GET /api/status/      reads the DB only. Cheap, so every tab
              runs it and stays consistent with whatever the sweep found —
              including tabs that lost the lease.

     Both repaint through paintStatus(), which fires the lcOnStatus hook, so
     a page only has to describe its own markup once.
     ══════════════════════════════════════════════════════════ */

  var SWEEP_MS = 120000;   /* real ping sweep */
  var SYNC_MS  = 20000;    /* cheap DB read   */
  var LEASE_KEY = 'lcLastSweep';

  function setText(id, val) {
    var el = d.getElementById(id);
    if (el && val !== undefined && val !== null) el.textContent = val;
  }

  /* Repaint every status element, counter and lab tally from a response. */
  function applyStatus(r) {
    if (!r || r.ok === false) return;
    (r.results || []).forEach(function (x) { paintStatus(x.id, x.status); });
    var t = r.totals || {};
    setText('stat-total', t.total);
    setText('stat-online', t.online !== undefined ? t.online : r.online);
    setText('stat-offline', t.offline !== undefined ? t.offline : r.offline);
    setText('stat-unknown', t.unknown);
    var byLab = r.by_lab || {};
    Object.keys(byLab).forEach(function (k) {
      w.lcPaintLabCount(k, byLab[k].online);
    });
  }
  w.lcApplyStatus = applyStatus;

  /* Silent DB read — no terminal noise, this runs every 20s in every tab.
     If the session has expired it must say so once and stop: otherwise it
     repeats a JSON parse error every 20 seconds forever. */
  function sync() {
    if (d.hidden || w.lcAuthExpired) return;
    return fetch('/api/status/', { credentials: 'same-origin' })
      .then(function (res) {
        if (res.status === 401 || (res.redirected && /login/.test(res.url))) {
          w.lcAuthExpired = true;
          w.lcLog('err', 'session expired — reload the page to sign in');
          throw new Error('unauthenticated');
        }
        return res.json();
      })
      .then(applyStatus)
      .catch(function () { /* transient; the next tick retries */ });
  }
  w.lcSyncStatus = sync;

  /* Only one tab may run the expensive sweep per interval. */
  function claimSweep() {
    try {
      var last = parseInt(localStorage.getItem(LEASE_KEY) || '0', 10);
      if (Date.now() - last < SWEEP_MS - 2000) return false;
      localStorage.setItem(LEASE_KEY, String(Date.now()));
      return true;
    } catch (e) {
      return true;      /* no localStorage — poll anyway rather than never */
    }
  }

  function sweep() {
    if (d.hidden || !claimSweep()) return;
    w.lcApi('/api/bulk-ping/', {
      method: 'POST', body: JSON.stringify({ scope: 'all' }),
      label: 'auto-poll → entire fleet', okMsg: 'auto-poll complete'
    }).then(applyStatus).catch(function () {});
  }
  w.lcSweepNow = sweep;

  /* Autostart on any page that renders at least one status element. */
  d.addEventListener('DOMContentLoaded', function () {
    if (!d.querySelector('[data-status-for], [data-lab-online], #stat-online')) return;
    sync();                                   /* immediate: kill stale paint */
    setInterval(sync, SYNC_MS);
    setInterval(sweep, SWEEP_MS);
    /* A tab returning to the foreground should not show minutes-old state. */
    d.addEventListener('visibilitychange', function () { if (!d.hidden) sync(); });
  });

})(window, document);
