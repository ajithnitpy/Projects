# Bulk Import / Export Guide — LabControl

The Django admin at `/admin/` now has **Import** and **Export** buttons
on the Desktop, DesktopUser, and Location change lists, powered by
`django-import-export`.

## Exporting

1. Log in to `/admin/` as a superuser
2. Click **Desktops** (or Desktop Users / Locations)
3. Click the **EXPORT** button (top right)
4. Choose format: **csv**, **xlsx** (Excel), **xls**, **ods**, **json**, **yaml**, **html**, **tsv**
5. Optionally filter first via the sidebar — only the filtered queryset is exported
6. Click **Submit** → the file downloads

**Security**: Exported desktop files mask **both** secret fields —
`ssh_password` and `sudo_password` — as `***REDACTED***`. If you genuinely need
real passwords in exports, remove `dehydrate_ssh_password` /
`dehydrate_sudo_password` from `core/resources.py`.

**Round-trip is safe.** Because exports are masked, re-importing an exported
file would otherwise overwrite every stored password with the literal string
`***REDACTED***` and lock you out of the whole fleet. `before_import_row()`
drops any password cell equal to that sentinel, so the stored value is kept.
Export → edit other columns → re-import is therefore a supported workflow;
only rows where you type a *real* new password change the credential.

## Importing

1. Click **Desktops** (or Desktop Users / Locations)
2. Click **IMPORT** (top right)
3. Upload a `.csv` or `.xlsx` file
4. Choose the format
5. Click **Submit**
6. Review the **dry-run preview** — shows what will be created, updated, or skipped
7. Click **Confirm import** to actually commit

Rows are matched on:
- **Desktop** → `device_name` (so re-importing the same name updates the existing row)
- **DesktopUser** → `(desktop + username)` composite
- **Location** → `name`

## CSV Templates

The `sample_imports/` folder in the project contains ready-to-use templates:

| File | Purpose |
|---|---|
| `sample_imports/locations_template.csv` | 5 sample locations |
| `sample_imports/desktops_template.csv` | 6 sample desktops (mix of Linux + Windows) |
| `sample_imports/desktop_users_template.csv` | 9 sample OS users |

**Import order matters**: Locations → Desktops → DesktopUsers, because
desktops reference locations and users reference desktops.

## Desktop CSV Columns

| Column | Required | Example | Notes |
|---|---|---|---|
| `device_name` | ✓ | `lab-a-pc-01` | Unique — used for matching |
| `ip_address` | ✓ | `192.168.1.11` | Unique |
| `mac_address` |   | `AA:BB:CC:00:00:11` | For Wake-on-LAN |
| `ssh_username` | ✓ | `labadmin` or `Administrator` | |
| `ssh_password` |   | `ChangeMe123` | Plain text (encrypt in prod!). Masked on export |
| `ssh_port` |   | `22` | Default 22 |
| `ssh_key_path` |   | `/home/labadmin/.ssh/id_ed25519` | Key auth instead of a password |
| `use_sudo` |   | `True` / `False` | Default True. Set False for Windows targets |
| `sudo_password` |   | `ChangeMe123` | Needed for privileged Linux ops. Masked on export |
| `make` |   | `Dell` | |
| `model` |   | `OptiPlex 7090` | |
| `serial_no` |   | `SN12345` | |
| `cpu` |   | `Intel Core i7-12700` | |
| `ram_gb` |   | `16` | Integer |
| `storage_gb` |   | `512` | Integer |
| `os_type` |   | `ubuntu` / `win11` / `win10` / `debian` | See model choices |
| `os_version` |   | `22.04 LTS` / `Windows 11 23H2` | |
| `purchase_year` |   | `2023` | Integer |
| `location` |   | `Lab A · Networking` | Matched by name (case-sensitive) |
| `asset_tag` |   | `LAB-10001` | |
| `status` |   | `online` / `offline` / `unknown` | Default `unknown` |
| `notes` |   | Free text | |
| `is_managed` |   | `True` / `False` | Default True |

## DesktopUser CSV Columns

| Column | Required | Example |
|---|---|---|
| `desktop` | ✓ | `lab-a-pc-01` (matches Desktop.device_name) |
| `username` | ✓ | `student01` |
| `full_name` |   | `Student One` |
| `uid` |   | `1001` (Linux) or blank (Windows) |
| `gid` |   | `1000` (Linux) or blank (Windows) |
| `home_dir` |   | auto-filled from OS if blank |
| `shell` |   | `/bin/bash` or `powershell.exe` |
| `is_locked` |   | `True` / `False` |
| `is_sudoer` |   | `True` / `False` |

## Tips

- **Excel users**: save as `.xlsx` or "CSV UTF-8" — avoid plain CSV because
  special characters (like `·` in location names) may get mangled
- **Update existing**: re-import with the same `device_name` and any
  changed columns will be updated. Rows with no changes are reported as skipped
- **Test first**: always use the dry-run preview before confirming
- **Transactions**: all imports run in a single database transaction —
  if any row fails, the whole import is rolled back
- **Permissions**: only users with `add_desktop` permission can import;
  only users with `view_desktop` permission can export
