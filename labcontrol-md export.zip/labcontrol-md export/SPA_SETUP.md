# LabControl SPA — Frontend Setup

The React single-page app is served from Django at **`/spa/`**. There are two
ways to run it. You already have Path 2 working out of the box.

## Path 2 — CDN (no Node.js) — WORKS NOW

Nothing to build. Django serves `templates/core/spa.html`, which loads React +
Babel from a CDN and transpiles `static/js/app.jsx` in the browser.

Just run the server and visit the SPA:

```
python manage.py runserver 0.0.0.0:8000
# Open http://<server>:8000/spa/
```

Pros: zero build step, no Node.js. Cons: ~500 KB of CDN JS on first load,
in-browser transpile adds ~1s to initial render. Fine for a lab tool.

## Path 1 — Vite build (optimized, needs Node.js)

For faster loads, precompile the JSX into a minified bundle.

### 1. Install Node.js
Download from https://nodejs.org (LTS). Verify: `node --version`

### 2. Create the Vite project (once)

```bash
cd D:\Projects\labcontrol-enhanced
npm create vite@latest frontend -- --template react
cd frontend
npm install
```

### 3. Copy the app in

Copy `static/js/app.jsx` into `frontend/src/App.jsx`. Change the last line
from:

```js
ReactDOM.createRoot(document.getElementById("root")).render(<App />);
```

to a standard export:

```js
export default App;
```

And in `frontend/src/main.jsx`:

```js
import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
ReactDOM.createRoot(document.getElementById("root")).render(<App />);
```

### 4. Configure Vite to output into Django static

Edit `frontend/vite.config.js`:

```js
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  base: "/static/spa/",
  build: {
    outDir: "../static/spa",
    emptyOutDir: true,
    manifest: true,
  },
  server: {
    proxy: { "/api": "http://localhost:8000" },
  },
});
```

### 5. Development (hot reload)

```bash
cd frontend
npm run dev        # http://localhost:5173, proxies /api to Django:8000
```

Run Django on :8000 in another terminal. Edit code and see instant updates.

### 6. Production build

```bash
npm run build      # outputs to ../static/spa/
```

Then update `templates/core/spa.html` to load the built bundle instead of the
CDN version. Vite generates a `manifest.json` in `static/spa/.vite/` — point
the template's `<script>` at the hashed filename it lists, e.g.:

```html
<script type="module" src="{% static 'spa/assets/index-abc123.js' %}"></script>
```

Then `python manage.py collectstatic` and serve normally.

## Which pages are in the SPA

All wired to the live API:

| Page | What it does | API it calls |
|---|---|---|
| Dashboard | Device tiles, Ping All, per-device power | /api/dashboard/, /api/ping-all/, /api/power/ |
| File Manager | Browse/view/edit/download/upload/delete remote files | /api/files/, /api/fm/* |
| Sessions | Active login sessions | /api/sessions/ |
| Inventory | Fleet software list, searchable | /api/software/ |
| Drift | Config drift reports per desktop | /api/drift/ |
| Reservations | Upcoming bookings | /api/reservations/ |
| Schedules | Scheduled task list | /api/scheduled-tasks/ |
| AI Assistant | General Q&A + read error logs | /api/ai/ask/, /api/ai/read-logs/ |
| Logs | Shell/power/activity audit | /api/logs/ |

The Operations Terminal at the footer streams every action across all pages.

## Populating data

Sessions, Inventory, and Drift pages are empty until a collector runs:

```bash
python manage.py run_collectors --type all
```

Reservations and Schedules are created via Django admin:
- /admin/core/reservation/add/
- /admin/core/scheduledtask/add/
